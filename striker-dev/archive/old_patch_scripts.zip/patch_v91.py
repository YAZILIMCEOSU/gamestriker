p='/home/user/striker-dev/index.html'
s=open(p,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old); assert n==1,(n,old[:70]); s=s.replace(old,new)
# SIHA/heli/drone: attack runs instead of orbiting their origin
rep('ai=n.airborne&&(n.kind==="interceptor"||n.kind==="attacker"||n.kind==="uav");const a=n.airborne?310:n.grounded?0:80;ai?this.chaseAI(n,e):(',
    'ai=n.airborne&&(n.kind==="interceptor"||n.kind==="attacker");const rn=n.airborne&&!ai&&(n.kind==="uav"||n.kind==="heli"||n.kind==="drone");const a=n.airborne?310:n.grounded?0:80;ai?this.chaseAI(n,e):rn?this.runAI(n,e):(')
rep('n.airborne&&!ai&&(n.position.y+=','n.airborne&&!ai&&!rn&&(n.position.y+=')
rep('surpriseTick(dt){',
'''runAI(n,e){n.mT=(n.mT||0)-e;const pl=this.player,dx=pl.x-n.position.x,dz=pl.z-n.position.z,dist=Math.hypot(dx,dz)||1;
if(n.mode!=="egress")n.mode="approach";
if(n.mode==="approach"&&dist<650&&n.mT<=0){n.mode="egress";n.mT=3.2+Math.random()*1.2;n.egAng=Math.atan2(dz,dx)+(Math.random()<.5?-1:1)*(1.3+Math.random()*.5)}
else if(n.mode==="egress"&&n.mT<=0)n.mode="approach";
let tx=pl.x,tz=pl.z;if(n.mode==="egress"){tx=n.position.x+Math.cos(n.egAng)*1200;tz=n.position.z+Math.sin(n.egAng)*1200}
const ddx=tx-n.position.x,ddz=tz-n.position.z,L=Math.hypot(ddx,ddz)||1;
const sp=(n.kind==="heli"?150:n.kind==="uav"?170:190)*[.9,1,1.08,1.16,1.25][this.di||0];
n.position.x+=ddx/L*sp*e;n.position.z+=ddz/L*sp*e;
const ty=n.kind==="heli"?85:Math.max(180,Math.min(700,pl.y+(n.mode==="egress"?140:0)));
n.position.y+=(ty-n.position.y)*Math.min(1,e*1.2);
n.heading=Math.atan2(ddx,-ddz)}
surpriseTick(dt){''')
s=s.replace('3.64 DEV','3.65 DEV')
open(p,'w',encoding='utf-8').write(s)
print('v91 ok')
