#!/usr/bin/env python3
# v3.28 — FAZ A: diagnostik ag (havuz/fps/proj canli sayaclar)
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v52.py"], cwd="/home/user", capture_output=True, text=True)
print("v52:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

rep('this.fuel<=0&&this.phase==="combat"&&this.finish(!1,"fuel"),this.catT+=a,',
    'this.fuel<=0&&this.phase==="combat"&&this.finish(!1,"fuel"),this.dFps=this.dFps?this.dFps*.95+.05/Math.max(a,1e-4):60,window.__diag={t:this.time,phase:this.phase,proj:this.projectiles.reduce((q,p)=>q+(p.active?1:0),0),pool:this.projectiles.length,fps:Math.round(this.dFps)},this.catT+=a,',
    "diagHook")

c28=s.count("3.27 DEV")
if c28<2:
    print("FAIL badge",c28); sys.exit(1)
s=s.replace("3.27 DEV","3.28 DEV")
print("ok badge x",c28)

io.open(P,"w",encoding="utf-8").write(s)
print("v53 size",len(s))
