#!/usr/bin/env python3
# v3.29 — FAZ B: webgl context restored -> gorunur overlay; yasam dongusu saglamlastirma
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v53.py"], cwd="/home/user", capture_output=True, text=True)
print("v53:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

rep('Q.current.addEventListener("webglcontextlost",ft);',
    'Q.current.addEventListener("webglcontextlost",ft);const Ct=()=>{window.__showBoot&&window.__showBoot("webgl context restored - reload required")};Q.current.addEventListener("webglcontextrestored",Ct);',
    "ctxRestored")

rep('St.removeEventListener("webglcontextlost",ft),',
    'St.removeEventListener("webglcontextlost",ft),St.removeEventListener("webglcontextrestored",Ct),',
    "ctxCleanup")

c29=s.count("3.28 DEV")
if c29<2:
    print("FAIL badge",c29); sys.exit(1)
s=s.replace("3.28 DEV","3.29 DEV")
print("ok badge x",c29)

io.open(P,"w",encoding="utf-8").write(s)
print("v54 size",len(s))
