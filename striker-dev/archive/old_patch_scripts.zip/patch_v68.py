P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old); assert n==1, f"count {n}: {old[:60]}"
    s=s.replace(old,new)
# 1) surface ships follow the real wave surface instead of a fixed y=0 plane
rep('o.airborne||o.kind===\"sub\"||(c.position.y=0)',
    'o.airborne||o.kind===\"sub\"||(c.position.y=this.seaY(o.position.x,o.position.z)+.6)')
# 2) CPU mirror of the ocean vertex displacement (ocean mesh sits at y=-2.5)
method=('seaY(x,z){const t=this.time;'
        'const d=Math.sin(x*.013+t*.5)*1.3+Math.sin(z*.023+t*.7)*.65+Math.sin((x*.7+z*.7)*.031+t*1.15)*.42+Math.sin((x*.86-z*.5)*.052-t*.9)*.26;'
        'return -2.5+d}')
rep('cloudTick(e){', method+'cloudTick(e){')
# 3) badge
s=s.replace('3.42 DEV','3.43 DEV')
open(P,'w',encoding='utf-8').write(s); print('v68 ok', len(s))
