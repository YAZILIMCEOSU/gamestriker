#!/usr/bin/env python3
# v3.32 — FAZ E (K5): recon / timer / carrier-defense gorev turleri
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v56.py"], cwd="/home/user", capture_output=True, text=True)
print("v56:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

# 1) uc yeni gorev (id==index korunur: sona eklenir)
rep('],reward:2200,limit:420});',
    '],reward:2200,limit:420});dn.push({id:202,name:"KEŞİF HATTI",season:3,chapter:3,kind:"recon",targets:["interceptor","interceptor"],briefing:["A photo-recon line ahead of the front. Four markers, one pass each.","Ön hattın önünde foto-keşif hattı. Dört işaret, her birine tek geçiş."],reward:1800,limit:300,par:200});dn.push({id:203,name:"SON SANİYE",season:3,chapter:3,kind:"timer",targets:["bridge","radar","refinery"],briefing:["Command wants it done yesterday. Half the window, double the glory.","Komuta dün bitmiş istiyor. Pencerenin yarısı, şerefin iki katı."],reward:2000,limit:240,par:150});dn.push({id:204,name:"AURORA KALKANI",season:3,chapter:3,kind:"cdef",targets:["attacker","bomber","attacker","bomber","heavy"],briefing:["Every gun in the sky is aiming at AURORA today. Be the shield.","Bugün gökyüzündeki her silah AURORA\'yı hedefliyor. Kalkan ol."],reward:2400,limit:360,par:260});',
    "newMissions")

# 2) ctor: recon noktalari + cdef saglik
rep('this.notify("takeoffRoll",5),',
    'this.notify("takeoffRoll",5),this.reconPts=e.kind==="recon"?[new H(900,140,-400),new H(-1100,160,-1500),new H(400,180,-2600),new H(-500,150,-3600)]:null,this.reconIdx=0,e.kind==="cdef"&&(this.carrierHealth=100),',
    "reconCtor")

# 3) update: recon yakalama + timer siniri + cdef guverte hasari
rep(';const LS=this.target?',
    ';if(this.phase==="combat"&&this.reconPts&&this.reconIdx<this.reconPts.length&&this.player.distanceTo(this.reconPts[this.reconIdx])<190){this.reconIdx++,this.score+=150,this.notify("reconGot",3),this.reconIdx>=this.reconPts.length&&(this.ext=1)}if(this.mission.kind==="timer"&&this.phase==="combat"&&this.time>this.mission.limit*.5&&!this.result)this.finish(!1,"timeout");if(this.mission.kind==="cdef"&&this.phase==="combat")for(const q of this.alive)q.airborne&&q.position.distanceTo(this.homePos)<600&&(this.carrierHealth=Math.max(0,this.carrierHealth-a*4));const LS=this.target?',
    "kindsLogic")

# 4) hudData
rep('boss:s.bossHp||null,', 'boss:s.bossHp||null,recon:s.reconIdx||0,reconN:s.reconPts?s.reconPts.length:0,', "hudRecon")

# 5) HUD recon sayaci
rep('e.boss&&S.jsxs("div",{className:"carrier-status boss-bar",',
    'e.reconN>0&&S.jsxs("div",{className:"carrier-status",children:["RECON ",e.recon,"/",e.reconN]}),e.boss&&S.jsxs("div",{className:"carrier-status boss-bar",',
    "reconHudJsx")

# 6) i18n intel_ + reconGot
a='الزعيم حرج — أنهِ الآن!"]'
add=',intel_recon:["Fly the route and photograph all four markers. Cameras hot at 190 m.","Rotayı uç ve dört işaretin hepsini fotoğrafla. Kameralar 190 m\'de aktif.","Fliege die Route und fotografiere alle vier Marker.","Recorre la ruta y fotografía los cuatro marcadores.","Suivez la route et photographiez les quatre repères.","Percorri la rotta e fotografa i quattro segnali.","Percorra a rota e fotografe os quatro marcadores.","Пролети маршрут и сфотографируй четыре метки.","Terbangi rute dan foto empat penanda.","حلّق على المسار وصوّر العلامات الأربع."],intel_timer:["Beat the clock: half the usual window. Every second is score.","Saati yen: pencerenin yarısı. Her saniye puan.","Schlag die Uhr: halbes Zeitfenster.","Gana al reloj: mitad de tiempo.","Battez l\'horloge : moitié du temps.","Batti il tempo: metà finestra.","Vença o relógio: metade do tempo.","Обгони время: половина окна.","Kalahkan jam: setengah jendela.","اسبق الساعة: نصف المهلة."],intel_cdef:["Hostiles are diving on AURORA. Keep them off the deck until the wave breaks.","Düşmanlar AURORA\'ya dalıyor. Dalga kırılana kadar güverteden uzak tut.","Feinde stürzen auf die AURORA — halte sie fern.","Los hostiles se lanzan sobre AURORA; mantenlos lejos.","Les hostiles fondent sur l\'AURORA ; écartez-les.","I nemici piombano sull\'AURORA; tienili lontani.","Hostis mergulham na AURORA; mantenha-os longe.","Противник пикирует на АВРОРУ — не подпускай.","Musuh menujam ke AURORA; jauhkan mereka.","الأعداء ينقضّون على أورورا — أبعدهم عن السطح."],reconGot:["Marker photographed.","İşaret fotoğraflandı.","Marker fotografiert.","Marcador fotografiado.","Repère photographié.","Segnale fotografato.","Marcador fotografado.","Метка снята.","Penanda difoto.","تم تصوير العلامة."]'
assert s.count(a)==1
s=s.replace(a,a+add)
print("ok i18nKinds")

rep('race:Pu,chain:ib};','race:Pu,chain:ib,recon:Pu,timer:Wp,cdef:qp};',"kindIcons")

c32=s.count("3.31 DEV")
if c32<2:
    print("FAIL badge",c32); sys.exit(1)
s=s.replace("3.31 DEV","3.32 DEV")
print("ok badge x",c32)

io.open(P,"w",encoding="utf-8").write(s)
print("v57 size",len(s))
