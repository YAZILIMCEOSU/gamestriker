import sys
p='/home/user/striker-dev/index.html'
s=open(p,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old)
    assert n==1,(n,old[:60])
    s=s.replace(old,new)
# 1) season-0 missions were all in sunset/haze mode (0.12 is truthy)
rep('sunset:[.12,0,.6,1][sn]','sunset:[0,0,.6,1][sn]')
# 2) balance sea/land/air target mix for every generated mission
bal=('targets:((t,id)=>{const L=["refinery","sam","radar","airfield","bridge"],A=["interceptor","attacker","uav","heli"],S=["corvette","destroyer","sub"],k=p=>t.filter(x=>p.includes(x)).length;'
     'while(k(L)>4){const i=t.indexOf("airfield");t.splice(i>=0?i:t.findIndex(x=>L.includes(x)),1)}'
     'for(let i=k(A);i<2;i++)t.push(["interceptor","uav","attacker","heli"][(id+i)%4]);'
     'for(let i=k(S);i<3;i++)t.push(["destroyer","corvette","destroyer"][(id+i)%3]);'
     'for(let i=k(L);i<2;i++)t.push(["refinery","sam","radar"][(id+i)%3]);return t})(sn>1&&c.length<9?c.concat("drone"):c,e),')
rep('targets:sn>1&&c.length<9?c.concat("drone"):c,',bal)
assert s.count('3.58 DEV')==2; s=s.replace('3.58 DEV','3.59 DEV')
open(p,'w',encoding='utf-8').write(s)
print('v85 ok',len(s))
