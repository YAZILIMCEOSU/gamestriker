#!/usr/bin/env python3
# v3.38 — KATAPULT IPTAL + yumusak kalkis + mat malzeme paketi.
# Zorla ivme/sarsinti/kilitli kontrollu katapult yerine kademeli takeoff roll + otomatik rotasyon.
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v62.py"], cwd="/home/user", capture_output=True, text=True)
print("v62:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag):
    global s
    c = s.count(old)
    if c != 1:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

# 1) kontrol yetkisi: katapult kilidi yerine kademeli
rep('const AUTH=this.catT<2.6?0:this.catT<3.8?Math.min(1,(this.catT-2.6)/1.2):1;',
    'const AUTH=Math.min(1,this.catT/2.2);', "authRamp")

# 2) hedef hiz: zorla 260/s ivme yerine kademeli roll
rep('const f=this.catT<2.6?Math.min(178,this.speed+(this.phase==="takeoff"?30:260)*a):88+n.throttle*(this.aircraft.speed-88)+(n.boost?40:0);',
    'const f=88+n.throttle*(this.aircraft.speed-88)+(n.boost?40:0);', "rollTarget")

# 3) damp + otomatik rotasyon; y-kilit ve zorla pitch kaldirildi
rep('if(this.catT<2.6?this.speed=Math.min(178,this.speed+260*a):this.speed=li.damp(this.speed,f9,.8,a),this.time<6&&(this.pitch=Math.max(this.pitch,this.catT<1.7?.07:Math.min(.2,.07+(this.catT-1.7)*.045))),this.catT<1.7&&(this.player.y=17),',
    'if(this.phase==="takeoff"&&this.speed<76?this.speed=Math.min(76,this.speed+30*a):this.speed=li.damp(this.speed,f9,.8,a),this.phase==="takeoff"&&this.speed<62&&(this.pitch=Math.min(this.pitch,.05)),this.phase==="takeoff"&&this.speed>62&&(this.pitch=Math.max(this.pitch,Math.min(.14,(this.speed-62)/400+.06))),', "smoothRotate")

# 4) liftoff esigi
rep('this.phase==="takeoff"&&(this.speed>70&&this.catT>2.2?(this.phase="combat",this.catT=4,this.notify("airborne",5)):0)',
    'this.phase==="takeoff"&&(this.speed>74?(this.phase="combat",this.catT=Math.max(4,this.catT),this.notify("airborne",5)):0)', "liftoff")

# 5) katapult kamera sarsintisi kaldirildi
rep(',!this.options.reducedMotion&&n.catT<2.6&&(this.camera.position.x+=Math.sin(this.time*90)*.12*(2.6-n.catT),this.camera.position.y+=Math.cos(this.time*77)*.07*(2.6-n.catT),this.camera.fov-=3)',
    '', "noShake")

# 6) hud catapult kapali
rep('catapult:s.catT<3,', 'catapult:!1,', "hudCat")

# 7) pull-up uyari: kalkis fazinda bastir
rep('e.altitude<85&&!e.catapult?', 'e.altitude<85&&e.phase!=="takeoff"?', "pullupCond")

# 8) mat malzeme: cam-mavi yansima yerine askeri gri
rep('this.dark=this.material(new aa({color:"#192630",metalness:.62,roughness:.53})),this.steel=this.material(new aa({color:"#697d89",metalness:.78,roughness:.36,map:this.panel})),this.pale=this.material(new aa({color:"#ccd4d4",metalness:.48,roughness:.36}))',
    'this.dark=this.material(new aa({color:"#232f38",metalness:.3,roughness:.7})),this.steel=this.material(new aa({color:"#77878f",metalness:.34,roughness:.62,map:this.panel})),this.pale=this.material(new aa({color:"#c8cfce",metalness:.28,roughness:.55}))',
    "matte")

# 9) badge
c = s.count("3.37 DEV")
if c < 2:
    print("FAIL badge", c); sys.exit(1)
s = s.replace("3.37 DEV", "3.38 DEV")
print("ok badge x", c)

io.open(P, "w", encoding="utf-8").write(s)
print("v63 size", len(s))
