#!/usr/bin/env python3
# v3.24 — araziye flat-pad carving: tesisler duz zeminde, gercek olcek hissi
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v48.py"], cwd="/home/user", capture_output=True, text=True)
print("v48:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

# 1) PK: pad kayitlari (airfield=92, refinery=93, radar=94)
rep('if(id%2)out.push([CX*.45+(sd%2?1400:-1400),CZ+2100,2400,26+(id%4)*6,91]);return out}',
    'if(id%2)out.push([CX*.45+(sd%2?1400:-1400),CZ+2100,2400,26+(id%4)*6,91]);const pa=4200+(id%3)*700,po=34+(id%5)*7;const pd=(px,pz,pr,pc)=>{const dw=px-CX,dE=pz-CZ,xx=Math.sqrt((dw/pa)**2+(dE/(pa*.75))**2),L=Math.sin(dw*.007+id)*.19+Math.sin(dE*.012+dw*.004)*.13+Math.sin(dw*.025-dE*.019)*.035;out.push([px,pz,pr,Math.max(10,(1-xx+L)*po),pc])};pd(CX+500,CZ+800,1000,92);pd(CX-800,CZ+200,450,93);pd(CX-100,CZ-500,220,94);return out}',"pkPads")

# 2) buildIslands: pad'leri mesh olarak cizme, ayri listede tut
rep('Pal=a;PK(e).forEach(([o,c,u,f],b)=>this.createIsland(o,c,u,f,b));',
    'Pal=a;this.pkPads=PK(e).filter(q=>q[4]>=92);PK(e).filter(q=>q[4]<92).forEach(([o,c,u,f],b)=>this.createIsland(o,c,u,f,b));',"buildFilter")

# 3) createIsland: cozunurluk + pad duzlestirme
rep('createIsland(e,n,a,o,c){const u=new qi(a*2,a*2,60,60);',
    'createIsland(e,n,a,o,c){const u=new qi(a*2,a*2,96,96);',"meshRes")
rep('f.setY(b,Math.max(-12,(1-x+L)*o))}u.computeVertexNormals();',
    'let F=Math.max(-12,(1-x+L)*o);for(const q of(this.pkPads||[])){const dx=w+e-q[0],dE=E+n-q[1],dd=Math.sqrt(dx*dx+dE*dE);if(dd<q[2]){const k=dd/q[2],s2=k<.75?0:((k-.75)/.25)*((k-.75)/.25)*(3-2*((k-.75)/.25));F=q[3]+(F-q[3])*s2}}f.setY(b,F)}u.computeVertexNormals();',"meshFlat")

# 4) terr: pad'leri tepe olarak sayma + duzlestirme
rep('terr(e,n){let t=0;for(const[d,p,g,o,c]of(this.peaks||(this.peaks=PK(this.mission.id||0)))){',
    'terr(e,n){let t=0;const PKL=(this.peaks||(this.peaks=PK(this.mission.id||0)));for(const[d,p,g,o,c]of PKL)if(c<92){',"terrSkip")
rep('-3)}}return t}',
    '-3)}}for(const q of PKL)if(q[4]>=92){const w2=e-q[0],E2=n-q[1],dd=Math.sqrt(w2*w2+E2*E2);if(dd<q[2]){const k=dd/q[2],s2=k<.75?0:((k-.75)/.25)*((k-.75)/.25)*(3-2*((k-.75)/.25));t=q[3]+(t-q[3])*s2}}return t}',"terrFlat")

# 5) spawn: kara hedefleri pad'lere oturur
rep('.find(x=>x[4]===90)',
    '.find(x=>x[4]===(lk?(c==="airfield"?92:c==="refinery"?93:94):90))',"padFind")
rep('LP[1]+((u%3)-1)*620',
    'LP[1]+(((u*77)%3)-1)*LP[2]*(c==="airfield"?0:.35)',"padP")
rep('LP[0]+(u-3)*480',
    'LP[0]+(((u*131)%3)-1)*LP[2]*(c==="airfield"?0:.45)',"padD")
rep('const gy=lk||lb2?Math.max(3,this.terr(d,p)+1.5):g;',
    'const gy=lk?LP[3]+1.5:lb2?Math.max(3,this.terr(d,p)+1.5):g;',"padGy")

rep('dn.push({id:200,name:"SON DALGA",season:3,chapter:0,kind:"waves",targets:["interceptor","heavy","interceptor"],briefing:["The last push of the season. Endless waves until the horn — hold the line.","Sezonun son taarruzu. Boruya kadar bitmeyen dalgalar — hattı tut."],reward:2100,limit:390,par:260});',
    'dn.push({id:200,name:"SON DALGA",season:3,chapter:0,kind:"waves",targets:["interceptor","heavy","interceptor"],briefing:["The last push of the season. Endless waves until the horn — hold the line.","Sezonun son taarruzu. Boruya kadar bitmeyen dalgalar — hattı tut."],reward:2100,limit:390,par:260});dn.push({id:201,name:"KÖPRÜ AVI",season:3,chapter:3,kind:"raid",targets:["bridge","bridge","radar","interceptor","interceptor"],briefing:["Two bridges feed the coastal front. Drop both, then silence the radar watching the strait.","İki köprü kıyı hattını besliyor. İkisini indir, sonra boğazı gözleyen radarı sustur.","Zwei Brücken versorgen die Front. Beide sprengen, dann das Radar ausschalten.","Dos puentes alimentan el frente. Derríbalos y luego el radar.","Deux ponts alimentent le front. Détruisez-les, puis le radar.","Due ponti riforniscono il fronte. Abbattili, poi il radar.","Duas pontes alimentam a frente. Derrube-as e depois o radar.","Два моста питают фронт. Уничтожь оба, затем радар.","Dua jembatan memasok garis depan. Hancurkan keduanya, lalu radar.","جسران يغذيان الجبهة. دمّرهما ثم الرادار."],reward:2200,limit:420});',
    "bridgeMission")

rep('if(!Rl(d,s.records)&&d!==Ddaily()&&d!==192)return;',
    'if(!Rl(d,s.records)&&d!==Ddaily()&&d!==192&&!(d>=193))return;',"deployUnlock")

# 6) rozet
c24=s.count("3.23 DEV")
if c24<2:
    print("FAIL badge",c24); sys.exit(1)
s=s.replace("3.23 DEV","3.24 DEV")
print("ok badge x",c24)

io.open(P,"w",encoding="utf-8").write(s)
print("v49 size",len(s))
