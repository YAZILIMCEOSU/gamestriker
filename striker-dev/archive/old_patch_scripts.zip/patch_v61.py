#!/usr/bin/env python3
# v3.36 — FAZ M: ORTAM GORSEL PAKETI (referans seviye 3): buyuk/yumusak patlamalar +
# gokyuzunde iri kume bulutlar. Yalnizca renderer/sky-shader — motor mantigina dokunmaz.
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v60.py"], cwd="/home/user", capture_output=True, text=True)
print("v60:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag):
    global s
    c = s.count(old)
    if c != 1:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

# 1) patlamalar: daha buyuk flash + daha cok/buyuk duman ve ates halkasi
rep('this.flash.intensity=500+(a.size||20)*52,this.particles.emit(a.position,new H(0,26,0),26,4,"#2b2f31",!0),this.particles.emit(a.position,new H(0,14,0),18,3,"#41484c",!0),(()=>{for(let q=0;q<10;q++)this.particles.emit(a.position,new H(Math.cos(q*.628)*52,4,Math.sin(q*.628)*52),34,2.4,"#ffb46b",!0)})()',
    'this.flash.intensity=800+(a.size||20)*85,this.particles.emit(a.position,new H(0,34,0),34,6,"#2b2f31",!0),this.particles.emit(a.position,new H(0,20,0),24,4.5,"#41484c",!0),this.particles.emit(a.position,new H(0,12,0),16,3.5,"#5a6166",!0),(()=>{for(let q=0;q<14;q++)this.particles.emit(a.position,new H(Math.cos(q*.449)*70,5,Math.sin(q*.449)*70),44,3.2,"#ffb46b",!0)})()',
    "bigBoom")

# 2) gokyuzu: iri, yumusak kume bulutlar
rep('vec2 uv=dir.xz/(dir.y+.16)*1.65+vec2(uTime*.0015,0.0);\n            float n=fbm(uv+fbm(uv*1.9)*.55);\n            float cloud=smoothstep(.46,.73,n)*smoothstep(.015,.15,dir.y);',
    'vec2 uv=dir.xz/(dir.y+.16)*1.25+vec2(uTime*.0015,0.0);\n            float n=fbm(uv+fbm(uv*1.7)*.62);\n            float cloud=smoothstep(.44,.72,n)*smoothstep(.012,.14,dir.y);',
    "bigClouds")

rep('col=mix(col,vec3(.86,.85,.81),wisps*.18);',
    'col=mix(col,vec3(.86,.85,.81),wisps*.26);',
    "wisps")

# 3) badge
c = s.count("3.35 DEV")
if c < 2:
    print("FAIL badge", c); sys.exit(1)
s = s.replace("3.35 DEV", "3.36 DEV")
print("ok badge x", c)

io.open(P, "w", encoding="utf-8").write(s)
print("v61 size", len(s))
