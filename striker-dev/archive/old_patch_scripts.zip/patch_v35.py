#!/usr/bin/env python3
# v3.15 DEV — P5 magazaya derinlik: ucak basina ZIRH ve AVIYONIK yukseltme hatlari
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v34.py"], cwd="/home/user", capture_output=True, text=True)
print("v34:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag, count=1):
    global s
    c = s.count(old)
    if c != count:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

# 1) motor hattina ek: zirh + aviyonik etkileri
rep('this.dmgMul=q5&&q5.wdmg?1.5:1,q5&&q5.wbomb&&(this.bombs+=2),q5&&q5.wflr&&(this.flares+=2)',
    'this.dmgMul=q5&&q5.wdmg?1.5:1,q5&&q5.wbomb&&(this.bombs+=2),q5&&q5.wflr&&(this.flares+=2),q5&&q5.upA&&(this.health+=18*q5.upA),q5&&q5.upV&&(this.flares+=q5.upV,this.bombs+=q5.upV)',
    "upEffects")
# 2) Ce cagrisi yeni hatlari tasisin
rep('new Pa(dn[d],s.aircraft,s.preferences,s.upgrades[s.aircraft]||0,s.shopW||{})',
    'new Pa(dn[d],s.aircraft,s.preferences,s.upgrades[s.aircraft]||0,{...(s.shopW||{}),upA:(s.upgA||{})[s.aircraft]||0,upV:(s.upgV||{})[s.aircraft]||0})',
    "cePass")
# 3) normalizer
rep('shopW:u.shopW&&typeof u.shopW==="object"?u.shopW:{},',
    'shopW:u.shopW&&typeof u.shopW==="object"?u.shopW:{},upgA:u.upgA&&typeof u.upgA==="object"?u.upgA:{},upgV:u.upgV&&typeof u.upgV==="object"?u.upgV:{},',
    "normUpg")
# 4) taze kayit varsayilanlari
rep('dailyHistory:[],preferences:', 'dailyHistory:[],stats:{m:0,w:0,sp:0},upgA:{},upgV:{},preferences:', "freshSave")
# 5) onShop: upA/upV satin alim
rep('const WP={wdmg:2500,wbomb:1800,wflr:1200};',
    'if(k==="upA"||k==="upV"){const M=k==="upA"?"upgA":"upgV",cur=(z[M]||{})[z.aircraft]||0,cost=450*(cur+1);if(cur>=3||z.credits<cost)return z;return{...z,credits:z.credits-cost,[M]:{...(z[M]||{}),[z.aircraft]:cur+1}}}const WP={wdmg:2500,wbomb:1800,wflr:1200};',
    "shopUpg")
# 6) hangar'a iki yeni yukseltme butonu
rep('children:[S.jsx(nb,{size:14}),S.jsx("span",{children:p>=3?f("maxUpgrade"):`${f("upgrade")} / ${450*(p+1)}`}),S.jsx("span",{className:"upgrade-pips",children:[1,2,3].map(v=>S.jsx("i",{className:v<=p?"filled":""},v))})]})',
    'children:[S.jsx(nb,{size:14}),S.jsx("span",{children:p>=3?f("maxUpgrade"):`${f("upgrade")} / ${450*(p+1)}`}),S.jsx("span",{className:"upgrade-pips",children:[1,2,3].map(v=>S.jsx("i",{className:v<=p?"filled":""},v))})]}),'
    'S.jsxs("button",{className:"upgrade-button",onClick:()=>qt("upA"),disabled:((s.upgA||{})[e]||0)>=3||s.credits<450*(((s.upgA||{})[e]||0)+1),children:[S.jsx("span",{children:f("upgArmor")}),S.jsx("b",{children:((s.upgA||{})[e]||0)>=3?f("maxUpgrade"):450*(((s.upgA||{})[e]||0)+1)})]}),'
    'S.jsxs("button",{className:"upgrade-button",onClick:()=>qt("upV"),disabled:((s.upgV||{})[e]||0)>=3||s.credits<450*(((s.upgV||{})[e]||0)+1),children:[S.jsx("span",{children:f("upgAvio")}),S.jsx("b",{children:((s.upgV||{})[e]||0)>=3?f("maxUpgrade"):450*(((s.upgV||{})[e]||0)+1)})]})',
    "upgButtons")
# 7) i18n
rep('wave:["HOSTILE WAVE INBOUND",',
    'upgArmor:["ARMOR PLATES +18 HULL","ZIRH PLAKALARI +18 GÖVDE","PANZERPLATTEN +18 RUMPF","PLACAS DE BLINDAJE +18 CASCO","PLAQUES DE BLINDAGE +18","PIASTRE CORAZZATE +18","PLACAS DE BLINDAGEM +18","БРОНЕПЛИТЫ +18 КОРПУС","PELAT BAJA +18 LAMBUNG","صفائح درع +18"],'
    'upgAvio:["AVIONICS +1 FLARE +1 BOMB","AVİYONİK +1 FİŞEK +1 BOMBA","AVIONIK +1 FACKEL +1 BOMBE","AVIÓNICA +1 BENGALA +1 BOMBA","AVIONIQUE +1 LEURRE +1 BOMBE","AVIONICA +1 FLARE +1 BOMBA","AVIÔNICA +1 FLARE +1 BOMBA","АВИОНИКА +1 ЛОВУШКА +1 БОМБА","AVIONIK +1 SUAR +1 BOM","إلكترونيات طيران +1 شعال +1 قنبلة"],'
    'wave:["HOSTILE WAVE INBOUND",', "i18nP5")

io.open(P, "w", encoding="utf-8").write(s)
print("v35 size", len(s))
