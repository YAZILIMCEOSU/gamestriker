#!/usr/bin/env python3
# v3.35 — FAZ L: KONTROL PAKETI (referans seviye 2): dikey hex gaz kolu (% gorevli, drag),
# BOOST hex butonu, coarse-pointer'de hex silah butonlari. Masaustu düzen korunur.
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v59.py"], cwd="/home/user", capture_output=True, text=True)
print("v59:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag):
    global s
    c = s.count(old)
    if c != 1:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

# 1) dikey gaz kolu
rep('S.jsxs("div",{className:"throttle-control",children:[S.jsx("span",{children:o("throttle")}),S.jsx("input",{"aria-label":o("throttle"),type:"range",min:"0",max:"100",value:Math.round(a.current.throttle*100),onChange:b=>{a.current.throttle=Number(b.target.value)/100}}),S.jsxs("b",{children:[Math.round(a.current.throttle*100),S.jsx("small",{children:"%"})]})]})',
    'S.jsxs("div",{className:"throttle-control",children:[S.jsxs("b",{className:"vthr-pct",children:[Math.round(a.current.throttle*100),S.jsx("small",{children:"%"})]}),S.jsx("div",{className:"vthr-track",onPointerDown:b=>{try{b.currentTarget.setPointerCapture(b.pointerId)}catch(_){}const r=b.currentTarget.getBoundingClientRect();a.current.throttle=Math.max(0,Math.min(1,1-(b.clientY-r.top)/r.height))},onPointerMove:b=>{if(b.pressure>0||b.buttons){const r=b.currentTarget.getBoundingClientRect();a.current.throttle=Math.max(0,Math.min(1,1-(b.clientY-r.top)/r.height))}},children:[S.jsx("div",{className:"vthr-fill",style:{height:Math.round(a.current.throttle*100)+"%"}}),S.jsx("div",{className:"vthr-knob",style:{bottom:Math.round(a.current.throttle*100)+"%"}})]}),S.jsx("span",{children:o("throttle")})]})',
    "vthrottle")

# 2) BOOST hex butonu
rep('(!e.tut)&&S.jsxs("div",{className:"aux-weapons"',
    'S.jsx("button",{className:"weapon boost-button",onPointerDown:()=>{a.current.boost=!0},onPointerUp:()=>{a.current.boost=!1},onPointerCancel:()=>{a.current.boost=!1},onLostPointerCapture:()=>{a.current.boost=!1},children:S.jsx("span",{children:"BOOST"})}),(!e.tut)&&S.jsxs("div",{className:"aux-weapons"',
    "boostBtn")

# 3) CSS
rep('@media (max-width:820px){.obj-banner{left:12px;top:8px;font-size:7px;padding:5px 9px}}\n</style>',
    '@media (max-width:820px){.obj-banner{left:12px;top:8px;font-size:7px;padding:5px 9px}}\n.throttle-control{height:auto;gap:6px}\n.vthr-pct{font-family:var(--mono);font-size:12px;font-weight:700;color:#bfe4f3;letter-spacing:.08em}\n.vthr-pct small{font-size:7px;opacity:.7;margin-left:2px}\n.vthr-track{pointer-events:auto;position:relative;width:30px;height:120px;background:rgba(13,30,39,.78);border:1px solid rgba(120,170,190,.35);clip-path:polygon(50% 0,100% 10%,100% 90%,50% 100%,0 90%,0 10%);touch-action:none;cursor:ns-resize}\n.vthr-fill{position:absolute;left:0;right:0;bottom:0;background:linear-gradient(180deg,rgba(79,163,199,.75),rgba(29,74,92,.75))}\n.vthr-knob{position:absolute;left:50%;width:22px;height:12px;transform:translate(-50%,50%);background:linear-gradient(180deg,#8fc7dd,#4fa3c7);border-radius:3px;box-shadow:0 2px 6px rgba(0,0,0,.5)}\n.boost-button{justify-content:center;background:rgba(29,74,92,.5);border-color:#4fa3c7}\n.boost-button>span{letter-spacing:.2em;color:#bfe4f3}\n@media (pointer:coarse){.weapon{clip-path:polygon(12px 0,calc(100% - 12px) 0,100% 50%,calc(100% - 12px) 100%,12px 100%,0 50%);border-radius:0}.virtual-stick{border-radius:24px;clip-path:polygon(25% 0,75% 0,100% 50%,75% 100%,25% 100%,0 50%)}.boost-button{display:flex}}\n.boost-button{display:none}\n@media (pointer:coarse){.boost-button{display:flex}}\n</style>',
    "ctlCss")

# 4) badge
c = s.count("3.34 DEV")
if c < 2:
    print("FAIL badge", c); sys.exit(1)
s = s.replace("3.34 DEV", "3.35 DEV")
print("ok badge x", c)

io.open(P, "w", encoding="utf-8").write(s)
print("v60 size", len(s))
