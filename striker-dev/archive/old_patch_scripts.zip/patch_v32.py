#!/usr/bin/env python3
# v3.12 DEV — Katapult İPTAL: havada başlangıç (air-start) + sorti çağrısı
# Aynı iskelet: sadece spawn/katapult dalları ve i18n rozet değişir.
import io, sys, subprocess

# once v3.11 zincirini icer.html'den taze uret (ayni iskelet, tekrur uretilebilir)
r = subprocess.run([sys.executable, "striker-dev/patch_v31.py"], cwd="/home/user",
                   capture_output=True, text=True)
print(r.stdout.strip().splitlines()[-1] if r.stdout else "", r.stderr[-200:])
if r.returncode != 0:
    sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()
n0 = len(s)

def rep(old, new, tag, count=1):
    global s
    c = s.count(old)
    if c != count:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

# 1) Spawn: güverte y=17 -> havada 260 m (z aynı kalsın: düşman geometrisi bozulmasin)
rep("player=new H(0,17,1150)", "player=new H(0,260,1150)", "spawnAlt")
# 2) catT 0 -> 9: tum catT< dallari (kilit, sarsinti, gverte tutusu, oto-tirmanma) devre disi
rep("entities=[];catT=0;", "entities=[];catT=9;", "catT9")
# 3) Baslangic hizi 0 -> 140 m/s (stall yok)
rep("bank=0;speed=0;health", "bank=0;speed=140;health", "speed140")
# 4) Katapult toast -> sorti cagrisi
rep('this.notify("catapult",3)', 'this.notify("sortie",4)', "sortieNotify")
# 5) i18n: sortie anahtari (10 dil), catapult onune ekle
rep('catapult:["CATAPULT LAUNCH"',
    'sortie:["SORTIE — weapons free","SORTİ — silahlar serbest","EINSATZ — Feuer frei",'
    '"SALIDA — fuego libre","SORTIE — feu à volonté","SORTITA — fuoco libero","SORTIE — fogo livre",'
    '"ВЫЛЕТ — оружие свободно","SORTI — senjata bebas","طلعة — الأسلحة حرة"],catapult:["CATAPULT LAUNCH"',
    "i18nSortie")
# 6) Sifir-girdi emniyeti: ilk 6 sn oto-tirmanma tabani (catT yerine time)
rep("this.catT<6&&(this.pitch=Math.max(this.pitch", "this.time<6&&(this.pitch=Math.max(this.pitch", "climbGuard")
# 7) Rozet 3.11 -> 3.12 (build tuplu icindeki tum diller)
c = s.count("3.11 DEV")
if c < 2:
    print("FAIL badge", c); sys.exit(1)
s = s.replace("3.11 DEV", "3.12 DEV")
print("ok badge x", c)

io.open(P, "w", encoding="utf-8").write(s)
print("size", n0, "->", len(s))
