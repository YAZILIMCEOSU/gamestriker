P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old); assert n==1, f"count {n}: {old[:70]}"
    s=s.replace(old,new)

# 1) context lost: do NOT open the error state; just stop drawing (three.js skips draws while lost)
rep('const ft=I=>{I.preventDefault(),y(!0),x(!0)};',
    'const ft=I=>{I.preventDefault(),window.__ctxLost=!0};')

# 2) context restored: recover automatically instead of a dead "reload required" screen
rep('const Ct=()=>{window.__showBoot&&window.__showBoot(\"webgl context restored - reload required\")};',
    'const Ct=()=>{setTimeout(()=>window.location.reload(),300)};')

assert s.count('3.53 DEV')==2
s=s.replace('3.53 DEV','3.54 DEV')
open(P,'w',encoding='utf-8').write(s); print('v80 ok', len(s))
