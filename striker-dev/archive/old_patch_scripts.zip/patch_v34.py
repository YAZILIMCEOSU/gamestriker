#!/usr/bin/env python3
# v3.14 DEV — P4 grafik: buyuk patlamalar, hasar vinyeti, sinematik renk katmani, dusman dumanı (hooksTick icinde v33'te)
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v33.py"], cwd="/home/user", capture_output=True, text=True)
print("v33:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag, count=1):
    global s
    c = s.count(old)
    if c != count:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

# 1) patlama boyutlari buyuyor
rep('this.event("explosion",e.position,e.kind==="carrier"?65:e.airborne?19:35)',
    'this.event("explosion",e.position,e.kind==="carrier"?80:e.airborne?26:48)', "boomSize")
rep('this.event("explosion",this.player,28)', 'this.event("explosion",this.player,34)', "boomPlayer")
# 2) HUD vinyet + sinematik gradyan katmani
rep('children:[S.jsxs("div",{className:"flight-top",',
    'children:[S.jsx("div",{className:"dmg-vignette",style:{opacity:e.health<45?Math.min(.85,(45-e.health)/45*.9):0}}),S.jsx("div",{className:"grade-overlay"}),S.jsxs("div",{className:"flight-top",',
    "vignette")
# 3) CSS
rep('.flight-hud{pointer-events:none;color:var(--hud);font-family:var(--mono)',
    '.dmg-vignette{position:absolute;inset:0;pointer-events:none;background:radial-gradient(ellipse at center,transparent 52%,rgba(255,42,24,.6) 100%);z-index:6;transition:opacity .25s}.grade-overlay{position:absolute;inset:0;pointer-events:none;background:linear-gradient(180deg,rgba(24,64,88,.12),transparent 32%,transparent 68%,rgba(255,146,64,.10));z-index:5}.flight-hud{pointer-events:none;color:var(--hud);font-family:var(--mono)',
    "css")

io.open(P, "w", encoding="utf-8").write(s)
print("v34 size", len(s))
