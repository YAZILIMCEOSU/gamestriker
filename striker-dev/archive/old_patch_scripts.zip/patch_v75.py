p = '/home/user/striker-dev/index.html'
s = open(p, encoding='utf-8').read()


def rep(old, new):
    global s
    n = s.count(old)
    assert n == 1, (n, old[:100])
    s = s.replace(old, new)


# 1) i18n: rütbe "ACE" ve puan etiketi (10 dil)
rep('rookie:["FLIGHT OFFICER",',
    'ace:["ACE","AS","ASS","AS","AS","ASSO","ÁS","АС","ACE","آس"],pts:["PTS","PUAN","PKT","PTS","PTS","PT","PTS","ОЧК","PTS","نقطة"],rookie:["FLIGHT OFFICER",')

# 2) Yerel pilot istatistiği: puan = kayıtların en iyi skor toplamı; rütbe eşikleri
rep('function kw({language:s,onStart:e,onControls:n}){',
    'function pilotStats(sv){const pts=Object.values(sv.records||{}).reduce((q,r)=>q+((r&&Number.isFinite(r.score))?r.score:0),0);const key=pts>=5000?"ace":pts>=1500?"pilot":"rookie";return{pts:Math.round(pts),key}}function kw({language:s,onStart:e,onControls:n}){')

# 3) Ana sayfadaki oyuncu düğmesi: rütbe + puan
rep('children:[s.callsign,S.jsx("small",{children:u("rookie")})]',
    'children:[s.callsign,S.jsx("small",{children:(()=>{const q=pilotStats(s);return u(q.key)+" · "+q.pts.toLocaleString()+" "+u("pts")})()})]')

s = s.replace('3.74 DEV', '3.75 DEV')
open(p, 'w', encoding='utf-8').write(s)
print('ok')
