#!/usr/bin/env python3
# v3.14 DEV — oyun zevki turu: gorev director (3-5 dk + surprizler), pro magazasi,
# ucak kartlari, geri cagirma bildirimi, dunya siralamasi + ilerleme rehberi
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v37.py"], cwd="/home/user", capture_output=True, text=True)
print("v37:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag, count=1):
    global s
    def bal(t):
        d=0;b=0;q=0;in_s=None;esc=False
        for ch in t:
            if in_s:
                if esc:esc=False
                elif ch=='\\':esc=True
                elif ch==in_s:in_s=None
                continue
            if ch in '"\'':in_s=ch
            elif ch=='`':in_s='`'
            elif ch=='(':d+=1
            elif ch==')':d-=1
            elif ch=='{':b+=1
            elif ch=='}':b-=1
            elif ch=='[':q+=1
            elif ch==']':q-=1
        return (d,b,q)
    if bal(old)!=bal(new):
        print("FAIL BAL",tag,bal(old),bal(new));import sys;sys.exit(1)
    c = s.count(old)
    if c != count:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

def slice_rep(start_marker, end_marker, new, tag, keep_end=0):
    global s
    i = s.find(start_marker)
    j = s.find(end_marker, i + 10)
    if i < 0 or j < 0:
        print("FAIL slice", tag, i, j); sys.exit(1)
    j += len(end_marker) - keep_end
    s = s[:i] + new + s[j:]
    print("ok slice", tag)

DM = "[.85,1,1.2,1.45,1.75][this.di]"

# ---------- Q1: director ----------
rep('this.alive.length===0&&!["race","chain","waves"].includes(this.mission.kind)&&(this.phase="return",',
    'this.alive.length===0&&!["race","chain","waves"].includes(this.mission.kind)&&(this.ext||this.time>=140||this.mission.kind==="escort")&&(this.phase="return",',
    "minLen")
rep(':(this.frenzyT=20,this.notify("frenzy",6)));',
    ':Math.random()<.5?((D2=>{this.entities.push({id:520,kind:"interceptor",position:new H(this.player.x+320,210,this.player.z+650),origin:new H(this.player.x+320,210,this.player.z+650),heading:.2,hp:130*D2,maxHp:130*D2,radius:22,fireIn:6,phase:1,airborne:!0},{id:521,kind:"interceptor",position:new H(this.player.x-320,210,this.player.z+650),origin:new H(this.player.x-320,210,this.player.z+650),heading:.2,hp:130*D2,maxHp:130*D2,radius:22,fireIn:7,phase:2,airborne:!0})})(' + DM + '),this.notify("ambush",5)):Math.random()<.5?(this.vipId=530,this.vipT=45,(D3=>{this.entities.push({id:530,kind:"attacker",position:new H(this.player.x,230,this.player.z-1600),origin:new H(this.player.x,230,this.player.z-1600),heading:.2,hp:260*D3,maxHp:260*D3,radius:24,fireIn:9,phase:0,airborne:!0})})(' + DM + '),this.notify("vip",5)):(this.frenzyT=20,this.notify("frenzy",6)));',
    "surprise")
rep('for(const q of this.alive)if(q.airborne&&q.hp<q.maxHp*.45&&Math.random()<.35)this.event("damage",q.position,.8)}',
    'if(this.vipT>0){this.vipT-=a;const vq=this.entities.find(q=>q.id===this.vipId);if(vq&&vq.hp<=0&&!this.vipDone){this.vipDone=!0;this.score+=400;this.notify("vipdown",3)}}'
    'if(!this.ext&&M!=="race"&&M!=="chain"&&M!=="waves"&&M!=="escort"&&this.alive.length===0&&this.time<140&&!this.result){this.ext=1;for(let i=0;i<3;i++){const x=this.player.x+(i-1)*380,z=this.player.z-1400-i*240,hp=130*diM;this.entities.push({id:540+i,kind:i===2?"heavy":"interceptor",position:new H(x,200,z),origin:new H(x,200,z),heading:.2,hp:hp,maxHp:hp,radius:i===2?26:22,fireIn:8+i,phase:i,airborne:!0})}this.notify("reinforce",4)}'
    'for(const q of this.alive)if(q.airborne&&q.hp<q.maxHp*.45&&Math.random()<.35)this.event("damage",q.position,.8)}',
    "director")

# ---------- Q2: pro magazasi (slice) ----------
SHOP_START = 'S.jsxs("div",{style:{display:"flex",gap:8,flexWrap:"wrap",alignItems:"center",margin:"0 0 12px",padding:"10px 12px",border:"1px solid #35525e",borderRadius:10,background:"rgba(17,38,49,.55)"},children:[S.jsx("strong",{style:{letterSpacing:".08em"},children:f("shop")})'
SHOP_END = 'f("upgAvio")}),S.jsx("b",{children:((s.upgV||{})[e]||0)>=3?f("maxUpgrade"):450*(((s.upgV||{})[e]||0)+1)})]})]}'
NEW_SHOP = ('S.jsxs("div",{className:"store-panel",children:[S.jsx("strong",{className:"store-title",children:f("shop")}),S.jsx("div",{className:"store-grid",children:[\n'
 'S.jsxs("div",{className:"store-col",children:[S.jsx("h4",{children:f("catPacks")}),S.jsxs("button",{className:"store-card",disabled:s.shopPack===GdDaystr(),onClick:()=>qt("pack"),children:[S.jsx("b",{children:f("packDaily")}),S.jsx("i",{children:s.shopPack===GdDaystr()?f("claimed"):"+750"})]}),S.jsxs("button",{className:"store-card",disabled:s.shopWeek===Math.floor(Date.now()/6048e5),onClick:()=>qt("week"),children:[S.jsx("b",{children:f("packWeekly")}),S.jsx("i",{children:s.shopWeek===Math.floor(Date.now()/6048e5)?f("claimed"):"+3000"})]})]}),\n'
 'S.jsxs("div",{className:"store-col",children:[S.jsx("h4",{children:f("catWeap")}),[["wdmg",2500,"wDmg"],["wbomb",1800,"wBomb"],["wflr",1200,"wFlr"]].map(w=>S.jsxs("button",{className:"store-card",disabled:!!(s.shopW||{})[w[0]]||s.credits<w[1],onClick:()=>qt(w[0]),children:[S.jsx("b",{children:f(w[2])}),S.jsx("i",{children:(s.shopW||{})[w[0]]?f("claimed"):w[1]})]},w[0]))]}),\n'
 'S.jsxs("div",{className:"store-col",children:[S.jsx("h4",{children:f("catUpg")}),S.jsxs("button",{className:"store-card",onClick:()=>qt("upA"),disabled:((s.upgA||{})[e]||0)>=3||s.credits<450*(((s.upgA||{})[e]||0)+1),children:[S.jsx("b",{children:f("upgArmor")}),S.jsx("i",{children:((s.upgA||{})[e]||0)>=3?f("maxUpgrade"):450*(((s.upgA||{})[e]||0)+1)})]}),S.jsxs("button",{className:"store-card",onClick:()=>qt("upV"),disabled:((s.upgV||{})[e]||0)>=3||s.credits<450*(((s.upgV||{})[e]||0)+1),children:[S.jsx("b",{children:f("upgAvio")}),S.jsx("i",{children:((s.upgV||{})[e]||0)>=3?f("maxUpgrade"):450*(((s.upgV||{})[e]||0)+1)})]})]}),\n'
 'S.jsxs("div",{className:"store-col",children:[S.jsx("h4",{children:f("catSup")}),S.jsxs("button",{className:"store-card ad-card",disabled:adT>0||(s.adsDate===GdDaystr()&&(s.adsCount||0)>=3),onClick:()=>{setAdT(5);setTimeout(()=>{qt("ad");setAdT(0)},5000)},children:[S.jsx("b",{children:f("adWatch")}),S.jsx("i",{children:adT>0?adT+" SN":(s.adsDate===GdDaystr()?Math.max(0,3-(s.adsCount||0))+"/3":"3/3")})]})]})\n'
 ']})]}')
slice_rep(SHOP_START, SHOP_END, NEW_SHOP, "store")

# ---------- Q3: ucak kartlari ----------
AC_START = 'S.jsx("div",{className:"aircraft-selector",children:no.map((v,y)=>S.jsxs("button",{className:e===v.id?"aircraft-choice active":"aircraft-choice",onClick:()=>n(v.id),children:[S.jsxs("span",{className:"aircraft-choice-index",children:["0",y+1]}),S.jsx(Hw,{id:v.id}),S.jsxs("span",{children:[v.code,S.jsx("strong",{children:v.name})]}),s.owned.includes(v.id)?S.jsx(qs,{size:14}):S.jsx(Ou,{size:14})]},v.id))})'
AC_NEW = ('S.jsx("div",{className:"aircraft-selector",children:no.map((v,y)=>S.jsxs("button",{className:e===v.id?"aircraft-choice active":"aircraft-choice",onClick:()=>n(v.id),children:[S.jsxs("span",{className:"aircraft-choice-index",children:["0",y+1]}),S.jsx(Hw,{id:v.id}),S.jsxs("span",{className:"ac-main",children:[v.code,S.jsx("strong",{children:v.name}),S.jsx("span",{className:"ac-bars",children:[["SPD",v.speed/600],["ARM",v.hull/170],["MSL",v.missiles/16]].map(b=>S.jsx("i",{style:{width:Math.max(8,Math.round(b[1]*100))+"%"}},b[0]))})]}),e===v.id?S.jsx("em",{className:"ac-sel",children:f("selTag")}):s.owned.includes(v.id)?S.jsx(qs,{size:14}):S.jsx(Ou,{size:14})]},v.id))})')
rep(AC_START, AC_NEW, "acCards")

# ---------- Q4: geri cagirma ----------
rep('S.jsx("button",{className:"daily-sortie-btn",style:{display:"block",margin:"8px auto 0",padding:"11px 22px",border:"1px solid #ff7561",',
    '(Date.now()-(s.lastSeen||0)>216e5&&s.lastGift!==GdDaystr())?S.jsx("button",{className:"daily-sortie-btn",style:{display:"block",margin:"8px auto 0",padding:"11px 22px",border:"1px solid #a4e1f1",borderRadius:"10px",background:"linear-gradient(180deg,#1d4a5c,#12303c)",color:"#d8f4ff",fontWeight:700,letterSpacing:".08em",cursor:"pointer",fontSize:"13px"},onClick:()=>onGift("idle"),children:c("idleTitle")}):null,S.jsx("button",{className:"daily-sortie-btn",style:{display:"block",margin:"8px auto 0",padding:"11px 22px",border:"1px solid #ff7561",',
    "welcomeCard")
rep('function jw({save:s,onMission:e}){', 'function jw({save:s,onMission:e,onGift}){', "jwProp")
rep('S.jsx(jw,{save:s,onMission:', 'S.jsx(jw,{save:s,onGift:k=>e(z=>{if(k==="idle"){const t=GdDaystr();if(z.lastGift===t||Date.now()-(z.lastSeen||0)<216e5)return z;return{...z,credits:z.credits+300,lastGift:t}}return z}),onMission:', "jwCall")
rep('pt.useEffect(()=>{if(typeof location<"u"&&(/[?&]demo/',
    'pt.useEffect(()=>{e(z=>({...z,lastSeen:Date.now()}))},[]);pt.useEffect(()=>{if(typeof Notification!=="u"&&Notification.permission==="granted"&&s.daily?.date!==GdDaystr())try{new Notification("STRIKER",{body:"Günlük ikmal hazır · daily supply ready"})}catch(_){}});pt.useEffect(()=>{if(typeof location<"u"&&(/[?&]demo/',
    "lastSeenEffect")
rep('stats:u.stats&&typeof u.stats==="object"?u.stats:{m:0,w:0,sp:0},',
    'stats:u.stats&&typeof u.stats==="object"?u.stats:{m:0,w:0,sp:0},lastSeen:u.lastSeen||0,lastGift:u.lastGift||"",',
    "normIdle")
rep('S.jsxs("span",{className:"credit-balance",children:[S.jsx(YM,{size:15}),s.credits.toLocaleString()]}),',
    'S.jsxs("span",{className:"credit-balance",children:[S.jsx(YM,{size:15}),s.credits.toLocaleString()]}),S.jsx("button",{className:"language-button",title:"Bildirimler / Notifications",onClick:()=>{if(typeof Notification!=="u")Notification.requestPermission().then(p=>{if(p==="granted")try{new Notification("STRIKER",{body:"Bildirimler açık · notifications on"})}catch(_){}})},children:"🔔"}),',
    "bell")

# ---------- Q5+Q6: dunya + rehber ----------
rep('children:c("rank")+" · "+c("sp")+" "+(s.stats?.sp||0)+" · "+c("matches")+" "+(s.stats?.m||0)+" · "+c("wins")+" "+(s.stats?.w||0)})]})]}),',
    'children:c("rank")+" · "+c("sp")+" "+(s.stats?.sp||0)+" · "+c("matches")+" "+(s.stats?.m||0)+" · "+c("wins")+" "+(s.stats?.w||0)}),S.jsx("span",{style:{marginLeft:10,color:"#e8a33d"},children:c("world")+" #"+Math.max(1,25e3-Math.min(24999,(s.stats?.sp||0)*6))+" · "+c("guide")+": "+(dn.find(u=>!s.records[u.id]&&u.id<192)?c("operation")+" "+String(dn.find(u=>!s.records[u.id]&&u.id<192).id+1).padStart(2,"0")+" → "+dn.find(u=>!s.records[u.id]&&u.id<192).name:c("guideUpg"))})]})]}),',
    "worldGuide")

# ---------- CSS ----------
rep('.dmg-vignette{',
    '.store-panel{margin:0 0 14px;padding:14px;border:1px solid #35525e;border-radius:12px;background:rgba(17,38,49,.55)}.store-title{letter-spacing:.12em;font-size:11px;display:block;margin-bottom:10px}.store-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px}.store-col h4{font-size:8px;letter-spacing:.14em;color:#7f95a3;margin:0 0 6px;font-weight:600}.store-card{display:flex;flex-direction:column;gap:6px;align-items:stretch;text-align:left;padding:10px 12px;border:1px solid #3c5a66;border-radius:10px;background:linear-gradient(180deg,#16323e,#10242e);color:#cfe3ee;cursor:pointer;font-size:9px;letter-spacing:.04em}.store-card:hover{border-color:#a4e1f1}.store-card:disabled{opacity:.45;cursor:default}.store-card b{font-size:9px;font-weight:700;letter-spacing:.06em}.store-card i{font-style:normal;color:#ffd1a7;font-family:var(--mono);font-size:10px}.store-card.ad-card{border-color:#e8a33d}.ac-main{display:flex;flex-direction:column;gap:3px;align-items:flex-start}.ac-bars{display:flex;flex-direction:column;gap:2px;width:64px}.ac-bars i{display:block;height:2px;background:#a4e1f1;border-radius:2px}.ac-sel{font-style:normal;color:#06222b;background:#a4e1f1;border-radius:4px;padding:1px 6px;font-size:7px;letter-spacing:.1em;font-weight:700}.dmg-vignette{',
    "css38")

# ---------- i18n ----------
rep('rank:["RANKING",',
    'catPacks:["SUPPLY PACKS","İKMAL PAKETLERİ","NACHSCHUB","PAQUETES","PACKS RAVITAILLEMENT","PACCHETTI","PACOTES","НАБОРЫ","PAKET","حزم إمداد"],'
    'catWeap:["WEAPONS","SİLAHLAR","WAFFEN","ARMAS","ARMES","ARMI","ARMAS","ОРУЖИЕ","SENJATA","أسلحة"],'
    'catUpg:["UPGRADES","YÜKSELTMELER","UPGRADES","MEJORAS","AMÉLIORATIONS","POTENZIAMENTI","MELHORIAS","УЛУЧШЕНИЯ","PENINGKATAN","ترقيات"],'
    'catSup:["SUPPORT","DESTEK","UNTERSTÜTZUNG","APOYO","SOUTIEN","SUPPORTO","APOIO","ПОДДЕРЖКА","DUKUNGAN","دعم"],'
    'selTag:["SELECTED","SEÇİLİ","GEWÄHLT","SELECCIONADO","SÉLECTIONNÉ","SELEZIONATO","SELECIONADO","ВЫБРАН","TERPILIH","محدد"],'
    'ambush:["AMBUSH — hostiles behind you!","PUSU — arkanda düşman!","HINTERHALT — Feinde im Rücken!","EMBOSCADA — ¡enemigos detrás!","EMBUSCADE — ennemis derrière !","IMBOSCATA — nemici alle spalle!","EMBOSCADA — inimigos atrás!","ЗАСАДА — противник сзади!","SERGAPAN — musuh di belakang!","كمين — أعداء خلفك!"],'
    'vip:["HIGH-VALUE TARGET — bonus 400","YÜKSEK DEĞERLİ HEDEF — bonus 400","HOCHWERTIGES ZIEL — Bonus 400","OBJETIVO DE ALTO VALOR — bonus 400","CIBLE DE HAUTE VALEUR — bonus 400","BERSAGLIO ALTO VALORE — bonus 400","ALVO DE ALTO VALOR — bônus 400","ЦЕННАЯ ЦЕЛЬ — бонус 400","TARGET BERHARGA — bonus 400","هدف عالي القيمة — مكافأة 400"],'
    'vipdown:["VIP DESTROYED +400","YDH İMHA +400","VIP ZERSTÖRT +400","VIP DESTRUIDO +400","VIP DÉTRUIT +400","VIP DISTRUTTO +400","VIP ABATIDO +400","ЦЕЛЬ УНИЧТОЖЕНА +400","VIP HANCUR +400","هدف مدمر +400"],'
    'reinforce:["REINFORCEMENTS — hostile relief fleet","TAKVİYE — düşman yardım filosu","VERSTÄRKUNG — feindliche Flotte","REFUERZOS — flota de socorro","RENFORTS — flotte de relève","RINFORZI — flotta di soccorso","REFORÇOS — frota de socorro","ПОДКРЕПЛЕНИЕ — флот противника","BANTUAN — armada musuh","تعزيزات — أسطول نجدة معاد"],'
    'idleTitle:["WELCOME BACK +300","TEKRAR HOŞ GELDİN +300","WILLKOMMEN ZURÜCK +300","BIENVENIDO +300","BON RETOUR +300","BENTORNATO +300","BEM-VINDO +300","С ВОЗВРАЩЕНИЕМ +300","SELAMAT KEMBALI +300","عدت إلينا +300"],'
    'world:["WORLD","DÜNYA","WELT","MUNDO","MONDE","MONDO","MUNDO","МИР","DUNIA","العالم"],'
    'guide:["NEXT GOAL","SIRADAKİ HEDEF","NÄCHSTES ZIEL","OBJETIVO","OBJECTIF","OBIETTIVO","META","ЦЕЛЬ","TARGET","الهدف التالي"],'
    'guideUpg:["upgrade your aircraft","uçağını yükselt","Flugzeug ausbauen","mejora tu avión","améliorez votre avion","potenzia il tuo aereo","melhore sua aeronave","улучши самолёт","tingkatkan pesawatmu","طوّر طائرتك"],'
    'rank:["RANKING",', "i18n38")

# ---------- rozet ----------
c = s.count("3.13 DEV")
if c < 2:
    print("FAIL badge", c); sys.exit(1)
s = s.replace("3.13 DEV", "3.14 DEV")
print("ok badge x", c)

io.open(P, "w", encoding="utf-8").write(s)
print("v38 size", len(s))
