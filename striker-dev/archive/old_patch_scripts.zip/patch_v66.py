import sys
P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old)
    assert n==1, f"anchor count {n}: {old[:60]}"
    s=s.replace(old,new)
# 1) underwing missiles: larger, dropped below wing on a visible pylon
rep('const Q=this.missile();Q.scale.setScalar(.46),Q.position.set(x*(3.5+X*2),-.5,1.4+X*.7),a.add(Q),a.add(this.box([.1,.4,1.1],this.dark,[x*(3.5+X*2),-.22,1.6+X*.7]))',
    'const Q=this.missile();Q.scale.setScalar(.6),Q.position.set(x*(3.5+X*2),-.95,1.4+X*.7),a.add(Q),a.add(this.box([.14,.62,1.1],this.dark,[x*(3.5+X*2),-.6,1.6+X*.7]))')
# 2) badge
n=s.count('3.40 DEV'); assert n>=1, 'badge'
s=s.replace('3.40 DEV','3.41 DEV')
open(P,'w',encoding='utf-8').write(s)
print('v66 ok, badge x',n,'size',len(s))
