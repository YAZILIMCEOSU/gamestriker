#!/usr/bin/env python3
# v3.14b — welcome-back karti: lastSeen efektinden once bayrak yakala
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v38.py"], cwd="/home/user", capture_output=True, text=True)
print("v38:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag, count=1):
    global s
    c = s.count(old)
    if c != count:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

rep('pt.useEffect(()=>{e(z=>({...z,lastSeen:Date.now()}))},[]);',
    'pt.useEffect(()=>{if(typeof window!=="u")window.__idle=Date.now()-(s.lastSeen||0)>216e5&&s.lastGift!==GdDaystr();e(z=>({...z,lastSeen:Date.now()}))},[]);',
    "idleFlag")
rep('(Date.now()-(s.lastSeen||0)>216e5&&s.lastGift!==GdDaystr())?S.jsx("button",{className:"daily-sortie-btn"',
    '(typeof window!=="u"&&window.__idle&&s.lastGift!==GdDaystr())?S.jsx("button",{className:"daily-sortie-btn"',
    "idleCard")
rep('if(k==="idle"){const t=GdDaystr();if(z.lastGift===t||Date.now()-(z.lastSeen||0)<216e5)return z;return{...z,credits:z.credits+300,lastGift:t}}',
    'if(k==="idle"){const t=GdDaystr();if(z.lastGift===t||!(typeof window!=="u"&&window.__idle))return z;return{...z,credits:z.credits+300,lastGift:t}}',
    "idleHandler")

io.open(P, "w", encoding="utf-8").write(s)
print("v39 size", len(s))
