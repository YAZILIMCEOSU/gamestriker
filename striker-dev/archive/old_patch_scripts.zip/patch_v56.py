#!/usr/bin/env python3
# v3.31 — FAZ D (K4): friendly-ates duzeltmesi + boss 4 faz + boss bar
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v55.py"], cwd="/home/user", capture_output=True, text=True)
print("v55:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

# 1) KRITIK: dost varliklar ates etmesin (AURORA oyuncuyu vuruyordu)
rep('updateEnemies(e){for(const n of this.entities){if(!n.hp)continue;',
    'updateEnemies(e){for(const n of this.entities){if(!n.hp||n.friendly)continue;',
    "friendlySkip")

# 2) boss bayragi
rep('airborne:f})})}',
    'airborne:f,boss:e.kind==="boss"&&u===0?1:0})})}',
    "bossFlag")

# 3) boss fazlari
rep('if(!n.hp||n.friendly)continue;n.phase+=',
    'if(!n.hp||n.friendly)continue;if(n.boss){const r=n.hp/n.maxHp,ph=r>.7?1:r>.4?2:r>.15?3:4;if(ph!==(n.bph||0)){n.bph=ph,this.notify("bossP"+ph,4)}n.phase+=e*[0,.05,.12,.2,-.08][ph],n.fireIn-=e*[0,.3,.6,1,.2][ph],this.bossHp={h:r,ph}}n.phase+=',
    "bossPhases")

# 4) hud boss bar
rep('lstate:s.lockState,', 'lstate:s.lockState,boss:s.bossHp||null,', "hudBoss")

# 5) HUD bar JSX
rep('e.carrierHealth<100&&S.jsxs("div",{className:"carrier-status",',
    'e.boss&&S.jsxs("div",{className:"carrier-status boss-bar",children:["BOSS / PH0"+e.boss.ph,"  ",Math.round(e.boss.h*100)+"%"]}),e.carrierHealth<100&&S.jsxs("div",{className:"carrier-status",',
    "bossBarJsx")

# 6) css
rep('@keyframes lockpulse{50%{box-shadow:0 0 14px #e8a33d88}}</style>',
    '@keyframes lockpulse{50%{box-shadow:0 0 14px #e8a33d88}}.carrier-status.boss-bar{color:#ff8a5c;border:1px solid #ff8a5c;padding:4px 10px}</style>',
    "cssBoss")

# 7) i18n bossP1..4
a='صاروخ قادم نحوك — اناور وأطلق الشعلات!"]'
add=',bossP1:["Boss engaged — escorts active.","Boss teması — korumalar aktif.","Boss-Kontakt — Eskorten aktiv.","Contacto con el jefe — escoltas activas.","Contact boss — escortes actives.","Contatto boss — scorte attive.","Contato com o chefe — escoltas ativas.","Контакт с боссом — эскорт активен.","Kontak boss — pengawal aktif.","اشتباك مع الزعيم — الحراسة نشطة."],bossP2:["Boss accelerating — keep your energy.","Boss hızlanıyor — enerjini koru.","Boss beschleunigt — Energie halten.","El jefe acelera — guarda energía.","Le boss accélère — gardez l\'énergie.","Il boss accelera — tieni l\'energia.","O chefe acelera — guarde energia.","Босс ускоряется — береги энергию.","Boss melaju — jaga energimu.","الزعيم يتسارع — حافظ على طاقتك."],bossP3:["Boss salvo incoming — break now!","Boss salvo geliyor — şimdi kır!","Boss-Salve im Anflug — jetzt ausbrechen!","¡Salva del jefe! ¡Rompe ya!","Salve du boss — rompez maintenant!","Salva del boss — spezza ora!","Salva do chefe — quebre agora!","Залп босса — манёвр сейчас!","Salvo boss datang — berbelok!","وابل الزعيم قادم — اناور الآن!"],bossP4:["Boss critical — finish it!","Boss kritik — bitir işi!","Boss kritisch — erledige ihn!","Jefe crítico — ¡remátalo!","Boss critique — finissez-le!","Boss critico — finiscilo!","Chefe crítico — termine-o!","Босс критичен — добей!","Boss kritis — selesaikan!","الزعيم حرج — أنهِ الآن!"]'
assert s.count(a)==1
s=s.replace(a,a+add)
print("ok i18nBoss")

c31=s.count("3.30 DEV")
if c31<2:
    print("FAIL badge",c31); sys.exit(1)
s=s.replace("3.30 DEV","3.31 DEV")
print("ok badge x",c31)

io.open(P,"w",encoding="utf-8").write(s)
print("v56 size",len(s))
