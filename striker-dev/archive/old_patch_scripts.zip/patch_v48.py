#!/usr/bin/env python3
# v3.23 — hangar sadelestirme (Sky Combat düzeni), taktik danisman + tehdit oncelikli hedef, detay paslari
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v47.py"], cwd="/home/user", capture_output=True, text=True)
print("v47:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

# 1) HANGAR: alt karusel + sol detay karti (jet ortada gorunur)
rep('.aircraft-choice{flex-direction:column;flex:1;align-items:flex-start;gap:5px;min-width:0;height:72px;padding:15px 10px 10px}',
    '.aircraft-choice{flex-direction:column;flex:1;align-items:flex-start;gap:5px;min-width:0;height:72px;padding:15px 10px 10px}',"cssHangar")

# 2) taktik danisman motoru
rep('updateWingman(e){if(!this.preferen',
    'advise(e){if(this.phase!=="combat")return;this.advT=(this.advT||10)-e;if(this.advT>0)return;this.advT=26;const rd=this.entities.find(n=>n.hp>0&&n.parts&&n.parts.some(p=>p.k==="dish"&&p.h>0));const aa=this.entities.find(n=>n.hp>0&&n.parts&&n.parts.some(p=>p.k==="aa"&&p.h>0));this.notify(rd?"advRadar":aa?"advAA":"advClean",6)}updateWingman(e){if(!this.preferen',"adviseMethod")
rep('this.updateEnemies(a),this.updateWingman(a)',
    'this.updateEnemies(a),this.advise(a),this.updateWingman(a)',"adviseCall")

# 3) i18n: danisman satirlari x10
rep('vipdown:[',
    'advAA:["TACTICAL: silence the AA guns first — they bleed your hull.","TAKTİK: önce AA\'ları sustur — gövdeni eritiyorlar.","TAKTIK: zuerst die Flak ausschalten.","TÁCTICA: silencia primero los AA.","TACTIQUE : neutralisez d\'abord la DCA.","TATTICA: neutralizza prima la contraerea.","TÁTICA: silencie o AA primeiro.","ТАКТИКА: сначала подави ПВО.","TAKTIS: bungkam AA dulu.","تكتيك: أسكت مدافع AA أولاً."],advRadar:["TACTICAL: kill the radar dish — the defenders go blind.","TAKTİK: radar tabağını düşür — savunma körleşir.","TAKTIK: Radarschüssel zerstören — Verteidigung wird blind.","TÁCTICA: destruye el radar.","TACTIQUE : détruisez le radar.","TATTICA: distruggi il radar.","TÁTICA: destrua o radar.","ТАКТИКА: сби радар — оборона ослепнет.","TAKTIS: hancurkan radar.","تكتيك: دمّر طبق الرادار."],advClean:["TACTICAL: airspace soft — press the high-value structure.","TAKTİK: hava yumuşak — yüksek değerli yapıya yüklen.","TAKTIK: Luftraum ruhig — Hochwertziel angreifen.","TÁCTICA: espacio aéreo libre — ve al objetivo de valor.","TACTIQUE : ciel dégagé — frappez la cible de valeur.","TATTICA: cielo libero — colpisci il bersaglio di valore.","TÁTICA: céu limpo — pressione o alvo de valor.","ТАКТИКА: небо чисто — бей по ценной цели.","TAKTIS: udara aman — serang sasaran bernilai.","تكتيك: السماء صافية — استهدف المنشأة القيمة."],vipdown:[',"i18nAdv")

# 4) tehdit oncelikli otomatik hedef (AA canli olan one)
rep('const a=this.alive.sort((o,c)=>o.position.distanceToSquared(this.player)-c.position.distanceToSquared(this.player))[0];a&&(this.targetId=a.id)',
    'const a=this.alive.sort((o,c)=>((o.parts&&o.parts.some(p=>p.k==="aa"&&p.h>0))?0:1e12)+o.position.distanceToSquared(this.player)-(((c.parts&&c.parts.some(p=>p.k==="aa"&&p.h>0))?0:1e12)+c.position.distanceToSquared(this.player)))[0];a&&(this.targetId=a.id)',"threatSort")

# 5) pist kenar isiklari
rep('a.add(this.box([5,2,5],this.steel,[-450,1,40]));',
    'for(let i=0;i<11;i++){a.add(this.box([1,.8,1],this.pale,[-450+i*90,2.4,23.5],.08));a.add(this.box([1,.8,1],this.pale,[-450+i*90,2.4,-23.5],.08))}a.add(this.box([5,2,5],this.steel,[-450,1,40]));',"runwayLights")

# 6) rafineri kure tanklar
rep('a.add(this.box([5,2,5],this.steel,[110,1,60]));',
    'a.add(this.mesh(new ia(6,12,10),this.steel,[-70,7,30]));a.add(this.mesh(new ia(5,12,10),this.steel,[-84,6,18]));a.add(this.box([5,2,5],this.steel,[110,1,60]));',"spheres")

# 7) kopru kule isiklari
rep('a.add(this.box([6,4,30],this.steel,[q*160,52,0]))',
    'a.add(this.box([6,4,30],this.steel,[q*160,52,0])),a.add(this.box([2,2,2],this.orange,[q*160,55,0],.6))',"bridgeLights")

rep('transform:none}}</style>',
    'transform:none}}.aircraft-selector{display:flex!important;position:absolute!important;bottom:0!important;left:0!important;right:0!important;top:auto!important;margin:0!important;flex-wrap:nowrap!important;flex-direction:row!important;overflow-x:auto!important;gap:8px!important;padding:0 16px 14px!important}.aircraft-choice{flex:0 0 auto!important;width:172px!important;height:88px!important;flex-direction:row!important;align-items:center!important}.hangar-detail-card{position:absolute!important;left:4%!important;top:96px!important;margin:0!important;max-width:330px!important;text-align:left!important}</style>',"cssTop")

# 8) rozet
c23=s.count("3.22 DEV")
if c23<2:
    print("FAIL badge",c23); sys.exit(1)
s=s.replace("3.22 DEV","3.23 DEV")
print("ok badge x",c23)

io.open(P,"w",encoding="utf-8").write(s)
print("v48 size",len(s))
