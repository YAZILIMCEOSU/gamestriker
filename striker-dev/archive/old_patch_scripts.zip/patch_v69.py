P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
old='})(diM),this.notify("bonus",6)'
n=s.count(old); assert n==1, f"count {n}"
s=s.replace(old,'})([.85,1,1.2,1.45,1.75][this.di]),this.notify("bonus",6)')
assert s.count('3.43 DEV')==2
s=s.replace('3.43 DEV','3.44 DEV')
open(P,'w',encoding='utf-8').write(s); print('v69 ok', len(s))
