P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old); assert n==1, f"count {n}: {old[:60]}"
    s=s.replace(old,new)
# 1) all menu screens (home/hangar/etc.): no bloom -> sharp hero jet
rep('this.bloom.strength=n?0:this.options.quality===\"ultra\"?.34:.24;',
    'this.bloom.strength=0;')
# 2) in-flight: restore bloom from preferences every flight frame
rep('renderFlight(e,n){this.player.position.copy(n.player),',
    'renderFlight(e,n){this.bloom.strength=this.options.quality===\"ultra\"?.34:.24,this.player.position.copy(n.player),')
assert s.count('3.51 DEV')==2
s=s.replace('3.51 DEV','3.52 DEV')
open(P,'w',encoding='utf-8').write(s); print('v78 ok', len(s))
