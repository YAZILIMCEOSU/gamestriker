#!/usr/bin/env python3
# v3.15 DEV — gemiye inis, yakit sistemi + reklam/kredi dolumu, ozellik kilitleri,
# acilis sinematigi, fragman butonu
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v39.py"], cwd="/home/user", capture_output=True, text=True)
print("v39:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def bal(t):
    d=0;b=0;q=0;in_s=None;esc=False
    for ch in t:
        if in_s:
            if esc:esc=False
            elif ch=='\\':esc=True
            elif ch==in_s:in_s=None
            continue
        if ch in '"\'':in_s=ch
        elif ch=='`':in_s='`'
        elif ch=='(':d+=1
        elif ch==')':d-=1
        elif ch=='{':b+=1
        elif ch=='}':b-=1
        elif ch=='[':q+=1
        elif ch==']':q-=1
    return (d,b,q)

def rep(old, new, tag, count=1):
    global s
    if bal(old)!=bal(new):
        print("FAIL BAL",tag,bal(old),bal(new));sys.exit(1)
    c = s.count(old)
    if c != count:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

# ---- 1) iniş: return fazında hız+irtifa koşulu ----
rep('this.phase==="return")this.lock=0,this.player.distanceTo(this.extraction)<190&&this.finish(!0);',
    'this.phase==="return"){this.lock=0;const Ld=this.player.distanceTo(this.extraction);if(Ld<190&&this.player.y<80&&this.speed<115)this.finish(!0,"landed");else if(Ld<260)this.notify(this.speed>=115?"landSpeed":"landAlt",2)}',
    "landing")
# ---- 2) dönüşte dost gemi (iniş güvertesi) ----
rep('this.rejoinPoint=null,this.assisted=!0,this.notify("extraction",30))}',
    'this.rejoinPoint=null,this.assisted=!0,this.notify("extraction",30),this.entities.push({id:902,kind:"carrier",friendly:!0,position:this.extraction.clone(),origin:this.extraction.clone(),heading:this.heading,hp:1e9,maxHp:1e9,radius:90,fireIn:1e9,phase:0,airborne:!1}))}',
    "deckCarrier")
# ---- 3) yakıt alanları ----
rep('targetId=0;carrierHealth=100;assisted;', 'targetId=0;carrierHealth=100;fuel=100;fuelCost=0;refuelAdT=0;refuelUsed=!1;assisted;', "fuelFields")
# ---- 4) yakıt tüketimi + dolum komutları ----
rep('this.time+=a,this.catT+=a,',
    'this.time+=a,this.fuel=Math.max(0,this.fuel-a*(96/this.mission.limit)),window.__refuel==="ad"&&!this.refuelUsed&&(this.refuelUsed=!0,this.refuelAdT=5,window.__refuel=null),window.__refuel==="buy"&&!this.refuelUsed&&(this.refuelUsed=!0,this.fuelCost=200,this.fuel=Math.min(100,this.fuel+40),this.notify("fuelUp",3),window.__refuel=null),this.refuelAdT>0&&(this.refuelAdT-=a,this.refuelAdT<=0&&(this.fuel=Math.min(100,this.fuel+40),this.notify("fuelUp",3))),this.fuel<=25&&!this.fuelWarned&&(this.fuelWarned=!0,this.notify("fuelLow",4)),this.fuel<=0&&this.phase==="combat"&&this.finish(!1,"fuel"),this.catT+=a,',
    "fuelDrain")
# ---- 5) snapshot ----
rep('carrierHealth:s.carrierHealth,mkind:s.mission.kind,', 'carrierHealth:s.carrierHealth,mkind:s.mission.kind,fuel:s.fuel,refuelAdT:s.refuelAdT,refuelUsed:s.refuelUsed,', "fuelSnap")
# ---- 6) HUD yakıt barı + dolum istemi ----
rep('S.jsx("div",{className:"grade-overlay"}),',
    'S.jsx("div",{className:"grade-overlay"}),S.jsx("div",{className:"fuel-bar",children:S.jsx("i",{style:{width:Math.max(0,Math.round(e.fuel))+"%",background:e.fuel<25?"#ff7561":"#9fe8b0"}})}),e.fuel<10&&!e.refuelUsed?S.jsxs("div",{className:"refuel-prompt",children:[S.jsx("span",{children:o("fuelLow")}),S.jsx("button",{onClick:()=>{window.__refuel="ad"},children:o("refuelAd")}),S.jsx("button",{onClick:()=>{window.__refuel="buy"},children:o("refuelBuy")})]}):null,',
    "fuelHud")
# ---- 7) sonuç + kredi düşümü ----
rep('seconds:this.time,kills:this.kills,reason:n}', 'seconds:this.time,kills:this.kills,reason:n,fuelCost:this.fuelCost||0}', "fuelResult")
rep('credits:Be.credits+(ae.success?ae.reward:0),', 'credits:Be.credits+(ae.success?ae.reward:0)-(ae.fuelCost||0),', "fuelDeduct")
# ---- 8) özellik kilitleri ----
rep('upV:(s.upgV||{})[s.aircraft]||0})', 'upV:(s.upgV||{})[s.aircraft]||0,unl:Object.keys(s.records).length})', "unlPass")
rep('this.assisted=a.assisted,', 'this.assisted=a.assisted,this.unl=q5&&q5.unl||0,', "unlCtor")
rep('updateWingman(e){if(!this.preferences.wingman||this.phase!=="combat")return;', 'updateWingman(e){if(!this.preferences.wingman||this.unl<3||this.phase!=="combat")return;', "wingGate")
rep('this.preferences.heavyMissiles?[this.mSet[0]*.85,', 'this.preferences.heavyMissiles&&this.unl>=6?[this.mSet[0]*.85,', "heavyGate")
rep('.map(([a,o,c])=>S.jsxs("div",{className:"settings-row",children:[S.jsxs("div",{children:[S.jsx("strong",{children:n(o)}),S.jsx("p",{children:n(c)})]}),S.jsx("button",{className:`toggle-switch ${s[a]?"on":""}`,role:"switch","aria-checked":s[a],"aria-label":n(o),onClick:()=>e({[a]:!s[a]}),children:S.jsx("span",{})})]},a))',
    '.map(([a,o,c])=>{const Lk={wingman:3,heavyMissiles:6,cockpit:9}[a]||0,Un=(()=>{try{return Object.keys((JSON.parse(localStorage.getItem("idea-game.striker.v2")||"{}").records)||{}).length}catch{return 0}})();return S.jsxs("div",{className:"settings-row",children:[S.jsxs("div",{children:[S.jsx("strong",{children:n(o)+(Lk&&Un<Lk?" · "+Un+"/"+Lk:"")}),S.jsx("p",{children:n(c)})]}),S.jsx("button",{className:`toggle-switch ${s[a]?"on":""}`,role:"switch","aria-checked":s[a],"aria-label":n(o),disabled:Lk&&Un<Lk,onClick:()=>{if(Lk&&Un<Lk)return;e({[a]:!s[a]})},children:S.jsx("span",{})})]},a)})',
    "settingsLock")
# ---- 9) sinematik + fragman ----
rep('function Gw({save:s,screen:e,onScreen:n,onModal:a,onLanguage:o,onSound:c}){',
    'function Ic({save:s,onDone:e}){const[n,a]=pt.useState(0);pt.useEffect(()=>{if(n>=4){e();return}const t=setTimeout(()=>a(n+1),2600);return()=>clearTimeout(t)},[n]);const L=["cine1","cine2","cine3","cine4"];return S.jsxs("div",{className:"cine-overlay",children:[S.jsx("div",{className:"cine-bar top"}),S.jsx("div",{className:"cine-bar bot"}),S.jsx("p",{children:__L(s.preferences.language,L[Math.min(3,n)])}),S.jsx("button",{onClick:e,children:__L(s.preferences.language,"skip")})]})}function Gw({save:s,screen:e,onScreen:n,onModal:a,onLanguage:o,onSound:c}){',
    "cineComp")
rep('S.jsx("div",{className:"screen-grain"}),S.jsx(Gw,',
    'S.jsx("div",{className:"screen-grain"}),s.seenIntro?null:S.jsx(Ic,{save:s,onDone:()=>e(z=>({...z,seenIntro:!0}))}),S.jsx(Gw,',
    "cineMount")
# fragman butonu: bell butonundan sonra
rep('children:"🔔"}),', 'children:"🔔"}),S.jsx("a",{className:"language-button",href:"https://01a0e2e4-565e-784a-b211-a5159d898b11.arena.site/",target:"_blank",rel:"noreferrer",title:"Tanıtım Fragmanı / Trailer",children:"▶"}),', "trailerBtn")
# ---- 10) normalizer seenIntro ----
rep('lastSeen:u.lastSeen||0,lastGift:u.lastGift||"",', 'lastSeen:u.lastSeen||0,lastGift:u.lastGift||"",seenIntro:u.seenIntro===!0,', "normIntro")
# ---- 11) CSS ----
rep('.store-panel{', '.cine-overlay{position:fixed;inset:0;z-index:60;background:radial-gradient(ellipse at center,rgba(4,14,20,.55),rgba(2,8,12,.92));display:flex;align-items:center;justify-content:center}.cine-bar{position:absolute;left:0;right:0;height:11%;background:#000}.cine-bar.top{top:0}.cine-bar.bot{bottom:0}.cine-overlay p{color:#d8f4ff;font-family:var(--mono);letter-spacing:.22em;font-size:13px;text-align:center;max-width:72%;line-height:1.9}.cine-overlay button{position:absolute;right:16px;bottom:14%;background:none;border:1px solid #3c5a66;color:#9eafbb;border-radius:8px;padding:6px 14px;cursor:pointer;letter-spacing:.12em;font-size:10px}.fuel-bar{position:absolute;right:12px;bottom:70px;width:130px;height:7px;border:1px solid #3c5a66;border-radius:4px;z-index:6;background:rgba(10,25,32,.6)}.fuel-bar i{display:block;height:100%;border-radius:3px;transition:width .3s}.refuel-prompt{position:absolute;left:50%;top:62%;transform:translateX(-50%);display:flex;gap:8px;align-items:center;z-index:7;background:rgba(10,25,32,.9);padding:8px 12px;border:1px solid #e8a33d;border-radius:10px;font-size:9px;letter-spacing:.08em}.refuel-prompt button{background:linear-gradient(180deg,#e8a33d,#c7822a);color:#17130b;border:none;border-radius:7px;padding:6px 10px;font-weight:700;cursor:pointer;font-size:9px}.store-panel{', "css40")
# ---- 12) i18n ----
rep('carrierLost:["Aurora was lost.",',
    'fuel:["OUT OF FUEL","YAKIT BİTTİ","TREIBSTOFF AUS","SIN COMBUSTIBLE","PANNE DE CARBURANT","CARBURANTE ESAURITO","SEM COMBUSTÍVEL","ТОПЛИВО КОНЧИЛОСЬ","BAHAN HABIS","نفد الوقود"],'
    'fuelLow:["FUEL LOW","YAKIT DÜŞÜK","TREIBSTOFF NIEDRIG","COMBUSTIBLE BAJO","CARBURANT FAIBLE","CARBURANTE BASSO","COMBUSTÍVEL BAIXO","МАЛО ТОПЛИВА","BAHAN TIPIS","وقود منخفض"],'
    'fuelUp:["FUEL +40","YAKIT +40","TREIBSTOFF +40","COMBUSTIBLE +40","CARBURANT +40","CARBURANTE +40","COMBUSTÍVEL +40","ТОПЛИВО +40","BAHAN +40","وقود +40"],'
    'refuelAd:["WATCH AD +40","REKLAM İZLE +40","ANZEIGE +40","VER ANUNCIO +40","PUB +40","ANNUNCIO +40","ANÚNCIO +40","РЕКЛАМА +40","IKLAN +40","إعلان +40"],'
    'refuelBuy:["BUY 200","SATIN AL 200","KAUFEN 200","COMPRAR 200","ACHETER 200","COMPRA 200","COMPRAR 200","КУПИТЬ 200","BELI 200","شراء 200"],'
    'landSpeed:["TOO FAST — slow down to land","ÇOK HIZLISIN — iniş için yavaşla","ZU SCHNELL — langsamer","MUY RÁPIDO — reduce","TROP VITE — ralentissez","TROPPO VELOCE — rallenta","MUITO RÁPIDO — reduza","СЛИШКОМ БЫСТРО — снизи","TERLALU CEPAT — perlambat","سرعة عالية — أبطئ"],'
    'landAlt:["TOO HIGH — descend to the deck","ÇOK YÜKSEKSİN — güverteye alçal","ZU HOCH — sinken","MUY ALTO — desciende","TROP HAUT — descendez","TROPPO ALTO — scendi","MUITO ALTO — desça","СЛИШКОМ ВЫСОКО — снижайся","TERLALU TINGGI — turun","مرتفع — انخفض"],'
    'cine1:["AURORA CARRIER — the last runway of the free seas","AURORA GEMİSİ — özgür denizlerin son pisti","AURORA — die letzte Piste der freien Meere","AURORA — la última pista de los mares libres","AURORA — la dernière piste des mers libres","AURORA — l’ultima pista dei mari liberi","AURORA — a última pista dos mares livres","АВРОРА — последний аэродром свободных морей","AURORA — landasan terakhir lautan bebas","أورورا — مدرج البحار الحرة الأخير"],'
    'cine2:["16 original airframes. One pilot. You.","16 özgün uçak. Tek pilot. Sen.","16 originale Zellen. Ein Pilot. Du.","16 células originales. Un piloto. Tú.","16 cellules originales. Un pilote. Toi.","16 cellule originali. Un pilota. Tu.","16 células originais. Um piloto. Você.","16 оригинальных машин. Один пилот. Ты.","16 pesawat orisinal. Satu pilot. Kamu.","16 طائرة أصلية. طيار واحد. أنت."],'
    'cine3:["Four theaters. Forty-eight operations. Endless sky.","Dört bölge. Kırk sekiz operasyon. Sonsuz gökyüzü.","Vier Gebiete. 48 Operationen. Endloser Himmel.","Cuatro teatros. 48 operaciones. Cielo infinito.","Quatre théâtres. 48 opérations. Un ciel sans fin.","Quattro teatri. 48 operazioni. Cielo infinito.","Quatro teatros. 48 operações. Céu sem fim.","Четыре театра. 48 операций. Бесконечное небо.","Empat medan. 48 operasi. Langit tanpa akhir.","أربعة مسارح. 48 عملية. سماء لا تنتهي."],'
    'cine4:["STRIKER — own the sky","STRIKER — gökyüzüne hükmet","STRIKER — beherrsche den Himmel","STRIKER — domina el cielo","STRIKER — dominez le ciel","STRIKER — domina il cielo","STRIKER — domine o céu","STRIKER — господствуй в небе","STRIKER — kuasai langit","STRIKER — تحكم في السماء"],'
    'skip:["SKIP","GEÇ","ÜBERSPRINGEN","SALTAR","PASSER","SALTA","PULAR","ПРОПУСТИТЬ","LEWATI","تخط"],'
    'carrierLost:["Aurora was lost.",', "i18n40")
# ---- 13) rozet ----
c = s.count("3.14 DEV")
if c < 2:
    print("FAIL badge", c); sys.exit(1)
s = s.replace("3.14 DEV", "3.15 DEV")
print("ok badge x", c)


rep('cockpitView:["","",', 'cockpitView:["COCKPIT VIEW","KOKPİT GÖRÜNÜMÜ",', "i18nCockpit1")
rep('cockpitHint:["","",', 'cockpitHint:["Missions start in the cockpit. Press C to change camera.","Görevler kokpit görünümünde başlar. C ile kamera değişir.",', "i18nCockpit2")
rep('C меняет kamera.', 'C меняет камеру.', "i18nRuFix")

rep('carrierLost:["Aurora was lost.",', 'landed:["Touchdown confirmed. Deck secured.","İniş onaylandı. Güverte emniyette.","Landung bestätigt. Deck gesichert.","Aterrizaje confirmado. Cubierta asegurada.","Appontage confirmé. Pont sécurisé.","Atterraggio confermato. Ponte sicuro.","Pouso confirmado. Convés seguro.","Посадка подтверждена. Палуба в безопасности.","Pendaratan dikonfirmasi. Dek aman.","تم الهبوط. السطح آمن."],carrierLost:["Aurora was lost.",', "i18nLanded")
rep('function Jn(s,e){return __L(s,Fw[e])}', 'function Jn(s,e){return __L(s,Fw[e]||[e,e,e,e,e,e,e,e,e,e])}', "jnSafe")
io.open(P, "w", encoding="utf-8").write(s)
print("v40 size", len(s))
