#!/usr/bin/env python3
# v3.13 DEV — P2+P3: görev çeşitliliği (escort/raid/waves/race) + aşama zinciri (chain)
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v32.py"], cwd="/home/user", capture_output=True, text=True)
print("v32:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag, count=1):
    global s
    c = s.count(old)
    if c != count:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

# 1) alive: dost birimler hedef/kilit/zafer listesine girmesin
rep('get alive(){return this.entities.filter(e=>e.hp>0)}',
    'get alive(){return this.entities.filter(e=>e.hp>0&&!e.friendly)}', "aliveFriendly")
# 2) race: boş hedef listesi anında zafer tetiklemesin
rep('this.alive.length===0&&(this.phase="return",this.extraction.copy(this.player)',
    'this.alive.length===0&&!["race","chain","waves"].includes(this.mission.kind)&&(this.phase="return",this.extraction.copy(this.player)', "raceGuard")
# 3) combat tick'ine hook çağrısı
rep('else{this.updateEnemies(a),this.updateWingman(a),',
    'else{this.updateEnemies(a),this.updateWingman(a),this.hooksTick(a),', "hookCall")
# 4) hook metodları
rep('updateProjectiles(e){', '''hooksTick(a){const M=this.mission.kind,diM=[.85,1,1.2,1.45,1.75][this.di];
if(M==="waves"&&(this.waveN||0)>=3&&this.alive.length===0&&!this.result)this.finish(!0);
if(M==="waves"&&this.time>18&&this.alive.length<=1&&(this.waveN||0)<3&&this.time<this.mission.limit-45){this.waveN=(this.waveN||0)+1;for(let i=0;i<3;i++){const x=this.player.x+(i-1)*420,z=this.player.z-1500-i*260,hp=(i===2?260:120)*diM;this.entities.push({id:300+this.waveN*10+i,kind:i===2?"heavy":"interceptor",position:new H(x,200,z),origin:new H(x,200,z),heading:.2,hp:hp,maxHp:hp,radius:i===2?26:22,fireIn:10+i*2,phase:i*2.1,airborne:!0})}this.notify("wave",3)}
if(M==="chain"){const st=this.stage||1,ho=this.alive.filter(q=>q.airborne).length,gr=this.alive.filter(q=>!q.airborne).length;
if(st===1&&ho===0){this.stage=2;this.notify("stage2",4);[["destroyer",380,39,8],["radar",130,30,26],["sub",220,26,8]].forEach((c,i)=>{const x=(i-1)*380,z=this.player.z-1200-i*300,hp=c[1]*diM;this.entities.push({id:400+i,kind:c[0],position:new H(x,c[3],z),origin:new H(x,c[3],z),heading:.2,hp:hp,maxHp:hp,radius:c[2],fireIn:1e9,phase:i,airborne:!1})})}
else if(st===2&&gr===0&&ho===0){this.stage=3;this.notify("stage3",4);const x=this.player.x,z=this.player.z-1800,hp=520*diM;this.entities.push({id:450,kind:"interceptor",position:new H(x,220,z),origin:new H(x,220,z),heading:.2,hp:hp,maxHp:hp,radius:22,fireIn:8,phase:0,airborne:!0})}
else if(st===3&&ho===0&&!this.result)this.finish(!0)}
if(M==="escort"){if(!this.convoy){const z=this.player.z+260;this.convoy={id:901,kind:"destroyer",friendly:!0,position:new H(140,6,z),origin:new H(140,6,z),heading:0,hp:750,maxHp:750,radius:39,fireIn:1e9,phase:0,airborne:!1};this.entities.push(this.convoy)}
this.convoy.position.z-=26*a;this.convoy.origin.z=this.convoy.position.z;
if(this.time>20)this.convoy.hp-=this.alive.length*.4*a;
if(this.convoy.hp<=0)this.carrierHealth=0;
if(this.convoy.position.z<-5200&&!this.result)this.finish(!0)}
if(M==="race"){if(!this.gates){this.gates=0;this.extraction.set(0,180,-800)}
if(this.player.distanceTo(this.extraction)<190){this.gates++;this.score+=150;
if(this.gates>=6){if(!this.result)this.finish(!0)}else{this.extraction.set(Math.sin(this.gates*1.7)*520,180,-800-this.gates*900);this.notify("gate",2)}}}
for(const q of this.alive)if(q.airborne&&q.hp<q.maxHp*.45&&Math.random()<.35)this.event("damage",q.position,.8)}
updateProjectiles(e){''', "hooks", 1)
# 5) snapshot'a mission kind
rep('carrierHealth:s.carrierHealth,markers:e', 'carrierHealth:s.carrierHealth,mkind:s.mission.kind,markers:e', "snapKind")
# 6) HUD konvoy etiketi
rep('children:["AURORA / ",Math.round(', 'children:[e.mkind==="escort"?"KONVOY / ":"AURORA / ",Math.round(', "convoyLabel")
# 7) yeni görevler zincir kilidinden muaf
rep('Rl(s,e.records)||s===Ddaily()||s===192,d=wl(e.aircraft)',
    'Rl(s,e.records)||s===Ddaily()||s===192||s>=193,d=wl(e.aircraft)', "unlockNew")
# 8) i18n: wave/gate/stage2/stage3
rep('sortie:["SORTIE — weapons free",',
    'wave:["HOSTILE WAVE INBOUND","DÜŞMAN DALGASI GELİYOR","FEINDWELLE IM ANFLUG","OLEADA ENEMIGA ENTRANTE","VAGUE ENNEMIE EN APPROCHE","ONDATA NEMICA IN ARRIVO","ONDA HOSTIL A CAMINHO","ВОЛНА ПРОТИВНИКА ПРИБЛИЖАЕТСЯ","GELOMBANG MUSUH DATANG","موجة معادية قادمة"],'
    'gate:["GATE CLEARED +150","GEÇİT TEMİZ +150","TOR PASSIERT +150","PUERTA SUPERADA +150","PORTE FRANCHIE +150","VARCHO SUPERATO +150","PORTÃO LIBERADO +150","ВОРОТА ПРОЙДЕНЫ +150","GERBANG AMAN +150","بوابة جديدة +150"],'
    'stage2:["STAGE 2 — RAID THE FLEET","AŞAMA 2 — FİLOYA BASKIN","PHASE 2 — ANGRIFF AUF DIE FLOTTE","FASE 2 — ASALTO A LA FLOTA","PHASE 2 — RAID SUR LA FLOTTE","FASE 2 — RAID ALLA FLOTTA","FASE 2 — ASSALTO À FROTA","ЭТАП 2 — РЕЙД НА ФЛОТ","TAHAP 2 — SERBUAN ARMADA","المرحلة 2 — غارة على الأسطول"],'
    'stage3:["FINAL STAGE — ACE DUEL","SON AŞAMA — AS DÜELLOSU","ENDPHASE — ASS-DUELL","FASE FINAL — DUELO DE ACES","PHASE FINALE — DUEL D’AS","FASE FINALE — DUELLO TRA ASSI","FASE FINAL — DUELO DE ASES","ФИНАЛ — ДУЭЛЬ АСОВ","TAHAP AKHIR — DUEL ACE","المرحلة الأخيرة — مبارزة الأساتذة"],'
    'sortie:["SORTIE — weapons free",', "i18nP2")
# 9) 8 yeni görev
rep('par:150,sunset:1});function Ey(){',
    'par:150,sunset:1});'
    'dn.push({id:193,name:"KONVOY ESCORT",season:3,chapter:0,kind:"escort",targets:["interceptor","interceptor","heavy"],briefing:["Escort the friendly destroyer through the strait. Keep the hostiles off her back until she clears the pass.","Dost muhribi boğazdan geçir. Açığı çıkana kadar düşmanı üstünden uzak tut."],reward:1600,limit:300,par:200});'
    'dn.push({id:194,name:"BASKIN",season:3,chapter:1,kind:"raid",targets:["destroyer","radar","sub","destroyer","radar"],briefing:["A raid on the anchored patrol group. Five targets, heavy flak discipline expected. Hit and run.","Demirli devriye grubuna baskın. Beş hedef, yoğun AA disiplini. Vur ve kaç."],reward:1700,limit:360,par:240});'
    'dn.push({id:195,name:"DALGA SAVUNMASI",season:3,chapter:2,kind:"waves",targets:["interceptor","interceptor"],briefing:["Hostiles attack in waves. Hold the sector until the relief package arrives — three waves minimum.","Düşman dalgalar halinde saldırıyor. Takviye gelene kadar sektörü tut — en az üç dalga."],reward:1800,limit:360,par:240});'
    'dn.push({id:196,name:"GEÇİT YARIŞI",season:3,chapter:3,kind:"race",targets:[],briefing:["Six gates, one clock. Fly the corridor clean and fast — no hostiles, only you and the line.","Altı kapı, tek saat. Koridoru temiz ve hızlı uç — düşman yok, sadece sen ve çizgi."],reward:1200,limit:240,par:150});'
    'dn.push({id:197,name:"ZİNCİR HAREKÂTI",season:3,chapter:3,kind:"chain",targets:["interceptor","interceptor"],briefing:["Three-stage operation: sweep the air, raid the fleet, then face their ace. No rest between.","Üç aşamalı harekât: havayı süpür, filoya baskın yap, sonra aslarıyla yüzleş. Ara yok."],reward:2200,limit:480,par:330});'
    'dn.push({id:198,name:"KONVOY FIRTINASI",season:3,chapter:1,kind:"escort",targets:["interceptor","interceptor","heavy","attacker"],briefing:["Storm cover for the convoy. Four hostile flights between the ship and home.","Konvoya fırtına koruması. Gemi ile liman arasında dört düşman uçuşu."],reward:2000,limit:330,par:220});'
    'dn.push({id:199,name:"DERİN BASKIN",season:3,chapter:2,kind:"raid",targets:["carrier","destroyer","radar","sub"],briefing:["Deep raid on the command anchorage. The flagship is the prize.","Komuta demir yerinde derin baskın. Ödül amiral gemisi."],reward:2100,limit:390,par:260});'
    'dn.push({id:200,name:"SON DALGA",season:3,chapter:0,kind:"waves",targets:["interceptor","heavy","interceptor"],briefing:["The last push of the season. Endless waves until the horn — hold the line.","Sezonun son taarruzu. Boruya kadar bitmeyen dalgalar — hattı tut."],reward:2100,limit:390,par:260});'
    'function Ey(){', "missions8")

io.open(P, "w", encoding="utf-8").write(s)
print("v33 size", len(s))
