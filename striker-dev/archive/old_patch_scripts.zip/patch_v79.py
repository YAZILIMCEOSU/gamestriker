P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old); assert n==1, f"count {n}: {old[:70]}"
    s=s.replace(old,new)

# A) disable the single random one-shot event; scheduler replaces it
rep('this.evtT=35+Math.random()*30,this.evtDone=!1,',
    'this.evtT=1e9,this.evtDone=!0,this.sched=null,this.schedI=0,')

# B) call the scheduler every combat frame
rep('this.frenzyT>0&&(this.frenzyT-=a),',
    'this.frenzyT>0&&(this.frenzyT-=a),this.surpriseTick(a),')

# C) scheduler + spawners (class methods)
methods = r'''surpriseTick(dt){
if(this.phase!=="combat"||!this.mission||this.mission.kind==="waves"||this.mission.kind==="chain")return;
if(!this.sched){
const id=this.mission.id||0;let sd=((id+3)*7919)%65521||1;const rnd=()=>(sd=(sd*16807)%2147483647)/2147483647;
const tier=Math.min(3,Math.floor(id/48));const n=3+tier;const pool=["ambush","swarm","heavy","swarm","ambush","heavy"];
this.sched=[];let t=this.time+38+rnd()*12;
for(let i=0;i<n;i++){this.sched.push({t:t,k:i%4===3?"supply":pool[Math.floor(rnd()*pool.length)]});t+=52+rnd()*22}
this.schedI=0;
}
if(this.schedI<this.sched.length&&this.time>this.sched[this.schedI].t){const ev=this.sched[this.schedI++];this.fireSurprise(ev.k,this.schedI)}
}
fireSurprise(k,idx){
const p=this.player,D=[.85,1,1.2,1.45,1.75][this.di]||1,b=5200+idx*20;
if(k==="ambush"){
this.entities.push({id:b,kind:"interceptor",position:new H(p.x+320,210,p.z+650),origin:new H(p.x+320,210,p.z+650),heading:.2,hp:130*D,maxHp:130*D,radius:22,fireIn:6,phase:1,airborne:!0},{id:b+1,kind:"interceptor",position:new H(p.x-320,210,p.z+650),origin:new H(p.x-320,210,p.z+650),heading:.2,hp:130*D,maxHp:130*D,radius:22,fireIn:7,phase:2,airborne:!0});
this.notify("ambush",5);
}else if(k==="swarm"){
for(let j=0;j<6;j++){const x=p.x+(j-2.5)*150,y=170+(j%3)*30,z=p.z-950-j*45;this.entities.push({id:b+j,kind:"drone",position:new H(x,y,z),origin:new H(x,y,z),heading:0,hp:40*D,maxHp:40*D,radius:9,fireIn:2.5+j*.4,phase:j,airborne:!0})}
this.notify("swarm",5);
}else if(k==="heavy"){
const x=p.x+(idx%2?700:-700),z=p.z-1500;
this.entities.push({id:b,kind:"heavy",position:new H(x,230,z),origin:new H(x,230,z),heading:.2,hp:260*D,maxHp:260*D,radius:26,fireIn:6,phase:0,airborne:!0});
this.notify("heavy",5);
}else if(k==="supply"){
this.missiles=Math.min(this.aircraft.missiles,this.missiles+2),this.flares+=1,this.bombs+=1,this.notify("supply",6);
}
}
'''
rep('updateEnemies(e){', methods + 'updateEnemies(e){')

# D) notify strings (10 languages: EN TR DE ES FR IT PT RU ID AR)
strings = ('swarm:["SWARM — drone swarm inbound!","SÜRÜ — drone sürüsü yaklaşıyor!","SCHWARM — Drohnenschwarm im Anflug!","ENJAMBRE — enjambre de drones en camino!","ESSAIM — essaim de drones en approche !","SCIAME — sciame di droni in arrivo!","ENXAME — enxame de drones chegando!","РОЙ — рой дронов на подходе!","KAWANAN — kawanan drone datang!","سرب — سرب من الطائرات المسيرة قادم!"],'
           'heavy:["HEAVY — heavy fighter coming in from ahead!","AĞIR — ağır avcı önden geliyor!","SCHWER — schwerer Jäger kommt von vorn!","PESADO — caza pesado de frente!","LOURD — chasseur lourd de face !","PESANTE — caccia pesante di fronte!","PESADO — caça pesado de frente!","ТЯЖЁЛЫЙ — тяжёлый истребитель спереди!","BERAT — pesawat tempur berat dari depan!","ثقيل — مقاتل ثقيل من الأمام!"],')
rep('ambush:["AMBUSH', strings + 'ambush:["AMBUSH')

assert s.count('3.52 DEV')==2
s=s.replace('3.52 DEV','3.53 DEV')
open(P,'w',encoding='utf-8').write(s); print('v79 ok', len(s))
