#!/usr/bin/env python3
# v3.33 — HANGAR 2.0: sade, temiz, Play Store kalitesinde garaj + i18n eksik anahtarlar + Se aktif-uçak düzeltmesi
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v57.py"], cwd="/home/user", capture_output=True, text=True)
print("v57:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag):
    global s
    c = s.count(old)
    if c != 1:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

# 1) Fw: eksik i18n anahtarlari (ham key gorunumunu bitir) — [en,tr,de,es,fr,it,pt,ru,id,ar]
FW_NEW = ('shop:["STORE","MAĞAZA","LADEN","TIENDA","MAGASIN","NEGOZIO","LOJA","МАГАЗИН","TOKO","المتجر"],'
 'packs:["PACKS","PAKETLER","PAKETE","PAQUETES","PACKS","PACCHETTI","PACOTES","НАБОРЫ","PAKET","الحزم"],'
 'weapons:["WEAPONS","SİLAHLAR","WAFFEN","ARMAS","ARMES","ARMI","ARMAS","ОРУЖИЕ","SENJATA","الأسلحة"],'
 'support:["SUPPORT","DESTEK","SUPPORT","APOYO","SOUTIEN","SUPPORT","APOIO","ПОДДЕРЖКА","DUKUNGAN","الدعم"],'
 'buy:["BUY","SATIN AL","KAUFEN","COMPRAR","ACHETER","COMPRA","COMPRAR","КУПИТЬ","BELI","شراء"],'
 'active:["ACTIVE","AKTİF","AKTIV","ACTIVO","ACTIF","ATTIVO","ATIVO","АКТИВЕН","AKTIF","نشط"],'
 'performance:["PERFORMANCE","PERFORMANS","LEISTUNG","RENDIMIENTO","PERFORMANCE","PRESTAZIONI","DESEMPENHO","ТЯГА","PERFORMA","الأداء"],'
 'armor:["ARMOR","ZIRH","PANZERUNG","BLINDAJE","BLINDAGE","CORAZZA","BLINDAGEM","БРОНЯ","LAPISAN","التدريع"],'
 'avionics:["AVIONICS","AVİYONİK","AVIONIK","AVIÓNICA","AVIONIQUE","AVIONICA","AVIÔNICA","АВИОНИКА","AVIONIK","إلكترونيات"],'
 'daily:["DAILY","GÜNLÜK","TÄGLICH","DIARIO","QUOTIDIEN","GIORNALIERO","DIÁRIO","ЕЖЕДНЕВНО","HARIAN","يومي"],'
 'weekly:["WEEKLY","HAFTALIK","WÖCHENTLICH","SEMANAL","HEBDO","SETTIMANALE","SEMANAL","ЕЖЕНЕДЕЛЬНО","MINGGUAN","أسبوعي"],'
 'watchAd:["WATCH AD","REKLAM İZLE","WERBUNG","VER ANUNCIO","PUB","GUARDA ANNUNCIO","VER ANÚNCIO","РЕКЛАМА","TONTON IKLAN","شاهد إعلان"],'
 'claimed:["CLAIMED","ALINDI","ABGEHOLT","RECLAMADO","RÉCLAMÉ","RITIRATO","RESGATADO","ПОЛУЧЕНО","DIAMBIL","مُستلم"],'
 'wDmg:["MISSILE DMG","FÜZE HASARI","RAKETENSCHADEN","DAÑO MISIL","DÉGÂTS MISSILE","DANNO MISSILE","DANO MÍSSIL","УРОН РАКЕТ","DAMAGE RUDAL","ضرر الصواريخ"],'
 'wBomb:["BOMB BAY","BOMBA YUVASI","BOMBENSCHACHT","BAHÍA BOMBAS","SOUTE BOMBES","STIVA BOMBES","PORÃO BOMBAS","БОМБОЛЮК","RUANG BOM","حجرة القنابل"],'
 'wFlr:["FLARE KIT","FLARE KİTİ","TÄUSCHKÖRPER","KIT BENGALAS","LEURRES","KIT FLARE","KIT FLARES","ТЕПЛОЛОВУШКИ","PENGECOH","عدة الشعلات"],'
 'dragHint:["DRAG TO ROTATE","DÖNDÜRMEK İÇİN SÜRÜKLE","ZIEHEN ZUM DREHEN","ARRASTRA PARA GIRAR","FAITES GLISSER","TRASCINA PER RUOTARE","ARRASTE PARA GIRAR","ПЕРЕТАЩИТЕ","SERET UNTUK PUTAR","اسحب للتدوير"],'
 'dailySortie:["DAILY SORTIE","GÜNLÜK SORTİ","TÄGLICHER EINSATZ","SALIDA DIARIA","SORTIE DU JOUR","USCITA GIORNALIERA","SURTIDA DIÁRIA","ЕЖЕДН. ВЫЛЕТ","SORTI HARIAN","طلعة يومية"],'
 'idleTitle:["HANGAR BONUS","HANGAR BONUSU","HANGAR-BONUS","BONO HANGAR","BONUS HANGAR","BONUS HANGAR","BÔNUS HANGAR","БОНУС АНГАРА","BONUS HANGAR","مكافأة الحظيرة"],'
 'aiDuel:["AI DUEL","YZ DÜELLOSU","KI-DUELL","DUELO IA","DUEL IA","DUELLO IA","DUELO IA","ДУЭЛЬ ИИ","DUEL AI","مبارزة الذكاء"],'
 'nextOp:["NEXT OPERATION","SIRADAKİ OPERASYON","NÄCHSTE OPERATION","PRÓXIMA OPERACIÓN","PROCHAINE OPÉRATION","PROSSIMA OPERAZIONE","PRÓXIMA OPERAÇÃO","СЛЕД. ОПЕРАЦИЯ","OP BERIKUTNYA","العملية القادمة"],'
 'bestSorties:["BEST SORTIES","EN İYİ SORTİLER","BESTE EINSÄTZE","MEJORES SALIDAS","MEILLEURES SORTIES","MIGLIORI USCITE","MELHORES SURTIDAS","ЛУЧШИЕ ВЫЛЕТЫ","SORTI TERBAIK","أفضل الطلعات"],'
 'seasonPass:["SEASON PASS","SEZON BİLETİ","SEASON PASS","PASE DE TEMPORADA","PASSE SAISON","PASS STAGIONALE","PASSE DE TEMPORADA","СЕЗОННЫЙ ПРОПУСК","SEASON PASS","تذكرة الموسم"],'
 'tier:["TIER","KADEME","STUFE","NIVEL","RANG","LIVELLO","NÍVEL","УРОВЕНЬ","TIER","المستوى"]')
rep('Fw={', 'Fw={' + FW_NEW + ',', "fwKeys")

# 2) Se: onUpgrade artik AKTIF ucagi gelistirir (preview ile karisma hatasi duzeltildi)
rep('Se=()=>{const ae=s.upgrades[u]||0,Ee=(ae+1)*450;if(!(ae>=3||!s.owned.includes(u))){if(s.credits<Ee){P(Te("insufficient"));return}e(Be=>{const ke=Be.upgrades[u]||0,De=(ke+1)*450;return ke>=3||Be.credits<De?Be:{...Be,credits:Be.credits-De,upgrades:{...Be.upgrades,[u]:ke+1}}}),K.current.play("lock")}}',
    'Se=()=>{const Ae=s.aircraft,ae=s.upgrades[Ae]||0,Ee=(ae+1)*450;if(!(ae>=3||!s.owned.includes(Ae))){if(s.credits<Ee){P(Te("insufficient"));return}e(Be=>{const ke=Be.upgrades[Be.aircraft]||0,De=(ke+1)*450;return ke>=3||Be.credits<De?Be:{...Be,credits:Be.credits-De,upgrades:{...Be.upgrades,[Be.aircraft]:ke+1}}}),K.current.play("lock")}}',
    "seActive")

# 3) Xw: HANGAR 2.0 — tam degisim
i = s.find('function Xw({save:s,preview:e')
j = s.find('const Ww={strike:', i)
if i < 0 or j < 0:
    print("FAIL xw bounds"); sys.exit(1)
XW_NEW = r'''function Xw({save:s,preview:e,onPreview:n,onSelect:a,onUpgrade:o,onStart:c,onShop:qt,onCamo:qc0}){const[adT,setAdT]=pt.useState(0),[tab,setTab]=pt.useState("jets");const u=s.preferences.language,f=v=>Jn(u,v),V=no.find(v=>v.id===e),g=s.owned.includes(e),_=s.aircraft===e,A=s.aircraft,AV=no.find(v=>v.id===A),pA=(s.upgA||{})[A]||0,pV=(s.upgV||{})[A]||0,pP=s.upgrades[A]||0,pips=t=>S.jsx("span",{className:"hg2-pips",children:[0,1,2].map(i=>S.jsx("i",{className:i<t?"on":""},i))}),row=(key,label,t,cost,buy)=>S.jsxs("div",{className:"hg2-row",children:[S.jsxs("div",{className:"hg2-rmain",children:[S.jsx("b",{children:label}),pips(t)]}),S.jsx("button",{className:"hg2-buy"+(t>=3?" max":""),onClick:buy,disabled:t>=3||s.credits<cost,children:t>=3?f("maxUpgrade"):String(cost)})]},key);return S.jsxs("section",{className:"hangar-content hg2",children:[S.jsxs("div",{className:"hg2-top",children:[S.jsxs("div",{className:"hg2-plate",children:[S.jsxs("div",{className:"hg2-id",children:[S.jsx("span",{className:"hg2-code",children:V.code}),S.jsx("strong",{children:V.name})]}),S.jsxs("div",{className:"hg2-sub",children:[S.jsx("em",{children:__L(u,V.role)}),g?S.jsx("b",{className:_?"hg2-act":"hg2-own",children:_?f("active"):f("selected")}):S.jsx("b",{className:"hg2-lock",children:f("locked")+" · "+V.price+" CR"})]})]}),S.jsxs("div",{className:"hg2-right",children:[S.jsxs("div",{className:"hg2-cr",children:[s.credits," CR"]}),S.jsxs("button",{className:"hg2-deploy",onClick:c,children:[S.jsx("span",{children:f("deploy")}),S.jsx("i",{children:"▶"})]})]})]}),S.jsx("div",{className:"hg2-camo",children:CAMO.map((cm,ci)=>S.jsx("button",{className:"hg2-cchip"+((s.camo||0)===ci?" on":""),style:{background:cm.c},onClick:()=>qc0(ci),"aria-label":"camo"},ci))}),S.jsx("div",{className:"hg2-bars",children:[["SPD",V.speed/600],["ARM",V.hull/170],["MSL",V.missiles/16]].map(b=>S.jsxs("div",{children:[S.jsx("span",{children:b[0]}),S.jsx("i",{children:S.jsx("u",{style:{width:Math.max(6,Math.round(b[1]*100))+"%"}})})]},b[0]))}),S.jsxs("div",{className:"hg2-dock",children:[S.jsxs("div",{className:"hg2-hint",children:[S.jsx(Yi,{size:13}),__L(u,Fw.dragHint)]}),tab==="jets"&&S.jsxs("div",{className:"hg2-panel",children:[S.jsx("div",{className:"hg2-strip",children:no.map(v=>S.jsxs("button",{className:"hg2-chip"+(e===v.id?" on":"")+(s.owned.includes(v.id)?"":" lk"),onClick:()=>n(v.id),children:[S.jsx(Hw,{id:v.id}),S.jsx("span",{children:v.code}),s.owned.includes(v.id)?null:S.jsx(Ou,{size:10})]},v.id))}),S.jsxs("div",{className:"hg2-foot",children:[S.jsx("p",{children:__L(u,V.description)}),g?S.jsx("button",{className:"hg2-primary"+(_?" off":""),onClick:a,disabled:_,children:_?f("active"):f("select")}):S.jsx("button",{className:"hg2-primary",onClick:a,disabled:s.credits<V.price,children:f("buy")+" · "+V.price+" CR"})]})]}),tab==="up"&&S.jsx("div",{className:"hg2-panel",children:S.jsxs("div",{className:"hg2-rows",children:[row("p",f("performance")+" · "+(AV?AV.code:""),pP,450*(pP+1),o),row("a",f("armor"),pA,450*(pA+1),()=>qt("upA")),row("v",f("avionics"),pV,450*(pV+1),()=>qt("upV"))]})}),tab==="shop"&&S.jsx("div",{className:"hg2-panel",children:S.jsxs("div",{className:"hg2-shop",children:[S.jsxs("button",{className:"hg2-card",disabled:s.shopPack===GdDaystr(),onClick:()=>qt("pack"),children:[S.jsx("b",{children:f("daily")}),S.jsx("i",{children:s.shopPack===GdDaystr()?f("claimed"):"+750 CR"})]}),S.jsxs("button",{className:"hg2-card",disabled:s.shopWeek===Math.floor(Date.now()/6048e5),onClick:()=>qt("week"),children:[S.jsx("b",{children:f("weekly")}),S.jsx("i",{children:s.shopWeek===Math.floor(Date.now()/6048e5)?f("claimed"):"+3000 CR"})]}),[["wdmg",2500,"wDmg"],["wbomb",1800,"wBomb"],["wflr",1200,"wFlr"]].map(w=>S.jsxs("button",{className:"hg2-card",disabled:!!(s.shopW||{})[w[0]]||s.credits<w[1],onClick:()=>qt(w[0]),children:[S.jsx("b",{children:f(w[2])}),S.jsx("i",{children:(s.shopW||{})[w[0]]?f("claimed"):w[1]+" CR"})]},w[0])),S.jsxs("button",{className:"hg2-card ad",disabled:adT>0||(s.adsDate===GdDaystr()&&(s.adsCount||0)>=3),onClick:()=>{setAdT(5);setTimeout(()=>{qt("ad");setAdT(0)},5000)},children:[S.jsx("b",{children:f("watchAd")}),S.jsx("i",{children:adT>0?adT+"s":s.adsDate===GdDaystr()?Math.max(0,3-(s.adsCount||0))+"/3":"+250 CR"})]})]})}),S.jsx("div",{className:"hg2-tabs",children:[["jets",f("aircraft")],["up",f("upgrade")],["shop",f("shop")]].map(t=>S.jsx("button",{className:"hg2-tab"+(tab===t[0]?" on":""),onClick:()=>setTab(t[0]),children:t[1]},t[0]))})]})]})}'''
s = s[:i] + XW_NEW + s[j:]
print("ok xwReplace")

# 4) HANGAR 2.0 CSS
CSS = r'''
.hg2{pointer-events:none}
.hg2-top{position:absolute;top:0;left:0;right:0;display:flex;justify-content:space-between;align-items:flex-start;gap:10px}
.hg2-plate{max-width:54%;padding:10px 14px;border:1px solid rgba(120,170,190,.25);border-radius:12px;background:linear-gradient(180deg,rgba(13,30,39,.84),rgba(10,22,29,.74));backdrop-filter:blur(6px)}
.hg2-id{display:flex;align-items:baseline;gap:8px}
.hg2-code{font-family:var(--mono);font-size:10px;letter-spacing:.14em;color:#e8a33d}
.hg2-id strong{font-size:16px;letter-spacing:.05em;color:#eaf4f8}
.hg2-sub{display:flex;gap:8px;align-items:center;margin-top:3px;font-size:9px;color:#9fb6c2;font-family:var(--mono);letter-spacing:.1em}
.hg2-act{color:#7fd6a2}.hg2-own{color:#8fc7dd}.hg2-lock{color:#e08b6d}
.hg2-right{display:grid;gap:8px;justify-items:end}
.hg2-cr{padding:6px 12px;border:1px solid rgba(120,170,190,.3);border-radius:999px;background:rgba(13,30,39,.8);font-family:var(--mono);font-size:11px;font-weight:700;color:#ffd98f;letter-spacing:.1em}
.hg2-deploy{pointer-events:auto;display:flex;align-items:center;gap:8px;padding:12px 18px;border:1px solid #e8a33d;border-radius:12px;background:linear-gradient(180deg,#e8a33d,#c7822a);color:#17130b;font-family:var(--mono);font-size:12px;font-weight:700;letter-spacing:.14em;cursor:pointer;box-shadow:0 6px 18px rgba(0,0,0,.35)}
.hg2-deploy i{font-style:normal;font-size:10px}
.hg2-camo{position:absolute;top:80px;left:0;display:flex;gap:6px}
.hg2-cchip{pointer-events:auto;width:24px;height:13px;border-radius:7px;border:1px solid rgba(255,255,255,.25);cursor:pointer;opacity:.5}
.hg2-cchip.on{opacity:1;box-shadow:0 0 0 2px rgba(232,163,61,.7)}
.hg2-bars{position:absolute;top:80px;right:0;display:grid;gap:4px;justify-items:end}
.hg2-bars>div{display:flex;gap:6px;align-items:center;font-family:var(--mono);font-size:9px;color:#9fb6c2;letter-spacing:.12em}
.hg2-bars i{display:block;width:74px;height:4px;border-radius:2px;background:rgba(255,255,255,.12)}
.hg2-bars u{display:block;height:100%;border-radius:2px;background:linear-gradient(90deg,#4fa3c7,#e8a33d);text-decoration:none}
.hg2-dock{position:absolute;left:0;right:0;bottom:0;display:grid;gap:8px}
.hg2-hint{display:flex;gap:6px;justify-content:center;align-items:center;font-family:var(--mono);font-size:8px;letter-spacing:.18em;color:#8aa2ad}
.hg2-panel{pointer-events:auto;border:1px solid rgba(120,170,190,.22);border-radius:14px;background:linear-gradient(180deg,rgba(13,30,39,.88),rgba(9,20,27,.82));backdrop-filter:blur(8px);padding:10px;max-height:32vh;overflow:auto;scrollbar-width:thin}
.hg2-tabs{pointer-events:auto;display:flex;gap:6px}
.hg2-tab{flex:1;padding:10px 6px;border:1px solid rgba(120,170,190,.25);border-radius:10px;background:rgba(13,30,39,.78);color:#9fb6c2;font-family:var(--mono);font-size:10px;font-weight:700;letter-spacing:.14em;cursor:pointer}
.hg2-tab.on{color:#17130b;background:linear-gradient(180deg,#e8a33d,#c7822a);border-color:#e8a33d}
.hg2-strip{display:flex;gap:6px;overflow-x:auto;padding:2px 2px 6px;scrollbar-width:thin}
.hg2-chip{pointer-events:auto;position:relative;flex:0 0 auto;width:54px;padding:7px 4px 5px;display:grid;justify-items:center;gap:3px;border:1px solid rgba(120,170,190,.25);border-radius:10px;background:rgba(17,38,49,.6);color:#cfe3ee;cursor:pointer}
.hg2-chip span{font-family:var(--mono);font-size:8px;letter-spacing:.06em}
.hg2-chip.on{border-color:#e8a33d;background:rgba(232,163,61,.14);color:#ffd98f}
.hg2-chip.lk{opacity:.45}
.hg2-chip svg{position:absolute;top:3px;right:3px}
.hg2-foot{display:flex;gap:10px;align-items:center;justify-content:space-between}
.hg2-foot p{margin:0;font-size:10px;line-height:1.45;color:#9fb6c2;max-width:55%}
.hg2-primary{pointer-events:auto;white-space:nowrap;padding:11px 20px;border:1px solid #e8a33d;border-radius:10px;background:linear-gradient(180deg,#e8a33d,#c7822a);color:#17130b;font-family:var(--mono);font-size:12px;font-weight:700;letter-spacing:.1em;cursor:pointer}
.hg2-primary.off{opacity:.6;cursor:default}
.hg2-primary:disabled{opacity:.4;cursor:not-allowed}
.hg2-rows{display:grid;gap:8px}
.hg2-row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:9px 12px;border:1px solid rgba(120,170,190,.2);border-radius:10px;background:rgba(17,38,49,.55)}
.hg2-rmain{display:grid;gap:5px}
.hg2-rmain b{font-family:var(--mono);font-size:11px;letter-spacing:.12em;color:#dceaf1}
.hg2-pips{display:flex;gap:4px}
.hg2-pips i{width:16px;height:5px;border-radius:3px;background:rgba(255,255,255,.15)}
.hg2-pips i.on{background:linear-gradient(90deg,#4fa3c7,#e8a33d)}
.hg2-buy{pointer-events:auto;padding:8px 14px;border:1px solid #4fa3c7;border-radius:9px;background:rgba(79,163,199,.14);color:#bfe4f3;font-family:var(--mono);font-size:11px;font-weight:700;cursor:pointer}
.hg2-buy:disabled{opacity:.4;cursor:not-allowed}
.hg2-buy.max{border-color:#3c5a66;color:#8aa2ad}
.hg2-shop{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px}
.hg2-card{display:grid;gap:4px;text-align:left;padding:10px 12px;border:1px solid rgba(120,170,190,.22);border-radius:10px;background:linear-gradient(180deg,rgba(22,50,62,.9),rgba(16,36,46,.9));color:#cfe3ee;cursor:pointer}
.hg2-card b{font-family:var(--mono);font-size:10px;font-weight:700;letter-spacing:.1em;color:#eaf4f8}
.hg2-card i{font-family:var(--mono);font-size:9px;font-style:normal;color:#e8a33d;letter-spacing:.08em}
.hg2-card.ad i{color:#a4e1f1}
.hg2-card:disabled{opacity:.45;cursor:default}'''
rep('.mission-weather{position:absolute;right:10px;bottom:10px;font-size:12px}\n</style>',
    '.mission-weather{position:absolute;right:10px;bottom:10px;font-size:12px}' + CSS + '\n</style>',
    "hg2Css")

# 5) badge
c33 = s.count("3.32 DEV")
if c33 < 2:
    print("FAIL badge", c33); sys.exit(1)
s = s.replace("3.32 DEV", "3.33 DEV")
print("ok badge x", c33)

io.open(P, "w", encoding="utf-8").write(s)
print("v58 size", len(s))
