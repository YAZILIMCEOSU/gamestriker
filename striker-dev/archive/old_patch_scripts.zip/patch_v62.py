#!/usr/bin/env python3
# v3.37 — HANGAR 3.0 (efsane tasarim): 4 stat bar (HIZ/CEVIKLIK/ZIRH/FUZE),
# cift ucak karsilastirma (preview altin vs aktif camgobegi), glow efektleri. Mobil+tablet.
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v61.py"], cwd="/home/user", capture_output=True, text=True)
print("v61:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag):
    global s
    c = s.count(old)
    if c != 1:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

# 1) hg2-bars -> hg3 stat paneli + karsilastirma
rep('S.jsx("div",{className:"hg2-bars",children:[["SPD",V.speed/600],["ARM",V.hull/170],["MSL",V.missiles/16]].map(b=>S.jsxs("div",{children:[S.jsx("span",{children:b[0]}),S.jsx("i",{children:S.jsx("u",{style:{width:Math.max(6,Math.round(b[1]*100))+"%"}})})]},b[0]))}),',
    'S.jsxs("div",{className:"hg3-stats"+(g&&!_?" cmp":""),children:[g&&!_?S.jsxs("div",{className:"hg3-legend",children:[S.jsxs("b",{children:[S.jsx("i",{className:"g"}),V.code]}),S.jsxs("b",{children:[S.jsx("i",{className:"c"}),AV?AV.code:""]})]}):null,[["speed",V.speed/320,AV?AV.speed/320:0],["agility",(V.agility||0)/1.9,AV?(AV.agility||0)/1.9:0],["hull",V.hull/170,AV?AV.hull/170:0],["missile",V.missiles/16,AV?AV.missiles/16:0]].map(r=>S.jsxs("div",{className:"hg3-row",children:[S.jsx("span",{children:f(r[0])}),S.jsxs("div",{className:"hg3-tracks",children:[S.jsx("i",{className:"g",children:S.jsx("u",{style:{width:Math.max(6,Math.round(r[1]*100))+"%"}})}),g&&!_?S.jsx("i",{className:"c",children:S.jsx("u",{style:{width:Math.max(6,Math.round(r[2]*100))+"%"}})}):null]})]},r[0]))]}),',
    "hg3stats")

# 2) glow + hg3 CSS
rep('.hg2-card:disabled{opacity:.45;cursor:default}\n',
    '.hg2-card:disabled{opacity:.45;cursor:default}\n.hg3-stats{position:absolute;top:80px;right:0;width:176px;display:grid;gap:7px;padding:10px 12px;border:1px solid rgba(120,170,190,.22);border-radius:12px;background:linear-gradient(180deg,rgba(13,30,39,.74),rgba(10,22,29,.62));backdrop-filter:blur(6px)}\n.hg3-legend{display:flex;gap:12px;justify-content:flex-end;font-family:var(--mono);font-size:8px;font-weight:700;letter-spacing:.12em;color:#cfe3ee}\n.hg3-legend i{display:inline-block;width:9px;height:3px;border-radius:2px;margin-right:4px;vertical-align:middle}\n.hg3-legend .g{background:#e8a33d;box-shadow:0 0 6px rgba(232,163,61,.8)}\n.hg3-legend .c{background:#4fa3c7;box-shadow:0 0 6px rgba(79,163,199,.8)}\n.hg3-row{display:grid;gap:3px}\n.hg3-row>span{font-family:var(--mono);font-size:7px;font-weight:600;letter-spacing:.16em;color:#9fb6c2}\n.hg3-tracks{display:grid;gap:3px}\n.hg3-tracks i{display:block;height:5px;border-radius:3px;background:rgba(255,255,255,.1);overflow:hidden}\n.hg3-tracks i.c{height:3px}\n.hg3-tracks u{display:block;height:100%;text-decoration:none;border-radius:3px}\n.hg3-tracks .g u{background:linear-gradient(90deg,#c7822a,#ffd98f);box-shadow:0 0 8px rgba(232,163,61,.8)}\n.hg3-tracks .c u{background:linear-gradient(90deg,#2c6d8a,#a4e1f1);box-shadow:0 0 6px rgba(79,163,199,.8)}\n.hg2-chip.on{box-shadow:0 0 14px rgba(232,163,61,.5)}\n.hg2-primary{box-shadow:0 0 16px rgba(232,163,61,.35);animation:hgPulse 2.2s ease-in-out infinite}\n@keyframes hgPulse{0%,100%{box-shadow:0 0 10px rgba(232,163,61,.25)}50%{box-shadow:0 0 22px rgba(232,163,61,.55)}}\n.hg2-deploy{box-shadow:0 6px 18px rgba(0,0,0,.35),0 0 18px rgba(232,163,61,.4)}\n@media (max-width:820px){.hg3-stats{width:150px;padding:8px 10px;gap:5px;top:84px}}\n',
    "hg3css")

# 3) badge
c = s.count("3.36 DEV")
if c < 2:
    print("FAIL badge", c); sys.exit(1)
s = s.replace("3.36 DEV", "3.37 DEV")
print("ok badge x", c)

io.open(P, "w", encoding="utf-8").write(s)
print("v62 size", len(s))
