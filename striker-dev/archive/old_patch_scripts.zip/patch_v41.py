#!/usr/bin/env python3
# v3.16 — tohumlu arazi (görev başına farklı harita), 6 biyom, helikopter + SİHA, hangar yeniden düzenleme
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v40.py"], cwd="/home/user", capture_output=True, text=True)
print("v40:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def bal(t):
    d=0;b=0;q=0;in_s=None;esc=False
    for ch in t:
        if in_s:
            if esc:esc=False
            elif ch=='\\':esc=True
            elif ch==in_s:in_s=None
            continue
        if ch in '"\'':in_s=ch
        elif ch=='`':q^=1
        elif not q:
            if ch in '([':d+=1
            elif ch in ')]':d-=1
            elif ch=='{':b+=1
            elif ch=='}':b-=1
    return d==0 and b==0

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    if not bal(old) or not bal(new):
        # denge sadece göreli olmalı: fark eşit olmalı
        pass
    s=s.replace(old,new)
    print("ok",tag)

def repn(old,new,tag,n):
    global s
    c=s.count(old)
    if c!=n:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

# 1) PK tohumlu tepe üreteci — motor sınıfından önce modül kapsamına
rep('class Pa{constructor(e,n,a,o=0,q5)',
'''function PK(id){let s=(id*2654435761)>>>0;const r=()=>(s=(s*1664525+1013904223)>>>0,s/4294967296),n=6+Math.floor(r()*4),out=[];for(let i=0;i<n;i++){let x=0,z=0,v=0;for(let k=0;k<24;k++){const g=r()*6.28318;v=1900+r()*4400;x=Math.cos(g)*v;z=Math.sin(g)*v-2800;if(Math.hypot(x,z-1150)>2500)break}out.push([x,z,540+r()*1200,150+r()*520,i])}return out}class Pa{constructor(e,n,a,o=0,q5)''',"PK")

# 2) motor terr(): sabit liste -> tohumlu
rep('for(const[d,p,g,o,c]of[[-1900,-2200,920,420,0],[1600,-3200,1400,510,1],[-3200,1300,1400,330,2],[3100,-850,780,210,3],[400,-6200,1600,690,4],[-3500,-6600,1800,520,5]])',
'for(const[d,p,g,o,c]of(this.peaks||(this.peaks=PK(this.mission.id||0))))',"terrSeed")

# 3) görev üretici: biome alanı
rep('sunset:[.12,0,.6,1][sn]}}','sunset:[.12,0,.6,1][sn],biome:e%6}}',"biomeField")

# 4) hedef havuzları: heli + uav
rep('intercept:["interceptor","attacker","interceptor","heavy","attacker","interceptor"]',
    'intercept:["interceptor","attacker","uav","heavy","attacker","heli"]',"poolIntercept")
rep('defense:["destroyer","corvette","bomber","interceptor","bomber","destroyer"]',
    'defense:["destroyer","corvette","heli","interceptor","bomber","uav"]',"poolDefense")
rep('radar:["radar","destroyer","drone","corvette","drone","radar","sub"]',
    'radar:["radar","destroyer","uav","corvette","drone","heli","sub"]',"poolRadar")
rep('u%3===2?"drone":u%2?"interceptor":"destroyer"',
    'u%5===4?"uav":u%3===2?"drone":u%2?"interceptor":"destroyer' + '"',"poolExtra")

# 5) motor spawn: airborne listesi + irtifa
rep('const f=["interceptor","heavy","attacker","drone","bomber"].includes(c),g=f?190+u*28:c==="radar"?26:8;',
    'const f=["interceptor","heavy","attacker","drone","bomber","heli","uav"].includes(c),g=f?(c==="heli"?85:c==="uav"?330:190+u*28):c==="radar"?26:8;',"spawnAlt")
rep('c==="radar"?130:100)*','c==="radar"?130:c==="heli"?120:c==="uav"?80:100)*',"hpKinds")
rep('radius:c==="carrier"?90:c==="sub"?26:f?22:',
    'radius:c==="carrier"?90:c==="sub"?26:c==="heli"?16:c==="uav"?13:f?22:',"radiusKinds")
rep('n.phase+=e*(n.airborne?.24:.022)',
    'n.phase+=e*(n.airborne?(n.kind==="heli"?.1:n.kind==="uav"?.5:.24):.022)',"phaseRate")
rep('n.position.y+=(n.origin.y+Math.sin(n.phase*1.3)*55-n.position.y)*Math.min(1,e*1.5)',
    'n.position.y+=((n.kind==="heli"?85:n.origin.y)+Math.sin(n.phase*1.3)*(n.kind==="heli"?10:55)-n.position.y)*Math.min(1,e*1.5)',"hoverY")
rep('(n.kind==="drone"?.55:1)','(n.kind==="drone"?.55:n.kind==="uav"?.5:n.kind==="heli"?.85:1)',"fireRate")

# 6) renderer: heli + uav modelleri (enemyAircraft başına)
rep('enemyAircraft(e){const n=new Vi,a=["interceptor","heavy","attacker","drone","bomber"].indexOf(e)',
'''enemyAircraft(e){if(e==="heli"){const n=new Vi,b=this.material(new aa({color:"#5d6a55",metalness:.35,roughness:.6,map:this.panel})),d=this.material(new aa({color:"#3a4238",metalness:.4,roughness:.5})),body=this.mesh(new oi(1.9,7,10,12),b,[0,0,0]);body.rotation.x=Math.PI/2,n.add(body);const nose=this.mesh(new ia(1.9,2.4,10),b,[0,0,4.6]);nose.rotation.x=Math.PI/2,n.add(nose);n.add(this.mesh(new bl(.22,3.4,6),d,[0,.6,-6.6])),n.add(this.mesh(new bl(.18,2.2,6),d,[0,1.9,0]));const rot=new Vi;rot.name="rotor";for(let i=0;i<4;i++){const B=this.mesh(new bl(12.5,.1,.5),d,[0,0,0]);B.rotation.y=i*Math.PI/4,rot.add(B)}rot.position.set(0,3,0),n.add(rot);for(const q of[-1,1])n.add(this.mesh(new bl(.16,5.4,6),d,[q*1.5,-2.1,0]));return n}if(e==="uav"){const n=new Vi,b=this.material(new aa({color:"#9aa0a6",metalness:.45,roughness:.45,map:this.panel})),d=this.material(new aa({color:"#4a4f55",metalness:.5,roughness:.4})),body=this.mesh(new oi(.55,3.6,8,10),b,[0,0,0]);body.rotation.x=Math.PI/2,n.add(body);n.add(this.mesh(new bl(13.5,.07,.9),b,[0,0,-.3])),n.add(this.mesh(new bl(.07,1.5,.9),b,[0,.7,-2.6]));const t=this.mesh(new ia(.5,1.2,8),d,[0,-.6,1.9]);return t.rotation.x=-Math.PI/2,n.add(t),n}const n=new Vi,a=["interceptor","heavy","attacker","drone","bomber","heli","uav"].indexOf(e)''',"heliUavMesh")

# 7) rotor animasyonu
rep('const u=c.getObjectByName("radar-dish");u&&(u.rotation.y=this.time*.55),',
    'const u=c.getObjectByName("radar-dish");u&&(u.rotation.y=this.time*.55);const Rt=c.getObjectByName("rotor");Rt&&(Rt.rotation.y=this.time*30),',"rotorSpin")

# 8) renderer adaları: sabit liste -> buildIslands; biyom paleti + sis
rep('[[-1900,-2200,920,420],[1600,-3200,1400,510],[-3200,1300,1400,330],[3100,-850,780,210],[400,-6200,1600,690],[-3500,-6600,1800,520]].forEach(([d,p,g,_],v)=>this.createIsland(d,p,g,_,v))',
    'this.buildIslands(0,0)',"islandsDyn")
rep('createIsland(e,n,a,o,c){const u=new qi(a*2,a*2,60,60)',
'''biomePal=[["#a4a294","#44594c","#7f8a83"],["#c9b28a","#8a7a4e","#a08a63"],["#d3dde0","#9fb2b8","#8e9aa0"],["#8a8464","#2f4a33","#5f6b57"],["#a06a52","#7a4a3a","#6b5a52"],["#5d6a72","#2a3940","#4a555e"]];islePal=null;buildIslands(e,n){this.islands.children.slice().forEach(a=>this.islands.remove(a));const a=this.biomePal[n||0]||this.biomePal[0];this.islePal=a;PK(e).forEach(([o,c,u,f],b)=>this.createIsland(o,c,u,f,b));const g=["#8fb0bf","#c9bd95","#dde7ea","#a3b5a5","#b09080","#404c58"][n||0]||"#8fb0bf";this.sceneE&&this.sceneE.fog&&this.sceneE.fog.color.set(g)}createIsland(e,n,a,o,c){const u=new qi(a*2,a*2,60,60)''',"biomePal")
rep('const f=u.attributes.position,d=[],p=new ht("#a4a294"),g=new ht("#44594c"),_=new ht("#7f8a83");',
    'const f=u.attributes.position,d=[],L0=this.islePal||["#a4a294","#44594c","#7f8a83"],p=new ht(L0[0]),g=new ht(L0[1]),_=new ht(L0[2]);',"isleColors")
rep('this.environment.setSunset(e.mission.sunset),',
    'this.environment.setSunset(e.mission.sunset),this.environment.buildIslands(e.mission.id||0,e.mission.biome||0),(e.mission.biome||0)===5&&this.environment.setSunset(!0),',"beginBiome")

# 9) görev kartına biyom rozeti
rep('S.jsxs("span",{className:"mission-number",children:[c("operation")," ",String(u.id+1).padStart(2,"0")]}),',
    'S.jsxs("span",{className:"mission-number",children:[c("operation")," ",String(u.id+1).padStart(2,"0")]}),S.jsx("span",{className:"mission-biome",children:c("biome"+(u.biome||0))}),',"biomeChip")

# 10) i18n biyom adları (EN,TR,DE,ES,FR,IT,PT,RU,ID,AR)
rep('const Fw={base:',
'''const Fw={biome0:["SEA BASE","DENİZ ÜSSÜ","SEEBASIS","BASE MARÍTIMA","BASE MARITIME","BASE MARE","BASE MARÍTIMA","МОРСКАЯ БАЗА","PANGKALAN LAUT","قاعدة بحرية"],biome1:["DESERT LINE","ÇÖL HATTI","WÜSTENLINE","LÍNEA DESIERTO","LIGNE DÉSERT","LINEA DESERTO","LINHA DESERTO","ПУСТЫНЯ","GURUN","الصحراء"],biome2:["ARCTIC","KUTUP","ARKTIS","ÁRTICO","ARCTIQUE","ARTICO","ÁRTICO","АРКТИКА","KUTUB","القطب"],biome3:["JUNGLE","ORMAN","DSCHUNGEL","SELVA","JUNGLE","GIUNGLA","SELVA","ДЖУНГЛИ","HUTAN","الغابة"],biome4:["CANYON","KANYON","CANYON","CAÑÓN","CANYON","CANYON","CANYON","КАНЬОН","NGARAI","الوادي"],biome5:["NIGHT OPS","GECE HAREKÂTI","NACHTEINSATZ","OPS NOCTURNOS","OPS DE NUIT","OPS NOTTURNE","OPS NOTURNAS","НОЧНАЯ ОПЕРАЦИЯ","OPS MALAM","عمليات ليلية"],base:''',"i18nBiome")

# 11) hangar sıralaması: uçak seçici üste, mağaza altta (python cerrahisi)
a = s.index('S.jsxs("div",{className:"store-panel"')
b = s.index('S.jsxs("div",{className:"model-inspect-hint"')
c = s.index('S.jsx("div",{className:"aircraft-selector"')
dend = s.index(']},v.id))})', c) + len(']},v.id))})')
store = s[a:b]; hint = s[b:c]; sel = s[c:dend]
hs = s.index('className:"hangar-content",children:[') + len('className:"hangar-content",children:[')
assert hs <= a, "hangar children order unexpected"
s = s[:hs] + sel + ',' + hint + store + s[dend:]
print("ok hangarReorder")

# 12) CSS
css_add = '''.hangar-content{gap:16px;overflow-y:auto;scrollbar-width:thin}
.hangar-content .aircraft-selector,.hangar-content .store-panel{pointer-events:auto}
.aircraft-selector{display:grid;grid-template-columns:repeat(auto-fill,minmax(265px,1fr));gap:12px;margin-top:2px;position:relative;bottom:auto;left:auto;right:auto;overflow-x:visible;padding:0}
.model-inspect-hint{position:relative;bottom:auto;right:auto;max-width:none;margin:4px auto 0}
.aircraft-choice{min-height:110px;padding:14px 16px}
.aircraft-choice .ac-main strong{font-size:17px;letter-spacing:.07em}
.aircraft-choice svg{width:66px;height:46px;flex:none}
.mission-card-map{position:relative}
.mission-biome{position:absolute;left:10px;bottom:10px;font-size:10px;font-weight:700;letter-spacing:.14em;color:#dfe9f2;background:rgba(10,18,26,.62);border:1px solid rgba(255,255,255,.16);padding:3px 8px;border-radius:999px}
@media(max-width:720px){.aircraft-selector{grid-template-columns:1fr}.aircraft-choice svg{width:54px;height:38px}}
'''
i = s.rfind('</style>')
s = s[:i] + css_add + s[i:]
print("ok css41")

# 13) rozet
c16 = s.count("3.15 DEV")
if c16 < 2:
    print("FAIL badge", c16); sys.exit(1)
s = s.replace("3.15 DEV", "3.16 DEV")
print("ok badge x", c16)

io.open(P, "w", encoding="utf-8").write(s)
print("v41 size", len(s))
