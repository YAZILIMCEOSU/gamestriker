P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old); assert n==1, f"count {n}: {old[:50]}"
    s=s.replace(old,new)
# 1) per-frame hook right before particles update
rep('this.particles.update(e),this.flash.intensity*=',
    'this.cloudTick(e),this.particles.update(e),this.flash.intensity*=')
# 2) cloud layer method on engine (placed before setMode)
method = (
 'cloudTick(e){if(!this.player||!this.assets)return;'
 'if(!this.cloudGroup){this.cloudGroup=new Vi;this.cloudGroup.name="clouds";this.scene.add(this.cloudGroup);'
 'this.cloudPuffs=[];const g=this.assets.geometry(new ia(1,14,10));'
 'for(let c=0;c<16;c++){const grp=new Vi;const mat=this.assets.material(new tx({color:"#f2f6f8",transparent:!0,opacity:.3,roughness:1,metalness:0,depthWrite:!1}));'
 'for(let p=0;p<6;p++){const m=new pn(g,mat);m.position.set((Math.random()-.5)*70,(Math.random()-.5)*14,(Math.random()-.5)*44);m.scale.setScalar(12+Math.random()*18);m.castShadow=!1;m.receiveShadow=!1;grp.add(m)}'
 'grp.position.set((Math.random()-.5)*2400,70+Math.random()*170,(Math.random()-.5)*2400);grp.userData.mat=mat;grp.userData.drift=(Math.random()-.5)*4;this.cloudGroup.add(grp);this.cloudPuffs.push(grp)}}'
 'const on=this.mode==="game";this.cloudGroup.visible=on;if(!on)return;'
 'const dt=Math.min(.05,Math.max(0,e||0)),pp=this.player.position;'
 'for(const grp of this.cloudPuffs){grp.position.x+=grp.userData.drift*dt;'
 'const dx=grp.position.x-pp.x,dy=grp.position.y-pp.y,dz=grp.position.z-pp.z,d=Math.sqrt(dx*dx+dy*dy+dz*dz);'
 'const near=Math.max(0,1-d/190);grp.userData.mat.opacity=.28+near*.4}}'
)
rep('setMode(e){this.mode!==e&&(this.mode=e,', method+'setMode(e){this.mode!==e&&(this.mode=e,')
# 3) badge
s=s.replace('3.41 DEV','3.42 DEV')
open(P,'w',encoding='utf-8').write(s)
print('v67 ok size',len(s))
