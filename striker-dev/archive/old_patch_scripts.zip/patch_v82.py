P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old); assert n==1, f"count {n}: {old[:80]}"
    s=s.replace(old,new)

GT = r'''groundTarget(e){
const g=new Vi;
const B=(sz,m,p,o)=>{const x=this.box(sz,m,p,o);g.add(x);return x};
const M=(geo,m,p)=>{const x=this.mesh(geo,m,p);g.add(x);return x};
const P=(c,mt=.3,rg=.65)=>this.material(new aa({color:c,metalness:mt,roughness:rg}));
const conc=P("#8d949a",.05,.9), white=P("#d7dde2"), tankW=P("#c3ccd1",.4,.45), rust=P("#6b4b3a",.2,.8);
const glass=P("#1d2a33",.6,.2), red=P("#b5452f"), blue=P("#2f6b8f"), yel=P("#c9a227"), olive=P("#5d6a55",.2,.8);
if(e==="radar"){
B([90,3,90],this.dark,[0,-1.5,0]);
for(const[x,z]of[[-8,-8],[8,-8],[-8,8],[8,8]])M(new oi(.7,.9,46,6),this.steel,[x,23,z]);
for(let y=8;y<=40;y+=8){B([17,.6,.6],this.steel,[0,y,-8]);B([17,.6,.6],this.steel,[0,y,8]);B([.6,.6,17],this.steel,[-8,y,0]);B([.6,.6,17],this.steel,[8,y,0])}
B([13,10,17],this.steel,[0,5,0]);
B([14,.5,18],white,[0,10.5,0]);
M(new oi(1.1,2.2,17,12),this.steel,[0,40,0]);
const f=M(new ia(10,20,12,0,Math.PI*2,0,Math.PI*.4),this.pale,[0,46,0]);f.rotation.x=1;f.name="radar-dish";
for(let i=0;i<8;i++){const a=i/8*Math.PI*2;M(new oi(.25,.25,6,4),this.steel,[Math.cos(a)*46,3,Math.sin(a)*46])}
return g}
if(e==="bridge"){
const deckY=16;
B([560,4,24],this.steel,[0,deckY,0]);
B([560,1,2.4],white,[0,deckY+2.5,-11]);B([560,1,2.4],white,[0,deckY+2.5,11]);
for(let x=-270;x<=270;x+=30){
B([1.2,12,1.2],this.steel,[x,deckY+8,-12]);B([1.2,12,1.2],this.steel,[x,deckY+8,12]);
}
B([560,1.2,1.2],this.steel,[0,deckY+14,-12]);B([560,1.2,1.2],this.steel,[0,deckY+14,12]);
for(const[x,z]of[[-280,-10],[-120,-10],[120,-10],[280,-10],[-280,10],[-120,10],[120,10],[280,10]])M(new oi(7,8,46,8),conc,[x,-18,z]);
for(const q of[-160,160]){M(new oi(3,4,62,8),this.steel,[q,deckY+30,-12]);M(new oi(3,4,62,8),this.steel,[q,deckY+30,12]);B([4,3,30],this.steel,[q,deckY+56,0])}
return g}
if(e==="refinery"){
B([260,2,180],conc,[0,1,0]);
for(const[x,z]of[[-80,-40],[-42,-40],[-4,-40],[34,-40],[72,-40],[-60,30],[-20,30],[20,30]]){
M(new oi(13,13,20,20),tankW,[x,10,z]);M(new ia(13,13,8,0,Math.PI*2,0,Math.PI*.5),tankW,[x,20,z]);
M(new oi(13.4,13.4,1,20),this.steel,[x,4,z]);
}
for(const z of[-6,0,6]){B([200,1.2,1.2],rust,[0,8,z+60])}
for(let x=-110;x<=110;x+=20){B([1.2,8,1.2],rust,[x,4,66]);}
M(new oi(2.2,3,70,10),this.steel,[70,36,-50]);
M(new ia(4,8,6),this.orange,[70,72,-50]);
B([14,6,12],olive,[-100,3,-70]);B([10,4,8],yel,[98,2,62]);
return g}
if(e==="airfield"){
B([900,1,60],this.dark,[0,.5,0]);
for(let x=-420;x<=420;x+=60)B([28,.3,1.2],white,[x,1.2,0]);
for(const x of[-240,-150,-60]){
M(new oi(15,15,50,12),olive,[x,12,-80]).rotation.z=Math.PI/2;
B([50,15,1],this.steel,[x,7.5,-105]);
}
M(new oi(4,5,40,10),white,[140,20,-60]);
M(new oi(7,5,6,12),glass,[140,43,-60]);
B([24,1.2,24],conc,[120,4,30]);
for(const[x,z]of[[90,40],[120,50],[150,40]]){
B([14,2.2,2.2],this.steel,[x,2.8,z]);B([4,.3,12],this.steel,[x,2.8,z]);B([2.4,2.6,.3],this.steel,[x-5,4.4,z])}
return g}
if(e==="sam"){
B([120,1,80],conc,[0,.5,0]);
for(const[x,z]of[[-30,-18],[30,-18],[-30,18],[30,18]]){
B([12,4,6],olive,[x,3,z]);
for(let t=0;t<4;t++)M(new oi(.9,.9,9,8),olive,[x-3+t*2,8,z]).rotation.x=0;
}
B([14,8,8],white,[0,4,-40]);M(new ia(7,14,10,0,Math.PI*2,0,Math.PI*.45),this.pale,[0,11,-40]).rotation.x=1;
for(const x of[-40,40])M(new oi(3,3,12,10),white,[x,6,35]);
for(let x=-55;x<=55;x+=10)B([.4,4,.4],this.steel,[x,2,-58]);
return g}
if(e==="port"){
B([260,4,40],conc,[0,2,0]);
for(const x of[-90,-30,30,90]){M(new oi(1.5,1.5,44,6),this.steel,[x-16,22,-22]);M(new oi(1.5,1.5,44,6),this.steel,[x+16,22,-22]);B([40,4,4],this.steel,[x,44,-22]);}
B([120,3,3],yel,[0,46,-22]);
const cols=[red,blue,yel,white];
for(let r=0;r<3;r++)for(let c=0;c<6;c++)B([12,6,5],cols[(r*6+c)%4],[-100+c*14,7+r*6,8+(r%2)*6]);
B([24,6,10],this.dark,[70,4,-10]);
return g}
if(e==="depot"){
B([160,1,110],conc,[0,.5,0]);
B([60,14,30],white,[-30,7,-20]);B([64,1,34],this.dark,[-30,14.5,-20]);
for(const x of[20,40,60,80])M(new oi(9,9,14,16),tankW,[x,7,20]);
for(const x of[-70,-10])B([10,8,18],olive,[x,4,35]);
for(let x=-80;x<=80;x+=20){B([.5,6,.5],this.steel,[x,3,-54]);}
B([160,.6,.6],this.steel,[0,6,-54]);
return g}
if(e==="tower"){
B([12,4,12],conc,[0,2,0]);
for(const[x,z]of[[-8,-8],[8,-8],[-8,8],[8,8]])M(new oi(.6,1.4,120,6),this.steel,[x*.35,60,z*.35]);
for(let y=12;y<=110;y+=14){B([16,.5,.5],this.steel,[0,y,-3]);B([16,.5,.5],this.steel,[0,y,3]);B([.5,.5,16],this.steel,[-3,y,0]);B([.5,.5,16],this.steel,[3,y,0])}
M(new oi(.3,.3,22,6),this.steel,[0,131,0]);
M(new ia(1.5,3,8),this.orange,[0,122,0]);
B([10,5,10],white,[12,3,12]);
return g}
return g}
'''

rep('ship(e,n=!1){const a=new Vi;',
    GT + 'ship(e,n=!1){const a=new Vi;if(["radar","bridge","refinery","airfield","sam","port","depot","tower"].includes(e))return this.groundTarget(e);')
rep('const lk=["refinery","airfield","radar"].includes(c)',
    'const lk=["refinery","airfield","radar","sam","depot","tower","port"].includes(c)')
rep('c==="radar"?26:8',
    'c==="radar"||c==="refinery"||c==="airfield"||c==="port"?26:c==="sam"||c==="depot"||c==="tower"?16:8')
rep('strike:["corvette","refinery","corvette","radar","airfield","bridge","sub"]',
    'strike:["corvette","refinery","sam","radar","airfield","bridge","sub"]')
assert s.count('3.55 DEV')==2
s=s.replace('3.55 DEV','3.56 DEV')
open(P,'w',encoding='utf-8').write(s); print('v82 ok', len(s))
