#!/usr/bin/env python3
# v3.17 — K1: basarimlar, camo sistemi, hangar detay karti, yeni SFX
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v41.py"], cwd="/home/user", capture_output=True, text=True)
print("v41:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

# 1) profil varsayilan alanlari
rep('dailyHistory:[],stats:{m:0,w:0,sp:0},',
    'dailyHistory:[],stats:{m:0,w:0,sp:0},kills:0,landed:0,camo:0,ach:{},',"eyFields")

# 2) normalizer yeni alanlar
rep('stats:u.stats&&typeof u.stats==="object"?u.stats:{m:0,w:0,sp:0},',
    'stats:u.stats&&typeof u.stats==="object"?u.stats:{m:0,w:0,sp:0},kills:Number.isFinite(u.kills)?u.kills:0,landed:Number.isFinite(u.landed)?u.landed:0,camo:Number.isFinite(u.camo)?Math.min(5,Math.max(0,u.camo)):0,ach:u.ach&&typeof u.ach==="object"?u.ach:{},',"cbFields")

# 3) sonuc isleyici: kills + landed istatistikleri
rep('stats:{m:(Be.stats?.m||0)+1,w:(Be.stats?.w||0)+(ae.success?1:0),sp:Math.max(Be.stats?.sp||0,ae.score)},',
    'stats:{m:(Be.stats?.m||0)+1,w:(Be.stats?.w||0)+(ae.success?1:0),sp:Math.max(Be.stats?.sp||0,ae.score)},kills:(Be.kills||0)+(ae.kills||0),landed:(Be.landed||0)+(ae.reason==="landed"?1:0),',"resStats")

# 4) CAMO + ACH sabitleri (modul kapsami, PK'dan once)
rep('function PK(id){',
'''const CAMO=[{c:"#7a8891"},{c:"#39424c"},{c:"#b09a72"},{c:"#5d6a4f"},{c:"#c8d2d8"},{c:"#8a3a34"}];const ACH=[["m1",1,100],["m10",10,250],["m25",25,600],["st30",30,400],["st90",90,900],["k100",100,300],["k500",500,800],["ld1",1,200],["ld5",5,500],["w1",1,300],["o3",3,400],["c5",5000,250]];function ACHVAL(k,s){const R=Object.keys(s.records).length,ST=Object.values(s.records).reduce((z,x)=>z+(x.stars||0),0);return k==="m1"||k==="m10"||k==="m25"?R:k==="st30"||k==="st90"?ST:k==="k100"||k==="k500"?s.kills||0:k==="ld1"||k==="ld5"?s.landed||0:k==="w1"?(s.stats?.w||0):k==="o3"?s.owned.length:s.credits}function PK(id){''',"achConsts")

# 5) renderer: setCamo + camo-duyarli setAircraft
rep('setAircraft(e){this.player.name!==e&&(this.scene.remove(this.player),this.player=this.makePlayer(e),this.scene.add(this.player))}',
    'setCamo(e){this.camoHex=(CAMO[e||0]||CAMO[0]).c;this.player&&this.aircraftCache.delete(this.player.name)}setAircraft(e){const A=no.find(o=>o.id===e),oc=A&&A.color;A&&this.camoHex&&(A.color=this.camoHex);(this.player.name!==e||this._cm!==this.camoHex)&&(this._cm=this.camoHex,this.aircraftCache.delete(e),this.scene.remove(this.player),this.player=this.makePlayer(e),this.scene.add(this.player));A&&(A.color=oc)}',"setCamo")

# 6) SFX: chime + buy
rep('const n=this.context;this._attn=1,this._pan0=0;',
    'const n=this.context;this._attn=1,this._pan0=0;if(e==="chime"){this._shot((g,a)=>{this._env(g,0,.12,.5);const o=n.createOscillator();o.type="sine";o.frequency.setValueAtTime(660,a);o.frequency.setValueAtTime(880,a+.12);o.frequency.setValueAtTime(1320,a+.24);o.connect(g);o.start(a);o.stop(a+.5);o.onended=()=>o.disconnect()});return}if(e==="buy"){this._shot((g,a)=>{this._env(g,0,.15,.2);const o=n.createOscillator();o.type="triangle";o.frequency.setValueAtTime(420,a);o.frequency.exponentialRampToValueAtTime(840,a+.15);o.connect(g);o.start(a);o.stop(a+.22);o.onended=()=>o.disconnect()});return}',"sfxNew")

# 7) baslıkta basarim butonu (gear'dan once)
rep('S.jsx("button",{className:"icon-button",onClick:()=>a("settings"),"aria-label":u("settings")',
    'S.jsx("button",{className:"icon-button",onClick:()=>a("ach"),"aria-label":u("achTitle"),children:S.jsx("span",{style:{fontSize:14,lineHeight:1},children:"★"})}),S.jsx("button",{className:"icon-button",onClick:()=>a("settings"),"aria-label":u("settings")',"achBtn")

# 8) AchD bileseni + dialog (settings dialog'undan once)
rep('o==="settings"&&S.jsx(ml,{title:Te("settingsTitle")',
    'o==="ach"&&S.jsx(AchD,{save:s,onClose:()=>c(null),onClaim:(k,rw)=>{e(Be=>({...Be,credits:Be.credits+rw,ach:{...Be.ach,[k]:1}}));K.current.play("chime")}}),o==="settings"&&S.jsx(ml,{title:Te("settingsTitle")',"achDialog")
rep('function PK(id){let s=(id*2654435761)',
    'function AchD({save:s,onClose:n,onClaim:a}){const L=s.preferences.language;return S.jsx(ml,{title:__L(L,Fw.achTitle),onClose:n,children:S.jsx("div",{className:"ach-list",children:ACH.map(([k,need,rw])=>{const v=ACHVAL(k,s),done=!!(s.ach||{})[k],ok=v>=need;return S.jsxs("div",{className:"ach-row"+(done?" done":""),children:[S.jsx("strong",{children:__L(L,Fw["ach_"+k])}),S.jsx("span",{children:Math.min(v,need)+" / "+need}),done?S.jsx("em",{children:__L(L,Fw.achClaimed)}):ok?S.jsx("button",{className:"ach-claim",onClick:()=>a(k,rw),children:"+"+rw}):null]},k)})})})}function PK(id){let s=(id*2654435761)',"achComp")

# 9) hangar: onCamo prop + qc + detay karti
rep('function Xw({save:s,preview:e,onPreview:n,onSelect:a,onUpgrade:o,onStart:c,onShop:qt}){const[adT,setAdT]=pt.useState(0);',
    'function Xw({save:s,preview:e,onPreview:n,onSelect:a,onUpgrade:o,onStart:c,onShop:qt,onCamo:qc0}){const[adT,setAdT]=pt.useState(0);const qc=i=>{qc0&&qc0(i)};',"xwProp")
rep('className:"hangar-content",children:[',
    'className:"hangar-content",children:[S.jsxs("div",{className:"hangar-detail-card",children:[S.jsxs("div",{className:"hd-top",children:[S.jsx("strong",{children:(v=>v.code+" · "+v.name)(no.find(v=>v.id===e))}),S.jsx("span",{className:"aircraft-role",children:__L(u,(no.find(v=>v.id===e)).role)})]}),S.jsx("p",{className:"hd-desc",children:__L(u,(no.find(v=>v.id===e)).description)}),S.jsx("div",{className:"camo-row",children:CAMO.map((cm,ci)=>S.jsx("button",{className:"camo-chip"+((s.camo||0)===ci?" active":""),style:{background:cm.c},onClick:()=>qc(ci),"aria-label":"camo"},ci))})]},"hd"),',"hdCard")

# 10) Xw cagrisina onCamo
rep('S.jsx(Xw,{save:s,preview:u,onPreview:f,onSelect:Pt,onUpgrade:Se,onStart:()=>ve(),',
    'S.jsx(Xw,{save:s,preview:u,onPreview:f,onSelect:Pt,onUpgrade:Se,onCamo:k=>{e(z=>({...z,camo:k}));$.current&&$.current.setCamo(k);K.current.play("click")},onStart:()=>ve(),',"xwCall")

# 11) i18n: basarim + camo anahtarları
rep('const Fw={biome0:',
'''const Fw={achTitle:["ACHIEVEMENTS","BAŞARIMLAR","ERFOLGE","LOGROS","SUCCÈS","TRAGUARDI","CONQUISTAS","ДОСТИЖЕНИЯ","PRESTASI","الإنجازات"],achClaimed:["CLAIMED","ALINDI","ERHALTEN","RECLAMADO","RÉCLAMÉ","RISCOSSO","RESGATADO","ПОЛУЧЕНО","DIKLAIM","تم الاستلام"],camo:["CAMO","BOYA","TARNANSTRICH","CAMUFLAJE","CAMOUFLAGE","MIMETICA","CAMUFLAGEM","КАМУФЛЯЖ","KAMUFLASE","تمويه"],ach_m1:["First Sortie","İlk Görev","Erster Einsatz","Primera misión","Première mission","Prima missione","Primeira missão","Первый вылет","Sorti pertama","الطلعة الأولى"],ach_m10:["10 Sorties","10 Görev","10 Einsätze","10 misiones","10 missions","10 missioni","10 missões","10 вылетов","10 sorti","10 طلعات"],ach_m25:["25 Sorties","25 Görev","25 Einsätze","25 misiones","25 missions","25 missioni","25 missões","25 вылетов","25 sorti","25 طلعة"],ach_st30:["30 Stars","30 Yıldız","30 Sterne","30 estrellas","30 étoiles","30 stelle","30 estrelas","30 звёзд","30 bintang","30 نجمة"],ach_st90:["90 Stars","90 Yıldız","90 Sterne","90 estrellas","90 étoiles","90 stelle","90 estrelas","90 звёзд","90 bintang","90 نجمة"],ach_k100:["100 Neutralized","100 Hedef","100 erledigt","100 neutralizados","100 neutralisés","100 neutralizzati","100 neutralizados","100 целей","100 dilumpuhkan","تحييد 100"],ach_k500:["500 Neutralized","500 Hedef","500 erledigt","500 neutralizados","500 neutralisés","500 neutralizzati","500 neutralizados","500 целей","500 dilumpuhkan","تحييد 500"],ach_ld1:["First Landing","İlk İniş","Erste Landung","Primer aterrizaje","Premier appontage","Primo atterraggio","Primeiro pouso","Первая посадка","Pendaratan pertama","الهبوط الأول"],ach_ld5:["5 Landings","5 İniş","5 Landungen","5 aterrizajes","5 appontages","5 atterraggi","5 pousos","5 посадок","5 pendaratan","5 هبوطات"],ach_w1:["First Victory","İlk Zafer","Erster Sieg","Primera victoria","Première victoire","Prima vittoria","Primeira vitória","Первая победа","Kemenangan pertama","النصر الأول"],ach_o3:["3 Aircraft","3 Uçak","3 Flugzeuge","3 aeronaves","3 appareils","3 velivoli","3 aeronaves","3 самолёта","3 pesawat","3 طائرات"],ach_c5:["5000 Credits","5000 Kredi","5000 Credits","5000 créditos","5000 crédits","5000 crediti","5000 créditos","5000 кредитов","5000 kredit","5000 رصيد"],biome0:''',"i18nAch")

# 12) CSS
css='''.ach-list{display:grid;gap:8px;max-height:60vh;overflow-y:auto}
.ach-row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 12px;border:1px solid #35525e;border-radius:10px;background:rgba(17,38,49,.55);font-size:13px}
.ach-row.done{opacity:.5}
.ach-row span{font-family:var(--mono);font-size:11px;opacity:.75}
.ach-claim{border:1px solid #e8a33d;background:linear-gradient(180deg,#e8a33d,#c7822a);color:#17130b;font-weight:700;border-radius:8px;padding:6px 12px;cursor:pointer}
.hangar-detail-card{pointer-events:auto;max-width:560px;margin:0 auto;padding:14px 16px;border:1px solid #35525e;border-radius:12px;background:rgba(13,29,38,.72);backdrop-filter:blur(6px)}
.hangar-detail-card .hd-top{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
.hangar-detail-card .hd-top strong{font-family:var(--display);letter-spacing:.08em;font-size:16px;color:#d6e0e4}
.hd-desc{font-size:12px;opacity:.8;margin:6px 0 2px}
.camo-row{display:flex;gap:8px;margin-top:10px}
.camo-chip{width:26px;height:26px;border-radius:50%;border:2px solid rgba(255,255,255,.25);cursor:pointer}
.camo-chip.active{border-color:#e8a33d;box-shadow:0 0 0 2px rgba(232,163,61,.35)}
'''
i=s.rfind('</style>')
s=s[:i]+css+s[i:]
print("ok css42")

# 13) rozet
c17=s.count("3.16 DEV")
if c17<2:
    print("FAIL badge",c17); sys.exit(1)
s=s.replace("3.16 DEV","3.17 DEV")
print("ok badge x",c17)

io.open(P,"w",encoding="utf-8").write(s)
print("v42 size",len(s))
