p='/home/user/striker-dev/index.html'
s=open(p,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old); assert n==1,(n,old[:70]); s=s.replace(old,new)
rep('ne.rec.length<4200&&ne.rec.push([Math.round(ne.time*20),Math.round(ne.player.x),Math.round(ne.player.y),Math.round(ne.player.z),Math.round(ne.heading*1e3),Math.round(ne.pitch*1e3),Math.round(ne.speed)])',
    'ne.rec.length<4200&&ne.rec.push([Math.round(ne.time*20),Math.round(ne.player.x),Math.round(ne.player.y),Math.round(ne.player.z),Math.round(ne.heading*1e3),Math.round(ne.pitch*1e3),Math.round(ne.speed),ne.rec.length%5===0?ne.entities.filter(n=>n.hp>0&&!n.friendly).map(n=>[n.id,Math.round(n.position.x),Math.round(n.position.y),Math.round(n.position.z),Math.round((n.heading||0)*1e3)]):undefined])')
rep('}else{const r0=q.rec[k];ne.player.set(',
    '}else{const r0=q.rec[k];if(!q.em)q.em=new Map(ne.entities.map(n=>[n.id,n]));{const si=Math.floor(k/5)*5,A=q.rec[si],B=q.rec[Math.min(q.rec.length-1,si+5)],f=Math.min(1,(k-si)/5),sa=(A&&A[7])||[],sb=(B&&B[7])||[],mb=new Map(sb.map(a=>[a[0],a])),ids=new Set();for(const a of sa){const n=q.em.get(a[0]);if(!n)continue;ids.add(a[0]);const b=mb.get(a[0])||a;n.position.set(a[1]+(b[1]-a[1])*f,a[2]+(b[2]-a[2])*f,a[3]+(b[3]-a[3])*f);n.heading=a[4]/1e3+((b[4]-a[4])/1e3)*f}for(const n of ne.entities){if(!n.friendly&&!ids.has(n.id))n.position.y=-400}}ne.player.set(')
s=s.replace('3.66 DEV','3.67 DEV')
open(p,'w',encoding='utf-8').write(s)
print('v93 ok')
