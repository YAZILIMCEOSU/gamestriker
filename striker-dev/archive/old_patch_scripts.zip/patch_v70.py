P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
old='constructor(e,n,a){this.options=n,this.renderer=new Mw('
assert s.count(old)==1, s.count(old)
s=s.replace(old,'constructor(e,n,a){window.__gfx=this,this.options=n,this.renderer=new Mw(')
open(P,'w',encoding='utf-8').write(s); print('v70 hook ok')
