#!/usr/bin/env python3
# v3.21 — yapi kaplamalari + cevre ayrintilari + ayri vurulabilir AA/radar/hangar/tank parcalari
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v45.py"], cwd="/home/user", capture_output=True, text=True)
print("v45:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

# 1) orman yogunlugu
rep('TN=c>=90?900:120;','TN=c>=90?2600:160;',"trees")

# 2) motor: parca sistemi (mkParts/partW/hitParts)
rep('terr(e,n){let t=0',
    'mkParts(c){return c==="refinery"?[{k:"tank",o:[-18,8,-8],r:9,h:60},{k:"tank",o:[0,8,10],r:9,h:60},{k:"tank",o:[18,8,-6],r:9,h:60},{k:"stack",o:[26,17,6],r:7,h:50},{k:"aa",o:[46,4,44],r:8,h:80}]:c==="airfield"?[{k:"hangar",o:[-46,8,30],r:16,h:120},{k:"hangar",o:[-10,8,30],r:16,h:120},{k:"tower",o:[46,13,28],r:8,h:80},{k:"tank",o:[64,4,8],r:6,h:50},{k:"tank",o:[64,4,0],r:6,h:50},{k:"tank",o:[64,4,-8],r:6,h:50},{k:"aa",o:[-90,4,-40],r:8,h:80}]:c==="radar"?[{k:"dish",o:[0,23,0],r:10,h:90},{k:"aa",o:[30,4,26],r:8,h:80}]:c==="bridge"?[{k:"aa",o:[-160,10,0],r:8,h:80},{k:"aa",o:[160,10,0],r:8,h:80}]:null}partW(e,t,out){const h=e.heading||0,ch=Math.cos(h),sh=Math.sin(h),x=t.o[0],z=t.o[2];return out.set(e.position.x+x*ch-z*sh,e.position.y+t.o[1],e.position.z+x*sh+z*ch)}hitParts(a,n){if(!a.parts)return!1;for(const t of a.parts){if(t.h<=0)continue;const wp=this.partW(a,t,this.temp);const hit=n.kind==="bomb"?wp.distanceTo(n.position)<100:kp(wp,n.previous,n.position)<t.r+3;if(hit){t.h-=n.damage;this.event("hit",wp,5);if(t.h<=0){this.event("explosion",wp,t.r*1.6);this.score+=150;this.damageEnemy(a,a.maxHp*.22)}return!0}}return!1}terr(e,n){let t=0',"partsSys")

# 3) spawn: parts alani
rep('grounded:lk||lb2,','grounded:lk||lb2,parts:this.mkParts(c),',"partsField")

# 4) mermi/bomba hasari parcalara yonlenir
rep('a.radius+(n.kind==="bomb"?20:3)){this.damageEnemy(a,n.damage)',
    'a.radius+(n.kind==="bomb"?20:3)){this.hitParts(a,n)||this.damageEnemy(a,n.damage)',"routeBullet")
rep('a.position.distanceTo(n.position)<115&&this.damageEnemy(a,n.damage)',
    'a.position.distanceTo(n.position)<115&&!this.hitParts(a,n)&&this.damageEnemy(a,n.damage)',"routeBomb")

# 5) AA parcalari ates eder
rep('n.phase+=e*(n.airborne?(n.kind==="heli"?.1:n.kind==="uav"?.5:.24):.022);',
    'n.phase+=e*(n.airborne?(n.kind==="heli"?.1:n.kind==="uav"?.5:.24):.022);if(n.parts)for(const t of n.parts)if(t.k==="aa"&&t.h>0){t.cd=(t.cd||0)-e;if(t.cd<=0&&n.position.distanceTo(this.player)<1600){t.cd=1.5+Math.random()*.9;const wp=this.partW(n,t,this.temp);this.desired.copy(this.player).sub(wp);this.desired.y+=50;this.desired.normalize().multiplyScalar(260);this.desired.x+=(Math.random()-.5)*36;this.desired.z+=(Math.random()-.5)*36;this.spawn("hostile",wp,this.desired,11,[9,11,14,17,20][this.di]);this.event("gun",wp,1)}}',"aaFire")

# 6) rafineri: kaplama + detay + AA modeli
rep('for(const q of[[-70,10.4,-50],[-52,10.4,-52],[70,11.4,-46]])a.add(this.box([17,1.4,13],this.pale,q));return a}',
    'for(const q of[[-70,10.4,-50],[-52,10.4,-52],[70,11.4,-46]])a.add(this.box([17,1.4,13],this.pale,q));for(const q of[[-70,6,-43.6],[-52,6,-45.6],[70,7,-39.6]])a.add(this.box([10,1.4,.4],this.pale,q,.06));a.add(this.box([40,2,2],this.steel,[0,6,24]));a.add(this.box([2,2,24],this.steel,[18,6,12]));for(const q of[[36,1.5,40],[40,1.5,44],[38,4,42]])a.add(this.box([4,3,4],this.steel,q));a.add(this.box([7,3,3.4],this.steel,[20,1.6,-30]));a.add(this.box([2.6,2.4,3.2],this.dark,[24.6,1.4,-30]));a.add(this.box([7,5,7],this.steel,[46,2.5,44]));a.add(this.box([1.4,9,1.4],this.steel,[46,9,44]));return a}',"refineryClad")

# 7) meydan: hangar kapi/mahya + AA + arac
rep('for(const q of[-1,0,1]){const t=this.mesh(new oi(3,3,10,10),this.steel,[64,4,q*8]);t.rotation.x=Math.PI/2,a.add(t)}return a}',
    'for(const q of[-1,0,1]){const t=this.mesh(new oi(3,3,10,10),this.steel,[64,4,q*8]);t.rotation.x=Math.PI/2,a.add(t)}a.add(this.box([22,8,.5],this.pale,[-46,5,19.2],.05));a.add(this.box([22,8,.5],this.pale,[-10,5,19.2],.05));a.add(this.box([30,1.6,1.6],this.pale,[-46,15.4,30],.05));a.add(this.box([30,1.6,1.6],this.pale,[-10,15.4,30],.05));a.add(this.box([7,5,7],this.steel,[-90,2.5,-40]));a.add(this.box([1.4,9,1.4],this.steel,[-90,9,-40]));a.add(this.box([7,3,3.4],this.steel,[-20,1.6,-40]));a.add(this.box([2.6,2.4,3.2],this.dark,[-15.4,1.4,-40]));return a}',"airfieldClad")

# 8) radar: AA modeli
rep('a.add(this.mesh(new oi(1.1,2.2,17,12),this.steel,[0,23,0]));',
    'a.add(this.mesh(new oi(1.1,2.2,17,12),this.steel,[0,23,0]));a.add(this.box([7,5,7],this.steel,[30,2.5,26]));a.add(this.box([1.4,9,1.4],this.steel,[30,9,26]));',"radarClad")

# 9) kopru: AA kuleleri
rep('a.add(this.box([90,10,20],this.dark,[160,4,0]));return a}',
    'a.add(this.box([90,10,20],this.dark,[160,4,0]));a.add(this.box([7,5,7],this.steel,[-160,11.5,0]));a.add(this.box([1.4,9,1.4],this.steel,[-160,18,0]));a.add(this.box([7,5,7],this.steel,[160,11.5,0]));a.add(this.box([1.4,9,1.4],this.steel,[160,18,0]));return a}',"bridgeClad")

# 10) rozet
c21=s.count("3.20 DEV")
if c21<2:
    print("FAIL badge",c21); sys.exit(1)
s=s.replace("3.20 DEV","3.21 DEV")
print("ok badge x",c21)

io.open(P,"w",encoding="utf-8").write(s)
print("v46 size",len(s))
