#!/usr/bin/env python3
# v3.16 DEV — P6 meta: mac/galibiyet/SP istatistikleri + SIRALAMA seridi + rozet 3.13
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v35.py"], cwd="/home/user", capture_output=True, text=True)
print("v35:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag, count=1):
    global s
    c = s.count(old)
    if c != count:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

# 1) sonuc handler'i her sonucta calissin (mac sayisi), kredi/record sadece basarida
rep('ae.success&&e(Be=>{const ke=Be.records[Ee],De=',
    'e(Be=>{const ke=Be.records[Ee],De=', "alwaysStats")
rep('return{...Be,credits:Be.credits+ae.reward,records:{...Be.records,[Ee]:De},daily:',
    'return{...Be,credits:Be.credits+(ae.success?ae.reward:0),records:ae.success?{...Be.records,[Ee]:De}:Be.records,stats:{m:(Be.stats?.m||0)+1,w:(Be.stats?.w||0)+(ae.success?1:0),sp:Math.max(Be.stats?.sp||0,ae.score)},daily:',
    "statsAcc")
# 2) normalizer stats
rep('upgV:u.upgV&&typeof u.upgV==="object"?u.upgV:{},',
    'upgV:u.upgV&&typeof u.upgV==="object"?u.upgV:{},stats:u.stats&&typeof u.stats==="object"?u.stats:{m:0,w:0,sp:0},',
    "normStats")
# 3) SIRALAMA seridi
rep('Math.floor(Object.values(s.records).reduce((z,k)=>z+(k.stars||0),0)/12)})]})]}),',
    'Math.floor(Object.values(s.records).reduce((z,k)=>z+(k.stars||0),0)/12)}),S.jsx("span",{style:{marginLeft:10,opacity:.85},children:c("rank")+" · "+c("sp")+" "+(s.stats?.sp||0)+" · "+c("matches")+" "+(s.stats?.m||0)+" · "+c("wins")+" "+(s.stats?.w||0)})]})]}),',
    "rankStrip")
# 4) i18n
rep('upgArmor:["ARMOR PLATES +18 HULL",',
    'rank:["RANKING","SIRALAMA","RANGLISTE","CLASIFICACIÓN","CLASSEMENT","CLASSIFICA","CLASSIFICAÇÃO","РЕЙТИНГ","PERINGKAT","التصنيف"],'
    'matches:["MATCHES","MAÇ","PARTIEN","PARTIDAS","MATCHS","PARTITE","PARTIDAS","БОИ","LAGA","مباريات"],'
    'wins:["WINS","GALİBİYET","SIEGE","VICTORIAS","VICTOIRES","VITTORIE","VITÓRIAS","ПОБЕДЫ","MENANG","انتصارات"],'
    'sp:["SP","SP","SP","SP","SP","SP","SP","ОЧКИ","SP","نقاط"],'
    'upgArmor:["ARMOR PLATES +18 HULL",', "i18nP6")
# 5) rozet
c = s.count("3.12 DEV")
if c < 2:
    print("FAIL badge", c); sys.exit(1)
s = s.replace("3.12 DEV", "3.13 DEV")
print("ok badge x", c)

io.open(P, "w", encoding="utf-8").write(s)
print("v36 size", len(s))
