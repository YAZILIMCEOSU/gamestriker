#!/usr/bin/env python3
# v3.34 — FAZ K: HUD LEVEL-UP (referans seviye 1): radar pusula harfleri + kenar ibreleri/mesafe,
# hedef bandi (objectives banner), hareketli ALT/SPD bantlari. Tamamen eklemeli.
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v58.py"], cwd="/home/user", capture_output=True, text=True)
print("v58:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag):
    global s
    c = s.count(old)
    if c != 1:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

# 1) radar verisine mesafe ekle
rep('selected:s.targetId===n.id}})',
    'selected:s.targetId===n.id,d:Math.round(Math.hypot(a,o))}})', "radarDist")

# 2) radar diskine doner pusula harfleri
rep('S.jsx("circle",{cx:"60",cy:"60",r:"56",fill:"url(#radar-background)",stroke:"currentColor",opacity:".6"}),',
    'S.jsx("circle",{cx:"60",cy:"60",r:"56",fill:"url(#radar-background)",stroke:"currentColor",opacity:".6"}),S.jsx("g",{className:"radar-card",style:{transform:`rotate(${-e.heading}deg)`,transformOrigin:"60px 60px"},children:[["N",60,13],["E",107,60],["S",60,111],["W",13,60]].map(q=>S.jsx("text",{x:q[1],y:q[2],className:"radar-let",children:q[0]}))}),',
    "radarCard")

# 3) kenar ibreleri + en yakin 3 mesafe
rep('S.jsx("path",{d:"M60 53l4 10-4-3-4 3Z",fill:"#fff"})',
    '[...e.radar].sort((p,q)=>(p.d||0)-(q.d||0)).map((b,w)=>{const dx=b.x-60,dy=b.y-60,L=Math.hypot(dx,dy)||1,ex=60+dx/L*50,ey=60+dy/L*50,an=Math.atan2(dx,-dy)*180/Math.PI;return S.jsxs("g",{transform:`translate(${ex},${ey}) rotate(${an})`,children:[S.jsx("path",{d:"M0-2.6l2.6 5.2h-5.2Z",className:"radar-needle"}),w<3?S.jsx("text",{className:"radar-dist",transform:`rotate(${-an})`,y:"11",children:((b.d||0)/1e3).toFixed(1)}):null]},w)}),S.jsx("path",{d:"M60 53l4 10-4-3-4 3Z",fill:"#fff"})',
    "radarNeedles")

# 4) hedef/ilerleme bandi
rep('S.jsxs("div",{className:"hull-display",',
    'S.jsxs("div",{className:"obj-banner",children:[S.jsx("b",{children:o("objectives")}),S.jsx("span",{children:e.mkind==="recon"?"RECON "+e.recon+"/"+e.reconN:e.boss?"BOSS PH0"+e.boss.ph+" · %"+Math.round(e.boss.h*100):e.mkind==="timer"?Math.max(0,Math.ceil(e.seconds))+"s":(e.carrierHealth<100?"AURORA %"+Math.round(e.carrierHealth)+" · ":"")+e.kills+"/"+e.targets})]}),S.jsxs("div",{className:"hull-display",',
    "objBanner")

# 5) hareketli ALT/SPD bantlari
rep('S.jsxs("div",{className:"telemetry telemetry-speed",children:[S.jsx("span",{children:o("speed")}),S.jsxs("strong",{children:[e.speed,S.jsx("small",{children:"KTS"})]}),S.jsx("div",{className:"tape-marks"})]}),S.jsxs("div",{className:"telemetry telemetry-altitude",children:[S.jsx("span",{children:o("altitude")}),S.jsxs("strong",{children:[e.altitude,S.jsx("small",{children:"FT"})]}),S.jsx("div",{className:"tape-marks"})]})',
    'S.jsxs("div",{className:"telemetry telemetry-speed",children:[S.jsx("span",{children:o("speed")}),S.jsxs("strong",{children:[e.speed,S.jsx("small",{children:"KTS"})]}),S.jsx("div",{className:"tape-marks",style:{backgroundPositionY:-(e.speed*.6)+"px"}})]}),S.jsxs("div",{className:"telemetry telemetry-altitude",children:[S.jsx("span",{children:o("altitude")}),S.jsxs("strong",{children:[e.altitude,S.jsx("small",{children:"FT"})]}),S.jsx("div",{className:"tape-marks",style:{backgroundPositionY:-(e.altitude*.35)+"px"}})]})',
    "tapeMotion")

# 6) CSS
rep('.hg2-card:disabled{opacity:.45;cursor:default}\n</style>',
    '.hg2-card:disabled{opacity:.45;cursor:default}\n.radar-let{font-family:var(--mono);font-size:8px;fill:var(--hud);opacity:.8;text-anchor:middle;dominant-baseline:middle}\n.radar-needle{fill:#ff6b57;opacity:.95}\n.radar-dist{font-family:var(--mono);font-size:6.5px;fill:#ffb3a6;text-anchor:middle}\n.obj-banner{position:absolute;top:12px;left:30px;z-index:5;display:flex;gap:9px;align-items:center;padding:7px 12px;border:1px solid rgba(120,170,190,.28);border-radius:9px;background:rgba(10,24,31,.74);font-family:var(--mono);letter-spacing:.12em;font-size:9px;color:#cfe3ee;backdrop-filter:blur(4px)}\n.obj-banner b{color:#e8a33d;font-size:8px;font-weight:700}\n@media (max-width:820px){.obj-banner{left:12px;top:8px;font-size:7px;padding:5px 9px}}\n</style>',
    "hudCss")

# 7) badge
c = s.count("3.33 DEV")
if c < 2:
    print("FAIL badge", c); sys.exit(1)
s = s.replace("3.33 DEV", "3.34 DEV")
print("ok badge x", c)

io.open(P, "w", encoding="utf-8").write(s)
print("v59 size", len(s))
