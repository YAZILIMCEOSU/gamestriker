P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old); assert n==1, f"count {n}: {old[:80]}"
    s=s.replace(old,new)

# 1) helper: create a mesh for an entity that was spawned after mission start
rep('begin(e){this.setMode(\"game\"),',
    'spawnMesh(n){this.targetCache.has(n.kind)||this.targetCache.set(n.kind,n.airborne?this.assets.enemyAircraft(n.kind):this.assets.ship(n.kind));const a=this.targetCache.get(n.kind).clone(!0);this.enemies.set(n.id,a);this.scene.add(a);return a}begin(e){this.setMode(\"game\"),')

# 2) render loop: create missing meshes for live entities (mid-mission spawns were never drawn)
rep('for(const o of n.entities){const c=this.enemies.get(o.id);if(!c)continue;c.position.copy(o.position)',
    'for(const o of n.entities){let c=this.enemies.get(o.id);if(!c&&o.hp>0)c=this.spawnMesh(o);if(!c)continue;c.position.copy(o.position)')

assert s.count('3.56 DEV')==2
s=s.replace('3.56 DEV','3.57 DEV')
open(P,'w',encoding='utf-8').write(s); print('v83 ok', len(s))
