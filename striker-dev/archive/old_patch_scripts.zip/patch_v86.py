import re
p='/home/user/striker-dev/index.html'
s=open(p,encoding='utf-8').read()
def rep(old,new,cnt=1):
    global s
    n=s.count(old); assert n==cnt,(n,old[:70]); s=s.replace(old,new)

# A) balance: >=10 aircraft (interceptor/attacker/bomber/heavy), >=10 SIHA (uav), sea>=3, land 2-4
st=s.index('targets:((t,id)=>{'); en_marker='(sn>1&&c.length<9?c.concat("drone"):c,e),'
en=s.index(en_marker,st)+len(en_marker)
assert s.count('targets:((t,id)=>{')==1
bal=('targets:((t,id)=>{const L=["refinery","sam","radar","airfield","bridge"],AC=["interceptor","attacker","bomber","heavy"],U=["uav"],S=["corvette","destroyer","sub"],k=p=>t.filter(x=>p.includes(x)).length;'
     'while(k(L)>4){const i=t.indexOf("airfield");t.splice(i>=0?i:t.findIndex(x=>L.includes(x)),1)}'
     'for(let i=k(AC);i<10;i++)t.push(["interceptor","attacker","interceptor","bomber"][(id+i)%4]);'
     'for(let i=k(U);i<10;i++)t.push("uav");'
     'for(let i=k(S);i<3;i++)t.push(["destroyer","corvette","destroyer"][(id+i)%3]);'
     'for(let i=k(L);i<2;i++)t.push(["refinery","sam","radar"][(id+i)%3]);return t})(sn>1&&c.length<9?c.concat("drone"):c,e),')
s=s[:st]+bal+s[en:]

# B) flyers placed in groups near the approach lane instead of 15 km out
rep('(e.kind==="boss"?-2600:-1100)-u*520-e.chapter*140,d=LP?',
    '(f?-1500-(u%6)*420-e.chapter*60:(e.kind==="boss"?-2600:-1100)-u*520-e.chapter*140),d=LP?')
rep('u===0?0:(u%2?-1:1)*(360+u*210);',
    'u===0?0:f?(u%2?-1:1)*(300+Math.floor(u/6)*420):(u%2?-1:1)*(360+u*210);')

# C) pursuit / evasion AI for interceptors and attackers
rep('const a=n.airborne?310:n.grounded?0:80;n.position.x=n.origin.x+Math.sin(n.phase)*a,n.position.z=n.origin.z+(Math.cos(n.phase)-1)*a,n.heading=Math.PI/2-n.phase,n.airborne&&(',
    'const ai=n.airborne&&(n.kind===\"interceptor\"||n.kind===\"attacker\");const a=n.airborne?310:n.grounded?0:80;ai?this.chaseAI(n,e):(n.position.x=n.origin.x+Math.sin(n.phase)*a,n.position.z=n.origin.z+(Math.cos(n.phase)-1)*a,n.heading=Math.PI/2-n.phase),n.airborne&&!ai&&(')
rep('surpriseTick(dt){',
'''chaseAI(n,e){n.evT=(n.evT||0)-e;n.jinkCd=(n.jinkCd||0)-e;const pl=this.player,dx=pl.x-n.position.x,dy=pl.y-n.position.y,dz=pl.z-n.position.z,dist=Math.hypot(dx,dy,dz)||1;
if(n.evT<=0&&n.jinkCd<=0){const locked=this.target===n&&this.lock>.25;if(locked||(dist<1000&&Math.random()<e*.8)){n.evT=2.4;n.jinkCd=5+Math.random()*4;n.evDir=Math.random()<.5?-1:1}}
let ux=dx/dist,uy=dy/dist,uz=dz/dist;const ang=n.evT>0?n.evDir*1.25:Math.sin(this.time*1.3+n.id)*.22;const c=Math.cos(ang),sn=Math.sin(ang);const rx=ux*c-uz*sn,rz=ux*sn+uz*c;ux=rx;uz=rz;if(n.evT>0)uy=uy*.5+n.evDir*.2;
const spd=(n.evT>0?290:215)*[.9,1,1.08,1.16,1.25][this.di||0];const L=Math.hypot(ux,uy,uz)||1;
n.position.x+=ux/L*spd*e;n.position.y=Math.max(120,Math.min(900,n.position.y+uy/L*spd*e));n.position.z+=uz/L*spd*e;n.heading=Math.atan2(ux,-uz)}
surpriseTick(dt){''')

# D) mission time limit scales with target count
assert s.count('3.59 DEV')==2; s=s.replace('3.59 DEV','3.60 DEV')
open(p,'w',encoding='utf-8').write(s)
print('v86 ok',len(s))
