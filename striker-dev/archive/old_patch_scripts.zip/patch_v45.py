#!/usr/bin/env python3
# v3.20 — kademe 2: zengin arazi paleti + egim, orman, koy/teras, kiyi hizali kopru, net gorush
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v44.py"], cwd="/home/user", capture_output=True, text=True)
print("v44:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

# 1) acik havada net gorush (sis az)
rep('this.sceneE.fog.density=e===2?4.5e-4:e===1?2.4e-4:1.6e-4',
    'this.sceneE.fog.density=e===2?3.6e-4:e===1?2.2e-4:9.5e-5',"fogClear")

# 2) arazi paleti: kum/cayir/orman/kaya/kar + egim gölgesi (iki gecis)
rep('const f=u.attributes.position,d=[],L0=this.islePal||["#a4a294","#44594c","#7f8a83"],p=new ht(L0[0]),g=new ht(L0[1]),_=new ht(L0[2]);for(let b=0;b<f.count;b++){const w=f.getX(b),E=f.getZ(b),x=Math.sqrt((w/a)**2+(E/(a*.75))**2),L=Math.sin(w*.007+c)*.19+Math.sin(E*.012+w*.004)*.13+Math.sin(w*.025-E*.019)*.035,F=Math.max(-12,(1-x+L)*o);f.setY(b,F);const R=F<10?p.clone():F>o*.59?_.clone():g.clone();R.multiplyScalar(.83+Math.sin(w*.13+E*.16)*.06+F/o*.17),d.push(R.r,R.g,R.b)}u.setAttribute("color",new It(d,3)),u.computeVertexNormals();',
    'const f=u.attributes.position,d=[];for(let b=0;b<f.count;b++){const w=f.getX(b),E=f.getZ(b),x=Math.sqrt((w/a)**2+(E/(a*.75))**2),L=Math.sin(w*.007+c)*.19+Math.sin(E*.012+w*.004)*.13+Math.sin(w*.025-E*.019)*.035;f.setY(b,Math.max(-12,(1-x+L)*o))}u.computeVertexNormals();const nr=u.attributes.normal,cS=new ht("#c9b78e"),cG=new ht("#5f7d46"),cF=new ht("#3f5a33"),cR=new ht("#6e675c"),cW=new ht("#e8ecec");for(let b=0;b<f.count;b++){const w=f.getX(b),E=f.getZ(b),F=f.getY(b),sl=nr.getY(b);let C=F<1.6?cS:F<14?cG:F<o*.55?cF:cR;if(sl<.7&&F>5)C=cR;else if(F>o*.7&&sl>.6)C=cW;const k=.8+Math.sin(w*.13+E*.16)*.07+Math.sin(w*.05-E*.07)*.05+F/o*.16;d.push(C.r*k,C.g*k,C.b*k)}u.setAttribute("color",new It(d,3));',"palette")

# 3) orman: buyuk kara parcalarina agaclanmis tek-mesh
rep('if(y.castShadow=!1,this.islands.add(y),c===0||c===3)',
    'if(y.castShadow=!1,this.islands.add(y),a>=1500){const tp=[],tc=[],TN=c>=90?900:120;for(let t=0;t<TN;t++){const rr=a*.88*Math.sqrt(((t*618034)%1000)/1000),an=t*2.399963,wx=Math.cos(an)*rr,wz=Math.sin(an)*rr*.75,xx=Math.sqrt((wx/a)**2+(wz/(a*.75))**2),L2=Math.sin(wx*.007+c)*.19+Math.sin(wz*.012+wx*.004)*.13+Math.sin(wx*.025-wz*.019)*.035,Fh=Math.max(-12,(1-xx+L2)*o);if(Fh<3||Fh>o*.78)continue;const hg=16+(t*7919)%18,sc=.9+((t*104729)%10)/10;for(let q=0;q<6;q++){const a1=q/6*6.2832,a2=(q+1)/6*6.2832;tp.push(wx,Fh-.5,wz,wx+Math.cos(a1)*4.6*sc,Fh+hg*.55,wz+Math.sin(a1)*4.6*sc,wx+Math.cos(a2)*4.6*sc,Fh+hg*.55,wz+Math.sin(a2)*4.6*sc,wx,Fh+hg*.5,wz,wx+Math.cos(a2)*4.6*sc,Fh+hg,wz+Math.sin(a2)*4.6*sc,wx+Math.cos(a1)*4.6*sc,Fh+hg,wz+Math.sin(a1)*4.6*sc);const v=.22+((t*31+q)%7)*.025;for(let m=0;m<6;m++)tc.push(v,v+.17,v*.75)}}if(tp.length){const gT=new gn;gT.setAttribute("position",new It(tp,3)),gT.setAttribute("color",new It(tc,3)),gT.computeVertexNormals();const mT=this.assets.mesh(gT,this.assets.material(new aa({vertexColors:!0,roughness:.95,metalness:0})),[e,0,n]);mT.castShadow=!1,this.islands.add(mT)}}if(0,c===0||c===3)',"trees")

# 4) rafineri: teras + lojmanlar
rep('if(e==="refinery"){for(const q of[[-18,0,-8],[0,0,10],[18,0,-6]])a.add(this.mesh(new oi(7,7,16,10),this.steel,q));a.add(this.box([6,34,6],this.steel,[26,17,6]));a.add(this.box([40,4,4],this.steel,[0,26,0]));return a}',
    'if(e==="refinery"){a.add(this.box([210,5,150],this.dark,[0,-2,0]));a.add(this.box([200,.3,1.6],this.pale,[0,.8,52],.05));for(const q of[[-18,0,-8],[0,0,10],[18,0,-6]])a.add(this.mesh(new oi(7,7,16,10),this.steel,q));a.add(this.box([6,34,6],this.steel,[26,17,6]));a.add(this.box([40,4,4],this.steel,[0,26,0]));for(const q of[[-70,5,-50],[-52,5,-52],[70,6,-46]])a.add(this.box([16,10,12],this.steel,q));for(const q of[[-70,10.4,-50],[-52,10.4,-52],[70,11.4,-46]])a.add(this.box([17,1.4,13],this.pale,q));return a}',"refineryUp")

# 5) radar: teras
rep('if(e==="radar"){a.add(this.mesh(new oi(27,36,12,12),this.dark,[0,0,0]))',
    'if(e==="radar"){a.add(this.box([90,4,90],this.dark,[0,-2,0])),a.add(this.mesh(new oi(27,36,12,12),this.dark,[0,0,0]))',"radarUp")

# 6) meydan: genis teras + kulube
rep('if(e==="airfield"){a.add(this.box([170,2,40],this.dark,[0,1,0]));',
    'if(e==="airfield"){a.add(this.box([230,5,150],this.dark,[0,-2.5,6]));a.add(this.box([16,9,12],this.steel,[90,4,-40]));a.add(this.box([17,1.2,13],this.pale,[90,9,-40]));a.add(this.box([170,2,40],this.dark,[0,1,0]));',"airfieldUp")

# 7) kopru: yaklasma dolgulari
rep('a.add(this.box([6,14,22],this.steel,[60,44,0]));return a}',
    'a.add(this.box([6,14,22],this.steel,[60,44,0]));a.add(this.box([90,10,20],this.dark,[-160,4,0]));a.add(this.box([90,10,20],this.dark,[160,4,0]));return a}',"causeway")

# 8) kopru kiyiya dik konumlanir (egim gradyani)
rep('grounded:lk||lb2,heading:.2,',
    'grounded:lk||lb2,heading:lb2?Math.atan2(this.terr(d,p+150)-this.terr(d,p-150),this.terr(d+150,p)-this.terr(d-150,p)):.2,',"bridgeHead")

# 9) rozet
c20=s.count("3.19 DEV")
if c20<2:
    print("FAIL badge",c20); sys.exit(1)
s=s.replace("3.19 DEV","3.20 DEV")
print("ok badge x",c20)

io.open(P,"w",encoding="utf-8").write(s)
print("v45 size",len(s))
