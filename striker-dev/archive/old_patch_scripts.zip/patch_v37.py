#!/usr/bin/env python3
# v3.13b — P2 fix: yeni gorev tipleri icin ikon eslemesi + liste kilidi
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v36.py"], cwd="/home/user", capture_output=True, text=True)
print("v36:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag, count=1):
    global s
    c = s.count(old)
    if c != count:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

rep('Ww={strike:Yu,intercept:Wp,defense:qp,radar:Pu,carrier:vy,boss:ib}',
    'Ww={strike:Yu,intercept:Wp,defense:qp,radar:Pu,carrier:vy,boss:ib,escort:vy,raid:Yu,waves:Wp,race:Pu,chain:ib}',
    "kindIcons")
rep('const f=Rl(u.id,s.records)||u.id===192,d=s.records[u.id]',
    'const f=Rl(u.id,s.records)||u.id===192||u.id>=193,d=s.records[u.id]',
    "listUnlock")

io.open(P, "w", encoding="utf-8").write(s)
print("v37 size", len(s))
