P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old); assert n==1, f"count {n}: {old[:60]}"
    s=s.replace(old,new)
# 1) drone nose: mesh travels along local -z, so aim -z at the tangent
rep('this.droneG.rotation.y=Math.atan2(-Math.sin(t*.22),Math.cos(t*.22))',
    'this.droneG.lookAt(cx-Math.sin(t*.22)*100,pp.y+28,cz+Math.cos(t*.22)*100),this.droneG.rotateY(Math.PI)')
# 2) fog: clear-weather density lower; ambient start fog lower; fog weather untouched
rep('e===3?1.7e-4:9.5e-5)', 'e===3?1.7e-4:3e-5)')
rep('e.fog=new vm("#8fb0bf",16e-5)', 'e.fog=new vm("#8fb0bf",4e-5)')
assert s.count('3.50 DEV')==2
s=s.replace('3.50 DEV','3.51 DEV')
open(P,'w',encoding='utf-8').write(s); print('v77 ok', len(s))
