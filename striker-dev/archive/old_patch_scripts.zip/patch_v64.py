#!/usr/bin/env python3
# v3.39 — FAZ N: 5 HAVA DURUMU (kar/firtina/sis gorsel+ikon+turbulans) + SES DUZEYI kaydirici.
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v63.py"], cwd="/home/user", capture_output=True, text=True)
print("v63:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag):
    global s
    c = s.count(old)
    if c != 1:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

# 1) kural uretici: 5 hava durumu
rep('weather:(e+sn)%3}})', 'weather:(e+sn)%5}})', "w5")

# 2) sis yogunluk haritasi + kar/firtina
rep('this.sceneE.fog.density=e===2?3.6e-4:e===1?2.2e-4:9.5e-5',
    'this.sceneE.fog.density=e===2?3.6e-4:e===4?2.6e-4:e===1?2.2e-4:e===3?1.7e-4:9.5e-5', "fogMap")

# 3) firtina turbulansi
rep('this.bank=li.damp(this.bank,-c*.52,3.4,a);',
    'this.bank=li.damp(this.bank,-c*.52,3.4,a),this.mission.weather===4&&this.phase==="combat"&&(this.bank+=(Math.sin(this.time*2.3)+.6*Math.sin(this.time*.77))*a*.5,this.pitch+=Math.sin(this.time*1.9)*a*.02);',
    "gust")

# 4) HUD overlay'leri
rep('e.weather===1?S.jsx("div",{className:"rain-overlay"}):null,',
    'e.weather===1||e.weather===4?S.jsx("div",{className:"rain-overlay"}):null,e.weather===4?S.jsx("div",{className:"storm-flash"}):null,e.weather===3?S.jsx("div",{className:"snow-overlay"}):null,e.weather===2?S.jsx("div",{className:"fog-overlay"}):null,',
    "overlays")

# 5) gorev karti hava ikonlari
rep('["","🌧",""][u.weather||0]', '["","🌧","🌫","🌨","⛈"][u.weather||0]', "wIcons")

# 6) ses: volume destegi
rep('setEnabled(e){this.enabled=e;this.master&&this.context&&this.master.gain.setTargetAtTime(e?.4:0,this.context.currentTime,.15)}',
    'setEnabled(e){this.enabled=e;this.master&&this.context&&this.master.gain.setTargetAtTime(e?.4*(this.vol??1):0,this.context.currentTime,.15)}setVolume(e){this.vol=e,this.master&&this.context&&this.master.gain.setTargetAtTime(this.enabled?.4*e:0,this.context.currentTime,.1)}',
    "volApi")

rep('K=pt.useRef(new zw),',
    'K=pt.useRef((()=>{const z=new zw;try{z.vol=JSON.parse(localStorage.getItem("idea-game.striker.v2")||"{}").preferences?.volume??1}catch(_q){z.vol=1}window.__setVol=v=>z.setVolume(v/100);return z})()),',
    "volBoot")

# 7) ayarlar: volume satiri (sensitivity satirindan sonra)
rep('S.jsxs("div",{className:"settings-row",children:[S.jsx("strong",{children:n("difficulty")})',
    'S.jsxs("div",{className:"settings-row",children:[S.jsx("strong",{children:n("volume")}),S.jsxs("div",{className:"sensitivity-input",children:[S.jsx("input",{type:"range",min:"0",max:"100",step:"5",value:Math.round((s.volume??1)*100),onChange:a=>{const v=Number(a.target.value);window.__setVol&&window.__setVol(v);e({volume:v/100})},"aria-label":n("volume")}),S.jsxs("span",{children:[Math.round((s.volume??1)*100),"%"]})]})]}),S.jsxs("div",{className:"settings-row",children:[S.jsx("strong",{children:n("difficulty")})',
    "volRow")

# 8) Fw volume anahtari
rep('Fw={', 'Fw={volume:["VOLUME","SES DÜZEYİ","LAUTSTÄRKE","VOLUMEN","VOLUME","VOLUME","VOLUME","ГРОМКОСТЬ","VOLUME","مستوى الصوت"],', "fwVol")

# 9) overlay CSS
rep('.hg2-card:disabled{opacity:.45;cursor:default}\n',
    '.hg2-card:disabled{opacity:.45;cursor:default}\n.snow-overlay{position:absolute;inset:0;pointer-events:none;background-image:radial-gradient(2px 2px at 20% 10%,rgba(255,255,255,.75),transparent 60%),radial-gradient(1.6px 1.6px at 60% 30%,rgba(255,255,255,.6),transparent 60%),radial-gradient(2.2px 2.2px at 80% 60%,rgba(255,255,255,.7),transparent 60%),radial-gradient(1.4px 1.4px at 40% 80%,rgba(255,255,255,.5),transparent 60%);background-size:220px 220px,180px 180px,260px 260px,160px 160px;animation:snowFall 7s linear infinite}\n@keyframes snowFall{to{background-position:0 220px,0 180px,0 260px,0 160px}}\n.fog-overlay{position:absolute;inset:0;pointer-events:none;background:linear-gradient(180deg,rgba(214,226,232,.14),rgba(214,226,232,.32))}\n.storm-flash{position:absolute;inset:0;pointer-events:none;background:#fff;opacity:0;animation:stormFlash 7s linear infinite}\n@keyframes stormFlash{0%,86%,90%,100%{opacity:0}87%,88%{opacity:.3}}\n',
    "wCss")

# 10) badge
c = s.count("3.38 DEV")
if c < 2:
    print("FAIL badge", c); sys.exit(1)
s = s.replace("3.38 DEV", "3.39 DEV")
print("ok badge x", c)

io.open(P, "w", encoding="utf-8").write(s)
print("v64 size", len(s))
