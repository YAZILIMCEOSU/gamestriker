P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
old='this.droneG.position.set(pp.x-95+Math.sin(t*.35)*40,pp.y+28+Math.sin(t*.6)*4,pp.z-110+Math.cos(t*.25)*30);this.droneG.rotation.y=this.player.rotation.y'
assert s.count(old)==1, s.count(old)
new=('const cx=pp.x-40+Math.cos(t*.22)*210,cz=pp.z-260+Math.sin(t*.22)*210;'
     'this.droneG.position.set(cx,pp.y+28+Math.sin(t*.6)*4,cz);'
     'this.droneG.rotation.y=Math.atan2(-Math.sin(t*.22),Math.cos(t*.22))')
s=s.replace(old,new)
assert s.count('3.49 DEV')==2
s=s.replace('3.49 DEV','3.50 DEV')
open(P,'w',encoding='utf-8').write(s); print('v76 ok', len(s))
