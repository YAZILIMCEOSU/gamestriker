import re,sys
sys.path.insert(0,'striker-dev')
from i18n_data import T,AIR,CH,LB
from i18n_ar import AR,AIR_AR,CH_AR,LB_AR
old_audio=open('audio_class.js',encoding='utf-8').read().strip()
new_audio=open('striker-dev/audio5.js',encoding='utf-8').read().strip()
h=open('inner.html',encoding='utf-8').read()
def rep(old,new,n=1):
    global h
    c=h.count(old)
    if c!=n:
        print("FAIL count",c,"for:",old[:90]); sys.exit(1)
    h=h.replace(old,new)

# ---------- i18n helpers ----------
rep('})();function Ux','})();function __L(c,a){const i={tr:1,de:2,es:3,fr:4,it:5,pt:6,ru:7,id:8,ar:9}[c]||0;return a[Math.min(i,a.length-1)]}function __nx(c){const L=["tr","en","de","es","fr","it","pt","ru","id","ar"];return L[(L.indexOf(c)+1)%L.length]}function Ux')
# ---------- dictionary expansion ----------
dicttxt=open('fw_dict.txt',encoding='utf-8').read().strip()
pairs=re.findall(r'(\w+):\["((?:[^"\\]|\\.)*)","((?:[^"\\]|\\.)*)"\]',dicttxt)
assert len(pairs)==130, len(pairs)
newdict=[]
for k,en,tr in pairs:
    assert k in AR, k
    if k not in T:
        print("MISSING TRANSLATION",k); sys.exit(1)
    vals=[en,tr]+list(T[k])
    if k=="hangarDesc":
        vals=["Sixteen original airframes. Sixteen ways to own the sky.","On altı özgün tasarım. Gökyüzüne hükmetmenin on altı yolu.","Sechzehn originale Zellen. Sechzehn Arten, den Himmel zu beherrschen.","Dieciséis células originales. Dieciséis formas de dominar el cielo.","Seize cellules originales. Seize façons de dominer le ciel.","Sedici cellule originali. Sedici modi per dominare il cielo.","Dezesseis células originais. Dezesseis formas de dominar o céu.","Шестнадцать оригинальных машин. Шестнадцать способов господства в небе.","Enam belas airframe orisinal. Enam belas cara menguasai langit."]
    if k=="build":
        vals=["FLIGHT BUILD 3.4 DEV","UÇUŞ SÜRÜMÜ 3.4 DEV"]+list(T[k])
    if k=="missionDesc":
        vals[0]="48 operations across four fictional theaters. Your progress is saved on this device."
        vals[1]="Dört kurgusal bölgede 48 operasyon. İlerlemen bu cihazda kaydedilir."
    vals=list(vals)+[AR.get(k,"")]
    newdict.append(k+':['+','.join('"'+v.replace('"','\\"')+'"' for v in vals)+']')
EXT4={"heavyMissiles":("Heavy Missile Mode","A\u011f\u0131r F\u00fcze Modu"),"heavyMissilesHint":("70% more damage, slower round, longer reload.","%70 daha fazla hasar, daha yava\u015f mermi, daha uzun dolum."),"wingman":("AI Wingman","AI Kanat Arkada\u015f\u0131"),"wingmanHint":("An AI jet follows you and fires at nearby hostiles.","Bir yapay zek\u00e2 u\u00e7a\u011f\u0131 seni takip eder ve yak\u0131n d\u00fc\u015fmanlara ate\u015f eder."),"dailySortie":("DAILY SORTIE","G\u00dcN\u00dcN SORT\u0130S\u0130"),"watchReplay":("WATCH REPLAY","TEKRARI \u0130ZLE"),"fire":("FIRE","ATE\u015e"),"doubleCredits":("DOUBLE CREDITS","KRED\u0130LER\u0130 2'YE KATLA"),"bestSorties":("BEST SORTIES","EN \u0130Y\u0130 SORT\u0130LER"),"spring":("SPRING","\u0130LKBAHAR"),"summer":("SUMMER","YAZ"),"autumn":("AUTUMN","SONBAHAR"),"winter":("WINTER","KI\u015e"),"music":("MUSIC","M\u00dcZ\u0130K"),"musicHint":("Toggle background music (sound effects stay on).","Arka plan m\u00fczi\u011fini a\u00e7/kapat (ses efektleri ayr\u0131 \u00e7al\u0131\u015f\u0131r)."),"aiDuel":("AI DUEL","AI D\u00dcELLO"),"startAuto":("AUTOPILOT","OTOMAT\u0130K P\u0130LOT"),"startManual":("MANUAL","MANUEL")}
for k in ["dragHint","lockedNote","diagBtn","diagNote","fsError","retryBtn","cockpitView","cockpitHint","heavyMissiles","heavyMissilesHint","wingman","wingmanHint","dailySortie","watchReplay","fire","doubleCredits","bestSorties","spring","summer","autumn","winter","music","musicHint","aiDuel","startAuto","startManual"]:
    vals=[None,None]+list(T[k])+[AR[k]]
    if k in EXT4: vals[0],vals[1]=EXT4[k]
    newdict.append(k+':['+','.join('""' if v is None else '"'+v+'"' for v in vals)+']')
newdict.append('catapult:["CATAPULT LAUNCH","KATAPULT KALKIŞ","KATAPULTSTART","LANZAMIENTO CON CATAPULTA","DÉCOLLAGE CATAPULTE","LANCIO CATAPULTA","DECOLAGEM CATAPULTADA","КАТАПУЛЬТНЫЙ СТАРТ","PELONTARAN KATAPULT","إقلاع بالمجناق"]')
rep(dicttxt,'{'+','.join(newdict)+'}')
rep('function Jn(s,e){return Fw[e][s==="tr"?1:0]}','function Jn(s,e){return __L(s,Fw[e])}')
# array-index ternaries (role/desc/briefing)
h=re.sub(r'([\w.]+)\[(\w+)==="tr"\?1:0\]', lambda m: '__L(%s,%s)'%(m.group(2),m.group(1)), h)
# inline literal ternaries -> dict
rep('u==="tr"?"İNCELEMEK İÇİN SÜRÜKLE":"DRAG TO INSPECT"','__L(u,Fw.dragHint)')
rep('c==="tr"?"Önce bir önceki görevi tamamla.":"Complete the previous mission to unlock this operation."','__L(c,Fw.lockedNote)')
rep('s==="tr"?"UÇUŞ SİSTEMİNİ DENETLE":"RUN FLIGHT SYSTEM CHECKS"','__L(s,Fw.diagBtn)')
rep('s==="tr"?"kontrol başarılı. GPU / cihaz performans testi değildir.":"checks passed. Not a GPU / device performance test."','__L(s,Fw.diagNote)')
rep('de==="tr"?"Bu tarayıcı tam ekran modunu desteklemiyor.":"Fullscreen is unavailable in this browser."','__L(de,Fw.fsError)')
rep('de==="tr"?"YENİDEN DENE":"RETRY"','__L(de,Fw.retryBtn)')
# language UI: 9 buttons + header cycle
rep('S.jsxs("div",{className:"segmented-options",children:[S.jsx("button",{className:s.language==="tr"?"active":"",onClick:()=>e({language:"tr"}),children:"Türkçe"}),S.jsx("button",{className:s.language==="en"?"active":"",onClick:()=>e({language:"en"}),children:"English"})]})','S.jsxs("div",{className:"segmented-options lang-grid",children:["tr","en","de","es","fr","it","pt","ru","id","ar"].map(L9=>S.jsx("button",{className:s.language===L9?"active":"",onClick:()=>e({language:L9}),children:L9.toUpperCase()},L9))})')
rep('onLanguage:()=>Xe({language:de==="tr"?"en":"tr"})','onLanguage:()=>Xe({language:__nx(de)})')
# chapter data: nm/ds arrays + tab label
for nm,(names,descs) in CH.items():
    pass
rep('place:"PELAGIC ISLANDS",description:"A new pilot. An unfamiliar horizon."}','place:"PELAGIC ISLANDS",description:"A new pilot. An unfamiliar horizon.",nm:["FIRST LIGHT","İLK IŞIK","ERSTES LICHT","PRIMERA LUZ","PREMIÈRE LUMIÈRE","PRIMA LUCE","PRIMEIRA LUZ","ПЕРВЫЙ СВЕТ","CAHAYA PERTAMA","النور الأول"],ds:["Ein neuer Pilot. Ein fremder Horizont.","Un piloto nuevo. Un horizonte desconocido.","Un nouveau pilote. Un horizon inconnu.","Un nuovo pilota. Un orizzonte sconosciuto.","Um novo piloto. Um horizonte desconhecido.","Новый пилот. Незнакомый горизонт.","Pilot baru. Cakrawala asing.","طيار جديد. أفق غير مألوف."]}')
rep('place:"NORTHERN FLOTILLA",description:"The fleet is moving. Hold the line."}','place:"NORTHERN FLOTILLA",description:"The fleet is moving. Hold the line.",nm:["NORTHERN FRONT","KUZEY CEPHESİ","NORDFRONT","FRENTE NORTE","FRONT NORD","FRONTE NORD","FRENTE NORTE","СЕВЕРНЫЙ ФРОНТ","FRONT UTARA","الجبهة الشمالية"],ds:["Die Flotte bewegt sich. Halte die Linie.","La flota se mueve. Mantén la línea.","La flotte avance. Tenez la ligne.","La flotta si muove. Tieni la linea.","A frota se move. Segure a linha.","Флот в движении. Держи строй.","Armada bergerak. Tahan garis.","الأسطول يتحرك. اثبت على الخط."]}')
rep('place:"TARANIS ARCHIPELAGO",description:"Beyond the radar. Behind the front."}','place:"TARANIS ARCHIPELAGO",description:"Beyond the radar. Behind the front.",nm:["SILENT THUNDER","SESSİZ FIRTINA","STILLER DONNER","TRUENO SILENCIOSO","TONNERRE SILENCIEUX","TUONO SILENZIOSO","TROVÃO SILENCIOSO","ТИХИЙ ГРОМ","GUNTUR SENYAP","الرعد الصامت"],ds:["Jenseits des Radars. Hinter der Front.","Más allá del radar. Tras el frente.","Au-delà du radar. Derrière le front.","Oltre il radar. Dietro il fronte.","Além do radar. Atrás da frente.","За радаром. За линией фронта.","Di luar radar. Di balik garis depan.","وراء الرادار. خلف الجبهة."]}')
rep('place:"SHENLONG STRAIT",description:"One last flight. Everything to protect."}','place:"SHENLONG STRAIT",description:"One last flight. Everything to protect.",nm:["FINAL HORIZON","SON UFUK","LETZTER HORIZONT","HORIZONTE FINAL","HORIZON FINAL","ORIZZONTE FINALE","HORIZONTE FINAL","ПОСЛЕДНИЙ ГОРИЗОНТ","CAKRAWALA TERAKHIR","الأفق الأخير"],ds:["Ein letzter Flug. Alles zu schützen.","Un último vuelo. Todo por proteger.","Un dernier vol. Tout à protéger.","Un ultimo volo. Tutto da proteggere.","Um último voo. Tudo a proteger.","Последний полёт. Всё, что дорого.","Penerbangan terakhir. Semua untuk dilindungi.","طلعة أخيرة. كل شيء يستحق الحماية."]}')
rep('accent:"#58e6e0",price:2600}],Zd=[','accent:"#58e6e0",price:2600},{id:"falchion",code:"SF-16C",name:"FALCHION",role:["INTERCEPTOR","ÖNLEME"],description:["Radar-guided patience. Fast climb, steady gun, long missile reach.","Radar güdümlü sabır. Hızlı tırmanış, stabil top, uzun füze menzili."],speed:285,agility:1.35,hull:95,missiles:12,color:"#6b7466",accent:"#ffd08a",price:1200},{id:"ravager",code:"XA-44",name:"RAVAGER",role:["STRIKE","TAARRUZ"],description:["Heavy ordnance for the hardest decks. Slow to turn, hard to stop.","En zor güverteler için ağır mühimmat. Dönmesi ağır, durdurması zor."],speed:255,agility:1.0,hull:160,missiles:16,color:"#4a5560",accent:"#ff9d7a",price:3200}],Zd=[')
rep('const o=e!=="striker",c=e==="tempest"','const o=e!=="striker"&&e!=="falchion",c=e==="tempest"')
rep('o==="tr"?u.tr:u.name','__L(o,u.nm||[u.name,u.tr])')
# briefings 9 langs
# defense/radar/carrier/boss: match by EN lead
def rep_lb(kind,en_lead):
    global h
    m=re.search(re.escape(kind+':['+'"'+en_lead)+r'[^"]*","[^"]*"\]',h)
    if not m:
        print("FAIL lb",kind); sys.exit(1)
    old=m.group(0)
    en_tr=re.findall(r'"((?:[^"\\]|\\.)*)"',old)
    h=h.replace(old,kind+':['+','.join('"'+v+'"' for v in en_tr+list(LB[kind])+[LB_AR[kind]])+']')
rep_lb("strike","A hostile patrol")
rep_lb("intercept","Interceptors are approaching")
rep_lb("defense","Aurora is under threat.")
rep_lb("radar","A coastal radar")
rep_lb("carrier","An enemy carrier group")
rep_lb("boss","The command fleet")
# aircraft role/desc 9 langs
def rep_arr(old2,kind,key):
    global h
    old=kind+':['+','.join('"'+v+'"' for v in old2)+']'
    vals=old2+list(AIR[key][0 if kind=="role" else 1])+[AIR_AR[key][0 if kind=="role" else 1]]
    rep(old,kind+':['+','.join('"'+v+'"' for v in vals)+']')
rep_arr(["MULTIROLE","ÇOK AMAÇLI"],"role","striker")
rep_arr(["AIR SUPERIORITY","HAVA ÜSTÜNLÜĞÜ"],"role","spectre")
rep_arr(["EXPERIMENTAL","DENEYSEL"],"role","tempest")
rep_arr(["INTERCEPTOR","ÖNLEME"],"role","falchion")
rep_arr(["STRIKE","TAARRUZ"],"role","ravager")
for key,en,tr in [("striker","Precision meets agility. A balanced platform for every sortie.","Hassasiyet ve çeviklik. Her sorti için dengeli bir platform."),
 ("spectre","Twin-engine power. Heavy armor and an expanded missile payload.","Çift motor gücü. Ağır zırh ve genişletilmiş füze kapasitesi."),
 ("tempest","A new flight philosophy. Blended wings, incredible speed, minimal armor.","Yeni bir uçuş felsefesi. Bütünleşik kanatlar, yüksek hız, hafif zırh."),
 ("falchion","Radar-guided patience. Fast climb, steady gun, long missile reach.","Radar güdümlü sabır. Hızlı tırmanış, stabil top, uzun füze menzili."),
 ("ravager","Heavy ordnance for the hardest decks. Slow to turn, hard to stop.","En zor güverteler için ağır mühimmat. Dönmesi ağır, durdurması zor.")]:
    rep('description:["'+en+'","'+tr+'"]','description:['+','.join('"'+v+'"' for v in [en,tr]+list(AIR[key][1])+[AIR_AR[key][1]])+']')

# ---------- v4 core patches ----------
rep(old_audio,new_audio)
rep('const n=Math.floor(e/6),a=ob[e%6]','const n=Math.floor(e/12),a=ob[e%6]')
rep('strike:["corvette","destroyer","corvette"]','strike:["corvette","destroyer","corvette","radar","destroyer","corvette"]')
rep('intercept:["interceptor","attacker","heavy"]','intercept:["interceptor","attacker","interceptor","heavy","attacker","interceptor"]')
rep('defense:["destroyer","corvette","bomber"]','defense:["destroyer","corvette","bomber","interceptor","bomber","destroyer"]')
rep('radar:["radar","destroyer","drone"]','radar:["radar","destroyer","drone","corvette","drone","radar"]')
rep('carrier:["destroyer","carrier","corvette"]','carrier:["destroyer","carrier","corvette","interceptor","corvette","destroyer"]')
rep('boss:["heavy","carrier","destroyer","drone"]','boss:["heavy","carrier","destroyer","drone","interceptor","heavy"]')
rep('for(let u=0;u<n;u++)c.push(u%2?"interceptor":"destroyer")','for(let u=0;u<n*2;u++)c.push(u%3===2?"drone":u%2?"interceptor":"destroyer")')
rep('reward:400+e*65,limit:420+n*60,par:165+n*45','reward:420+e*55,limit:480+n*60,par:240+n*50')
rep('"FINAL APPROACH","NEW DAWN"]','"FINAL APPROACH","NEW DAWN","IRON DAWN","PEARL RUN","SIGNAL FIRE","BULWARK","NIGHT WATCH","STEEL RAIN","ORCA HUNT","RIPTIDE","FROSTBITE","MIDNIGHT SUN","QUIET WATER","VANADIS","STORM CELL","EYE OF TARANIS","PHANTOM WAKE","SALT WIND","UNDERTOW","LIGHTNING REEF","KRAKEN","LAST LIGHT","METEOR SHOWER","AZURE WALL","HOMECOMING","FIRST DAWN"]')
rep('(270+u*145)','(360+u*210)')
rep('p=-710-u*255-e.chapter*100','p=-1100-u*520-e.chapter*140')
rep('(a.difficulty==="hard"?1.2:1);this.entities.push','(a.difficulty==="hard"?1.2:1)*1.6;this.entities.push')
rep('get target(){','terr(e,n){let t=0;for(const[d,p,g,o,c]of[[-1900,-2200,920,420,0],[1600,-3200,1400,510,1],[-3200,1300,1400,330,2],[3100,-850,780,210,3],[400,-6200,1600,690,4],[-3500,-6600,1800,520,5]]){const w=e-d,E=n-p;if(Math.abs(w)<g*1.7&&Math.abs(E)<g*1.4){const x=Math.sqrt((w/g)**2+(E/(g*.75))**2),L=Math.sin(w*.007+c)*.19+Math.sin(E*.012+w*.004)*.13+Math.sin(w*.025-E*.019)*.035;t=Math.max(t,Math.max(-12,(1-x+L)*o)-3)}}return t}get target(){')
rep('this.player.y<20&&(this.health-=a*7,this.player.y=Math.max(6,this.player.y),this.pitch=Math.max(this.pitch,.03))','this.player.y<Math.max(20,this.terr(this.player.x,this.player.z)+16)&&(this.health-=a*8,this.player.y=Math.max(6,this.player.y,this.terr(this.player.x,this.player.z)+8),this.pitch=Math.max(this.pitch,.05),this.shake=Math.min(1,this.shake+.4))')
rep('this.bloom.enabled=e.quality==="high"||e.quality==="ultra"','this.bloom.enabled=e.quality!=="low"')
# ---------- aircraft paint from data ----------
rep('const a=new Vi;a.name=e;const o=e!=="striker"&&e!=="falchion",c=e==="tempest",u=this.material(new aa({color:c?"#4a6974":o?"#81909d":"#a0acb2",map:this.panel,metalness:.77,roughness:c?.42:.46,envMapIntensity:1.5})),f=this.material(new aa({color:c?"#65d5d0":"#b1c7cf",metalness:.55,roughness:.36}))','const a=new Vi;a.name=e;const o=e!=="striker"&&e!=="falchion",c=e==="tempest",P=no.find(x=>x.id===e)||{},u=this.material(new aa({color:P.color||(c?"#4a6974":o?"#81909d":"#a0acb2"),map:this.panel,metalness:.77,roughness:c?.42:.46,envMapIntensity:1.5})),f=this.material(new aa({color:P.accent||(c?"#65d5d0":"#b1c7cf"),metalness:.55,roughness:.36}))')
# ---------- per-aircraft missile loadout ----------
rep('this.aircraft=wl(n,o),this.health','this.aircraft=wl(n,o),this.mSet={striker:[450,8,110,.8],spectre:[450,9,125,.85],tempest:[520,6,95,.6],falchion:[540,7,100,.55],ravager:[380,14,160,1.15]}[n.id]||[450,8,110,.8],this.health')
rep('this.temp.copy(this.forward).multiplyScalar(450),this.spawn("missile",this.player,this.temp,8,110+this.upgrade*10,e.id)&&(this.missiles--,this.missileTimer=.8,this.shake=.18,this.event("launch",this.player))','this.temp.copy(this.forward).multiplyScalar(this.mSet[0]),this.spawn("missile",this.player,this.temp,this.mSet[1],this.mSet[2]+this.upgrade*10,e.id)&&(this.missiles--,this.missileTimer=this.mSet[3],this.shake=.18,this.event("launch",this.player))')
# ---------- AI upgrades ----------
rep('n.airborne&&(n.position.y=n.origin.y+Math.sin(n.phase*1.3)*55)','n.airborne&&(n.position.y+=(n.origin.y+Math.sin(n.phase*1.3)*55-n.position.y)*Math.min(1,e*1.5),n.position.x+=(this.player.x-n.position.x)*Math.min(1,e*.1),n.position.z+=(this.player.z-n.position.z)*Math.min(1,e*.1))')
rep('(this.preferences.difficulty==="hard"?7:11)+n.id%4*1.5','(this.preferences.difficulty==="hard"?6:9)+n.id%4*1.5')
rep('normalize().multiplyScalar(180),this.spawn("hostile"','normalize().multiplyScalar(200),this.spawn("hostile"')

# ---------- v6 gameplay ----------
rep('const f=["interceptor","heavy","attacker","drone","bomber"].includes(c),d=u===0?0:(u%2?-1:1)*(360+u*210),p=-1100-u*520-e.chapter*140,g=','const f=["interceptor","heavy","attacker","drone","bomber"].includes(c),p=-1100-u*520-e.chapter*140;let d=u===0?0:(u%2?-1:1)*(360+u*210);for(let q=1;q<8&&this.terr(d,p)>4;q++)d+=(q%2?1:-1)*(260+q*190);const g=')
rep('player=new H(0,165,420);forward','player=new H(0,24,860);forward')
rep('entities=[];projectiles=','entities=[];catT=0;projectiles=')
rep('speed=165;health','speed=0;health')
rep('this.time+=a,this.gunTimer-=a,','this.time+=a,this.catT+=a,this.gunTimer-=a,')
rep('const f=88+n.throttle*(this.aircraft.speed-88)+(n.boost?40:0);if(this.speed=li.damp(this.speed,f,.8,a),','const f=this.catT<2.6?Math.min(178,this.speed+260*a):88+n.throttle*(this.aircraft.speed-88)+(n.boost?40:0);if(this.speed=li.damp(this.speed,f,this.catT<2.6?3:.8,a),this.catT<2.6&&(this.pitch=Math.max(this.pitch,.07)),')
rep('this.catT>3&&this.player.y<Math.max(20,' if False else 'this.player.y<Math.max(20,this.terr(this.player.x,this.player.z)+16)&&(','this.catT>3&&this.player.y<Math.max(20,this.terr(this.player.x,this.player.z)+16)&&(')
rep('this.carrier.position.set(-230,0,1080)','this.carrier.position.set(0,0,1050)',2)
rep('this.assisted=a.assisted,e.targets.forEach','this.assisted=a.assisted,this.notify("catapult",3),e.targets.forEach')

# ---------- v7 S1 ----------
rep('language:u.language==="en"?"en":"tr"','language:["tr","en","de","es","fr","it","pt","ru","id","ar"].includes(u.language)?u.language:"tr"')
rep('language:"tr",assisted:!0,difficulty:"normal"','language:"tr",assisted:!1,cockpit:!1,difficulty:"normal"')
rep('assisted:typeof u.assisted=="boolean"?u.assisted:!0','assisted:typeof u.assisted=="boolean"?u.assisted:!1')
rep('reducedMotion:u.reducedMotion===!0,','reducedMotion:u.reducedMotion===!0,cockpit:u.cockpit===!0,')
rep('n(dn.length===24&&new Set(dn.map(u=>u.id)).size===24,"Mission IDs must be unique.")','n(dn.length===48&&new Set(dn.map(u=>u.id)).size===48,"Mission IDs must be unique.")')
rep('e("24 mission configurations"','e("48 mission configurations"')
rep('size===3,"Aircraft must have distinct flight stats."','size===16,"Aircraft must have distinct flight stats."')
rep('["reducedMotion","motion","motionDesc"]].map','["reducedMotion","motion","motionDesc"],["cockpit","cockpitView","cockpitHint"]].map')
rep('$.current.begin(ae),$.current.cameraMode="chase",z("chase"),','$.current.begin(ae),$.current.cameraMode=s.preferences.cockpit?"cockpit":"chase",z($.current.cameraMode),')
rep('this.renderer.toneMappingExposure=1,','this.renderer.toneMappingExposure=1.12,')
rep('this.bloom.strength=e.quality==="ultra"?.28:.19','this.bloom.strength=e.quality==="ultra"?.34:.24')
rep('this.flash.intensity=800','this.flash.intensity=1400')
rep('this.sun=new rx("#ffe1b9",4.1)','this.sun=new rx("#ffe1b9",4.5)')

# ---------- v8 S2 ----------
from i18n_air2 import AIR2,ROLES2,STATS2,ROLE_TR
_objs=[]
for _id in ["vanguard","ghost","talon","bastion","horizon","cyclone","marauder","sentinel","phantom","archer","kraken"]:
    c,nm,sp,ag,hu,mi,co,ac,pr=STATS2[_id];rl=ROLES2[_id]
    _objs.append('{id:"%s",code:"%s",name:"%s",role:["%s","%s"],description:[%s],speed:%d,agility:%s,hull:%d,missiles:%d,color:"%s",accent:"%s",price:%d}'%(_id,c,nm,rl,ROLE_TR[rl],','.join('"'+v+'"' for v in AIR2[_id]),sp,ag,hu,mi,co,ac,pr))
rep("price:3200}],Zd=[","price:3200},"+",".join(_objs)+"],Zd=[")
rep("}const o=e===\"carrier\",","}if(e===\"sub\"){const t=this.mesh(new oi(7,7,64,14),this.dark,[0,0,0]);t.rotation.x=Math.PI/2,a.add(t);a.add(this.box([4,7,10],this.dark,[0,6,-4]));a.add(this.box([1.2,3,8],this.dark,[0,4,14]));return a}const o=e===\"carrier\",")
rep('_=(c==="carrier"?380:','_=(c==="carrier"?380:c==="sub"?220:')
rep('radius:c==="carrier"?90:f?22:','radius:c==="carrier"?90:c==="sub"?26:f?22:')
rep('n.fireIn<=0&&this.flareTimer<=0','n.fireIn<=0&&(n.kind!=="sub"||n.surf)&&this.flareTimer<=0')
rep('(this.preferences.difficulty==="hard"?6:9)+n.id%4*1.5','(this.preferences.difficulty==="hard"?6:9)*(this.healthPercent<35?1.4:1)+n.id%4*1.5')
rep('damageEnemy(e,n){if(!(e.hp<=0)&&','damageEnemy(e,n){if(e.kind==="sub"&&!e.surf)return;if(!(e.hp<=0)&&')
rep('this.kills++,this.score+=e.kind==="carrier"?800:e.airborne?350:250,','this.kills++,this.combo=this.time-(this.lastKill||-99)<6?(this.combo||0)+1:1,this.lastKill=this.time,this.score+=(e.kind==="carrier"?800:e.airborne?350:250)+40*((this.combo||1)-1),')
rep('o.airborne||(c.position.y=0)','o.airborne||o.kind==="sub"||(c.position.y=0)')
rep('o.visible=c.hp>0,o.position.set(c.position.x,.25,c.position.z)','o.visible=c.hp>0&&(c.kind!=="sub"||c.surf),o.position.set(c.position.x,.25,c.position.z)')
rep('this.flash.intensity=1400','this.flash.intensity=1400,this.particles.emit(a.position,new H(0,26,0),26,4,"#2b2f31",!0),this.particles.emit(a.position,new H(0,14,0),18,3,"#41484c",!0)')
rep('n.airborne&&(n.position.y+=(n.origin.y+Math.sin(n.phase*1.3)*55-n.position.y)*Math.min(1,e*1.5),n.position.x+=(this.player.x-n.position.x)*Math.min(1,e*.1),n.position.z+=(this.player.z-n.position.z)*Math.min(1,e*.1))','n.airborne&&(n.position.y+=(n.origin.y+Math.sin(n.phase*1.3)*55-n.position.y)*Math.min(1,e*1.5),n.position.x+=(this.player.x-n.position.x)*Math.min(1,e*.1),n.position.z+=(this.player.z-n.position.z)*Math.min(1,e*.1)),n.kind==="sub"&&(n.surf=((this.time+n.id*7)%26)>12&&((this.time+n.id*7)%26)<24,n.position.y=n.surf?2:-16,n.surf&&!n.ps&&this.event("surf",n.position,10),n.ps=n.surf)')
rep('strike:["corvette","destroyer","corvette","radar","destroyer","corvette"]','strike:["corvette","destroyer","corvette","radar","destroyer","corvette","sub"]')
rep('radar:["radar","destroyer","drone","corvette","drone","radar"]','radar:["radar","destroyer","drone","corvette","drone","radar","sub"]')
rep('carrier:["destroyer","carrier","corvette","interceptor","corvette","destroyer"]','carrier:["destroyer","carrier","corvette","interceptor","corvette","destroyer","sub"]')
rep('boss:["heavy","carrier","destroyer","drone","interceptor","heavy"]','boss:["heavy","carrier","destroyer","drone","interceptor","heavy","sub"]')

# ---------- v9 S2w2 ----------
def repn(a,b,n=2):
    global h
    assert h.count(a)==n,(a,h.count(a))
    h=h.replace(a,b)
repn('assisted:!1,cockpit:!1,difficulty:"normal"','assisted:!1,cockpit:!1,heavyMissiles:!1,wingman:!1,difficulty:"normal"',1)
repn('cockpit:u.cockpit===!0,','cockpit:u.cockpit===!0,heavyMissiles:u.heavyMissiles===!0,wingman:u.wingman===!0,',1)
rep('["cockpit","cockpitView","cockpitHint"]].map','["cockpit","cockpitView","cockpitHint"],["heavyMissiles","heavyMissiles","heavyMissilesHint"],["wingman","wingman","wingmanHint"]].map')
rep('ravager:[380,14,160,1.15]}[n.id]','ravager:[380,14,160,1.15],vanguard:[470,8,120,.8],ghost:[440,10,105,.9],talon:[500,7,115,.65],bastion:[360,15,150,1.2],horizon:[560,6,90,.55],cyclone:[580,5,95,.5],marauder:[400,13,140,1.05],sentinel:[460,9,110,.85],phantom:[530,7,100,.6],archer:[600,5,85,.45],kraken:[340,16,170,1.3]}[n.id]')
rep('const e=this.target;if(this.lock<1||!e){this.notify("lockFirst");return}this.temp.copy(this.forward).multiplyScalar(this.mSet[0]),this.spawn("missile",this.player,this.temp,this.mSet[1],this.mSet[2]+this.upgrade*10,e.id)&&(this.missiles--,this.missileTimer=this.mSet[3],','const e=this.target;if(this.lock<1||!e){this.notify("lockFirst");return}const m=this.preferences.heavyMissiles?[this.mSet[0]*.85,this.mSet[1]*1.35,this.mSet[2]*1.7+this.upgrade*14,this.mSet[3]*1.25]:[this.mSet[0],this.mSet[1],this.mSet[2]+this.upgrade*10,this.mSet[3]];this.temp.copy(this.forward).multiplyScalar(m[0]),this.spawn("missile",this.player,this.temp,m[1],m[2],e.id)&&(this.missiles--,this.missileTimer=m[3],')
rep('this.updateEnemies(a);const d=this.target','this.updateEnemies(a),this.updateWingman(a);const d=this.target')
rep('updateEnemies(e){for(const n of this.entities){if(!n.hp)continue;','updateWingman(e){if(!this.preferences.wingman||this.phase!=="combat")return;this.wingT=(this.wingT||0)-e;if(this.wingT>0)return;let t=null,b=225e4;for(const n of this.entities)if(n.hp){const d=n.position.distanceToSquared(this.player);d<b&&(b=d,t=n)}if(!t)return;this.wingT=3.4;this.temp.copy(this.player).addScaledVector(this.forward,-28),this.temp.y+=7;const a=this.temp2||(this.temp2=new H);a.copy(t.position).sub(this.temp).normalize().multiplyScalar(420);this.spawn("missile",this.temp,a,7,70+this.upgrade*6,t.id)&&this.event("launch",this.temp)}updateEnemies(e){for(const n of this.entities){if(!n.hp)continue;')

# ---------- v10 S3w1 ----------
rep('function x_(s){return dn.find(e=>!s[e.id])?.id??23}','function x_(s){return dn.find(e=>!s[e.id])?.id??23}function Ddaily(){const s=new Date;return (s.getFullYear()*372+(s.getMonth()+1)*31+s.getDate())%48}function GdDaystr(){const s=new Date;return s.getFullYear()+"-"+(s.getMonth()+1)+"-"+s.getDate()}')
rep('if(!Rl(d,s.records))return;','if(!Rl(d,s.records)&&d!==Ddaily())return;')
rep('"campaign-content scroll-screen",children:[S.jsxs("div",{className:"scree','"campaign-content scroll-screen",children:[S.jsx("button",{className:"daily-sortie-btn",style:{display:"block",margin:"18px auto 0",padding:"13px 26px",border:"1px solid #e8a33d",borderRadius:"10px",background:"linear-gradient(180deg,#e8a33d,#c7822a)",color:"#17130b",fontWeight:700,letterSpacing:".08em",cursor:"pointer",fontSize:"14px"},onClick:()=>e(Ddaily()),children:S.jsxs("span",{children:[c("dailySortie"),s.daily?.score>0?S.jsxs("b",{children:[" · ",s.daily.score]}):null]})}),S.jsxs("div",{className:"scree')
rep('return{...Be,credits:Be.credits+ae.reward,records:{...Be.records,[Ee]:De}}','return{...Be,credits:Be.credits+ae.reward,records:{...Be.records,[Ee]:De},daily:Ee===Ddaily()&&(!Be.daily||Be.daily.date!==GdDaystr()||ae.score>Be.daily.score)?{date:GdDaystr(),score:ae.score,mission:Ee}:Be.daily||{date:"",score:0,mission:-1}}')
rep('records:{},preferences:{quality:','records:{},daily:{date:"",score:0,mission:-1},preferences:{quality:')
rep('records:o,preferences:f}}catch{return s}','records:o,preferences:f,daily:e.daily&&Number.isFinite(e.daily.score)?{date:String(e.daily.date||""),score:Math.max(0,Math.floor(e.daily.score)),mission:Number.isFinite(e.daily.mission)?e.daily.mission:-1}:{date:"",score:0,mission:-1}}}catch{return s}')
# ---------- v11 S3w2: sorti kaydedici ----------
rep('ie=pt.useRef(!1),me=pt.useRef(!0),','ie=pt.useRef(!1),rp=pt.useRef(null),me=pt.useRef(!0),')
rep('boost:he.has("ShiftLeft")||he.has("ShiftRight")})}ae.processEvents','boost:he.has("ShiftLeft")||he.has("ShiftRight")})}ne.rec||(ne.rec=[]),(ne.recT=(ne.recT||0)+T)>=.05&&(ne.recT=0,ne.rec.length<4200&&ne.rec.push([Math.round(ne.time*20),Math.round(ne.player.x),Math.round(ne.player.y),Math.round(ne.player.z),Math.round(ne.heading*1e3),Math.round(ne.pitch*1e3),Math.round(ne.speed)])),ae.processEvents')
rep('if(!J.paused&&!J.modal&&!ne.result){const he=G.current','if(rp.current){const q=rp.current;q.t+=T;const k=Math.floor(q.t/.05);if(k>=q.rec.length-1){rp.current=null,F(q.res)}else{const r0=q.rec[k];ne.player.set(r0[1],r0[2],r0[3]),ne.heading=r0[4]/1e3,ne.pitch=r0[5]/1e3,ne.speed=r0[6],ne.time=r0[0]/20,ne.forward.set(Math.sin(ne.heading)*Math.cos(ne.pitch),Math.sin(ne.pitch),-Math.cos(ne.heading)*Math.cos(ne.pitch))}}else if(!J.paused&&!J.modal&&!ne.result){const he=G.current')
rep('function Qw({result:s,language:e,missionId:n,onNext:a,onRetry:o,onExit:c})','function Qw({result:s,language:e,missionId:n,onNext:a,onRetry:o,onExit:c,onReplay:p})')
rep('S.jsxs("button",{className:"text-button",onClick:c,children:[S.jsx(jM,{size:14}),u("exit")]})','p&&S.jsx("button",{className:"text-button",onClick:p,children:u("watchReplay")}),S.jsxs("button",{className:"text-button",onClick:c,children:[S.jsx(jM,{size:14}),u("exit")]})')
rep('S.jsx(Qw,{result:L,language:de,missionId:d,onNext:We,onRetry:Ce,onExit:rt})','S.jsx(Qw,{result:L,language:de,missionId:d,onNext:We,onRetry:Ce,onExit:rt,onReplay:j.current?.rec?.length>20?()=>{rp.current={rec:j.current.rec,t:0,res:L},F(null)}:null})')
# ---------- v12 S4w1: touch stick + PWA ----------
rep('},ke=()=>{document.hidden&&Be()};return window.addEventListener("keydown",ae),window.addEventListener("keyup",Ee),window.addEventListener("blur",Be),document.addEventListener("visibilitychange",ke),()=>{window.removeEventListener("keydown",ae),window.removeEventListener("keyup",Ee),','},ke=()=>{document.hidden&&Be()},tj={id:null,x:0,y:0},ij=e=>{const n=D.current;if(!n.flight||n.paused||n.modal||n.result||e.target!==Q.current)return;tj.id=e.pointerId,tj.x=e.clientX,tj.y=e.clientY},sj=e=>{if(e.pointerId!==tj.id)return;B.current.yaw=Math.max(-1,Math.min(1,(e.clientX-tj.x)/110)),B.current.pitch=Math.max(-1,Math.min(1,-(e.clientY-tj.y)/110))},nj=e=>{e.pointerId!==tj.id&&null!==tj.id||(tj.id=null,B.current.yaw=0,B.current.pitch=0)};return window.addEventListener("keydown",ae),window.addEventListener("keyup",Ee),window.addEventListener("blur",Be),document.addEventListener("visibilitychange",ke),window.addEventListener("pointerdown",ij),window.addEventListener("pointermove",sj),window.addEventListener("pointerup",nj),window.addEventListener("pointercancel",nj),()=>{window.removeEventListener("pointerdown",ij),window.removeEventListener("pointermove",sj),window.removeEventListener("pointerup",nj),window.removeEventListener("pointercancel",nj),window.removeEventListener("keydown",ae),window.removeEventListener("keyup",Ee),')
rep('<link rel="icon" type="image/svg+xml" href="./favicon.svg" />','<link rel="icon" type="image/svg+xml" href="./favicon.svg" /><link rel="manifest" href="./manifest.webmanifest" /><meta name="theme-color" content="#0b0e10" /><meta name="apple-mobile-web-app-capable" content="yes" /><meta name="apple-mobile-web-app-title" content="Striker" />')
rep('</style>\n  </head>','</style>\n  <script>navigator.serviceWorker&&navigator.serviceWorker.register("./sw.js").catch(()=>{});</script>\n  </head>')
# ---------- v13 S4w2: dokunmatik kilit + touch HUD ----------
rep('tj.id=e.pointerId,tj.x=e.clientX,tj.y=e.clientY}','tj.id=e.pointerId,tj.x=e.clientX,tj.y=e.clientY,tj.t=performance.now()}')
rep('nj=e=>{e.pointerId!==tj.id&&null!==tj.id||(tj.id=null,B.current.yaw=0,B.current.pitch=0)}','nj=e=>{if(e.pointerId===tj.id||null===tj.id){const a=Math.abs(e.clientX-tj.x)<12&&Math.abs(e.clientY-tj.y)<12&&performance.now()-tj.t<400,b=$.current,n=j.current;if(a&&b&&n&&n.phase==="combat")for(const f of b.markers(n)){if(!f.visible)continue;const d=Math.hypot(f.x-e.clientX/innerWidth*100,f.y-e.clientY/innerHeight*100);if(d<10){n.targetId=f.id,n.lock=0,n.lockedSound=!1,n.rejoinPoint=null;break}}tj.id=null,B.current.yaw=0,B.current.pitch=0}}')
rep('</script>\n  </head>','</script>\n  <style>@media (pointer:coarse){.weapons-controls{width:auto;bottom:18px;right:14px;gap:10px}.weapons-controls .weapon,.gyro-toggle{min-width:56px;min-height:52px}}</style>\n  </head>')
# ---------- v14 S1w2: fragman kalitesi su + şok dalgası ----------
rep('p.y+=sin(p.x*.013+uTime*.5)*1.3+sin(p.z*.023+uTime*.7)*.65;','p.y+=sin(p.x*.013+uTime*.5)*1.3+sin(p.z*.023+uTime*.7)*.65+sin((p.x*.7+p.z*.7)*.031+uTime*1.15)*.42+sin((p.x*.86-p.z*.5)*.052-uTime*.9)*.26;')
rep('float wave(vec2 p){return sin(p.x*.17+p.y*.075+uTime*1.5)*.32+sin(p.y*.27-p.x*.1+uTime*1.1)*.17+noise(p*.085+uTime*.02)*.75;}','float wave(vec2 p){return sin(p.x*.17+p.y*.075+uTime*1.5)*.32+sin(p.y*.27-p.x*.1+uTime*1.1)*.17+sin((p.x*.4+p.y*.9)*.33-uTime*2.2)*.09+noise(p*.085+uTime*.02)*.75;}')
rep('col+=vec3(1.,.78,.43)*spec*2.1;\n          float foam=smoothstep(.97,.995,noise(p*.08+uTime*.025));col+=foam*.065;','col+=vec3(1.,.78,.43)*spec*2.1;\n          float glit=pow(max(dot(reflect(-sun,normal),view),0.0),900.0);col+=vec3(1.,.9,.66)*glit*3.4;\n          float foam=smoothstep(.97,.995,noise(p*.08+uTime*.025))+smoothstep(.62,1.05,wave(p))*.3;col+=min(foam,1.0)*.085;')
rep('this.particles.emit(a.position,new H(0,26,0),26,4,"#2b2f31",!0),this.particles.emit(a.position,new H(0,14,0),18,3,"#41484c",!0)','this.particles.emit(a.position,new H(0,26,0),26,4,"#2b2f31",!0),this.particles.emit(a.position,new H(0,14,0),18,3,"#41484c",!0),(()=>{for(let q=0;q<10;q++)this.particles.emit(a.position,new H(Math.cos(q*.628)*52,4,Math.sin(q*.628)*52),34,2.4,"#ffb46b",!0)})()')
# ---------- v15 S4 cila + S5 ----------
rep('className:"weapons-controls",children:[S.jsxs("button",{className:`weapon missile-button','className:"weapons-controls",children:[S.jsx("button",{className:"weapon fire-button",style:{background:"#3a1f16",borderColor:"#ff8a5c"},onPointerDown:e=>{e.preventDefault(),s.input.current.fire=!0},onPointerUp:()=>{s.input.current.fire=!1},onPointerLeave:()=>{s.input.current.fire=!1},children:S.jsx("span",{children:o("fire")})}),S.jsxs("button",{className:`weapon missile-button')
rep(':Be.daily||{date:"",score:0,mission:-1}}','  :Be.daily||{date:"",score:0,mission:-1},dailyHistory:[{date:GdDaystr(),score:Math.max(ae.score,Be.dailyHistory?.find(z=>z.date===GdDaystr())?.score||0),mission:Ee},...(Be.dailyHistory||[]).filter(z=>z.date!==GdDaystr())].sort((p,q)=>q.score-p.score).slice(0,25)}'.replace("  ",""))
rep('{date:"",score:0,mission:-1}}}catch{return s}','{date:"",score:0,mission:-1},dailyHistory:Array.isArray(e.dailyHistory)?e.dailyHistory.filter(z=>z&&Number.isFinite(z.score)).slice(0,25).map(z=>({date:String(z.date||""),score:Math.max(0,Math.floor(z.score)),mission:Number.isFinite(z.mission)?z.mission:-1})):[]}}catch{return s}')
rep('daily:{date:"",score:0,mission:-1},preferences:','daily:{date:"",score:0,mission:-1},dailyHistory:[],preferences:')
rep('s.daily?.score>0?S.jsxs("b",{children:[" · ",s.daily.score]}):null]})}),S.jsxs("div",{className:"scree','s.daily?.score>0?S.jsxs("b",{children:[" · ",s.daily.score]}):null]})}),s.dailyHistory?.length>0?S.jsx("div",{style:{maxWidth:560,margin:"10px auto 0"},children:S.jsxs("div",{children:[S.jsx("strong",{children:c("bestSorties")}),S.jsx("div",{style:{display:"grid",gap:4,marginTop:6},children:s.dailyHistory.slice(0,5).map((z,k)=>S.jsxs("div",{style:{display:"flex",justifyContent:"space-between",fontSize:13,opacity:.85},children:[S.jsx("span",{children:z.date+" · #"+(z.mission+1)}),S.jsx("b",{children:z.score})]},k))})]})}):null,S.jsxs("div",{className:"scree')
rep('function Qw({result:s,language:e,missionId:n,onNext:a,onRetry:o,onExit:c,onReplay:p})','function Qw({result:s,language:e,missionId:n,onNext:a,onRetry:o,onExit:c,onReplay:p,onDouble:w})')
rep('p&&S.jsx("button",{className:"text-button",onClick:p,children:u("watchReplay")}),','w&&S.jsx("button",{className:"text-button",onClick:w,children:u("doubleCredits")}),p&&S.jsx("button",{className:"text-button",onClick:p,children:u("watchReplay")}),')
rep('onReplay:j.current?.rec?.length>20?()=>{rp.current={rec:j.current.rec,t:0,res:L},F(null)}:null})','onReplay:j.current?.rec?.length>20?()=>{rp.current={rec:j.current.rec,t:0,res:L},F(null)}:null,onDouble:window.StrikerAds?.showRewarded&&L?()=>{window.StrikerAds.showRewarded(q=>{q&&e(Be=>({...Be,credits:Be.credits+(L.reward||0)}))})}:null})')
# ---------- v16 P0-A: tanılama genişletme ----------
rep('"Assisted training pilot could not complete the first sortie.")}),s}','"Assisted training pilot could not complete the first sortie.")}),e("Submarine surfaces and is only vulnerable when surfaced",()=>{const f=dn.find(d=>d.targets.includes("sub")),u=new Pa(f,"striker",a),sb=u.entities.find(d=>d.kind==="sub");n(!!sb,"Strike mission has no submarine.");let d=0;for(;d<1700&&!sb.surf;d++)u.update(1/60,o),u.events.length=0;n(sb.surf,"Submarine did not surface within its cycle.");const p0=sb.hp;u.damageEnemy(sb,50);const p1=sb.hp;n(p1<p0,"Surfaced submarine took no damage.");sb.surf=!1;u.damageEnemy(sb,50),n(sb.hp===p1,"Submerged submarine was damaged.")}),e("Wingman engages nearby hostiles",()=>{const u=new Pa(dn[0],"striker",{...a,wingman:!0});u.player.copy(u.entities[0].position),u.player.y+=120,u.player.z-=420;let fired=!1;for(let d=0;d<300;d++){u.update(1/60,o),fired=fired||u.projectiles.some(p=>p.active&&p.kind==="missile"),u.events.length=0;if(fired)break}n(fired,"AI wingman never fired at a nearby hostile.")}),e("Heavy missile mode increases damage",()=>{const u=new Pa(dn[0],"striker",{...a,heavyMissiles:!0});c(u,90);u.fireMissile();const p=u.projectiles.find(q=>q.active&&q.kind==="missile");n(p&&p.damage>150,"Heavy missile damage not applied.")}),e("Daily helpers stay in range",()=>{n(Ddaily()>=0&&Ddaily()<48,"Daily mission index out of range."),n(/^\\d{4}-\\d{1,2}-\\d{1,2}$/.test(GdDaystr()),"Daily date key malformed.")}),s}')
# ---------- v17 hotfix: hangar şeridi + ikonlar + demo modu ----------
rep('.aircraft-selector{pointer-events:auto;gap:10px;display:flex;position:absolute;bottom:0;right:0}','.aircraft-selector{pointer-events:auto;gap:10px;display:flex;position:absolute;bottom:0;right:0;left:0;overflow-x:auto;padding:0 16px 12px;-webkit-overflow-scrolling:touch;scrollbar-width:thin}')
rep('.aircraft-choice{text-align:left;','.aircraft-choice{flex:0 0 auto;text-align:left;')
rep('d:n[s],fill:"currentColor",fillOpacity:".13"','d:n[s]||n.striker,fill:"currentColor",fillOpacity:".13"')
rep('pt.useEffect(()=>{if(!Q.current)return;','pt.useEffect(()=>{if(typeof location<"u"&&/[?&]demo/.test(location.search))e(Be=>({...Be,credits:99999,owned:no.map(z=>z.id),upgrades:Object.fromEntries(no.map(z=>[z.id,3])),records:Object.fromEntries(dn.map(z=>[z.id,{stars:3,score:9999,seconds:60}]))}))},[]);pt.useEffect(()=>{if(!Q.current)return;')
# ---------- v18: uçak başına ayrı siluet ----------
rep('P=no.find(x=>x.id===e)||{},u=this.material','P=no.find(x=>x.id===e)||{},SH={vanguard:{span:1,canard:!0,fin:1},ghost:{span:.84,sweep:1.15,canard:!1,fin:.2},talon:{span:.95,sweep:.9,canard:!0,fin:.45},bastion:{span:1.16,sweep:.85,canard:!0,fin:.3},horizon:{span:1.22,sweep:1.05,canard:!1,fin:.36},cyclone:{span:.88,sweep:1.25,canard:!0,fin:.55},marauder:{span:1.05,sweep:.8,canard:!1,fin:.36,eng:1},sentinel:{span:1,canard:!0,fin:.4},phantom:{span:.9,sweep:1.3,canard:!1,fin:.12},archer:{span:1.08,sweep:.95,canard:!0,fin:.42,eng:1},kraken:{span:1.28,sweep:.75,canard:!1,fin:.3,eng:1}},u=this.material')
rep('for(const x of[-1,1]){const L=c?9.8:o?9.2:8.4,F=this.mesh(Tu(c?1.4:1.25,L,','for(const x of[-1,1]){const q=SH[e]||{},L=(c?9.8:o?9.2:8.4)*(q.span||1),F=this.mesh(Tu(c?1.4:1.25,L,')
rep('if(a.add(F),a.add(this.surface(','if(F.scale.z=q.sweep||1,a.add(F),a.add(this.surface(')
rep(',!c){const X=this.mesh(Tu(.8,',',!c&&q.canard!==!1){const X=this.mesh(Tu(.8,')
rep('O.rotation.z=-x*(c?.55:.36),a.add(O)','O.rotation.z=-x*(c?.55:.36*(q.fin||1)),a.add(O)')
rep('const b=o?2:1','const b=o?SH[e]&&SH[e].eng||2:1')
# ---------- v19: 4 mevsim x 48 = 192 görev ----------
rep('rb=["FIRST STRIKE"','rb=[0,1,2,3].flatMap(SN=>["FIRST STRIKE"')
rep('"HOMECOMING","FIRST DAWN"]','"HOMECOMING","FIRST DAWN"])')
rep('const n=Math.floor(e/12),a=ob[e%6]','const n=Math.floor(e%48/12),sn=Math.floor(e/48),a=ob[e%6]')
rep('return{id:e,name:s,chapter:n,kind:a,targets:c,briefing:lb[a],reward:420+e*55,limit:480+n*60,par:240+n*50,sunset:e%3!==1}','return{id:e,name:s+(sn?[""," \u00b7SUMMER"," \u00b7AUTUMN"," \u00b7WINTER"][sn]:""),season:sn,chapter:n,kind:a,targets:sn>1&&c.length<9?c.concat("drone"):c,briefing:lb[a],reward:420+e*55,limit:480+n*60,par:240+n*50,sunset:[.12,0,.6,1][sn]}')
rep('*(a.difficulty==="hard"?1.2:1)*1.6','*(a.difficulty==="hard"?1.2:1)*1.6*(1+(e.season||0)*.18)*(1+((e.id||0)%48)/48*.28)')
rep('(this.preferences.difficulty==="hard"?6:9)*(this.healthPercent<35?1.4:1)','((this.preferences.difficulty==="hard"?6:9)/(1+(this.mission.season||0)*.12+((this.mission.id||0)%48)/120))*(this.healthPercent<35?1.4:1)')
rep('return (s.getFullYear()*372+(s.getMonth()+1)*31+s.getDate())%48}','return (s.getFullYear()*372+(s.getMonth()+1)*31+s.getDate())%192}')
rep('e("48 mission configurations",()=>{n(dn.length===48&&new Set(dn.map(u=>u.id)).size===48','e("192 mission configurations",()=>{n(dn.length===192&&new Set(dn.map(u=>u.id)).size===192')
rep('Math.floor(Object.keys(s.records).length/6))),o=s.preferences.language','Math.floor(Object.keys(s.records).length/6))),[sn,ssn]=pt.useState(0),o=s.preferences.language')
rep('S.jsx("div",{className:"chapter-tabs",role:"tablist"','S.jsx("div",{className:"chapter-tabs",style:{marginBottom:8},children:[0,1,2,3].map(f=>S.jsx("button",{className:sn===f?"active":"",onClick:()=>ssn(f),children:c(["spring","summer","autumn","winter"][f])},f))}),S.jsx("div",{className:"chapter-tabs",role:"tablist"')
rep('dn.filter(u=>u.chapter===n)','dn.filter(u=>u.chapter===n&&u.season===sn)')
rep('children:"/ 24"','children:"/ "+dn.length')
rep('this.box([4.7,.45,2.5],this.dark,[0,-1.25,-2.3])','this.box([4.7,.3,2.2],this.dark,[0,-1.42,-2.3])')
rep('this.box([2.1,.5,1],this.dark,[0,-.8,-3.1])','this.box([1.9,.34,.9],this.dark,[0,-.95,-3.1])')
rep('opacity:.09,roughness:.05','opacity:.05,roughness:.05')
rep('this.cameraPoint.copy(n.player).add(new H(0,1.75,0))','this.cameraPoint.copy(n.player).add(new H(0,1.9,0))')
# ---------- v20: dağ içi hedef fix + kokpit gerçekçilik + ışıklar + katapult ----------
rep('const f=["interceptor","heavy","attacker","drone","bomber"].includes(c),p=-1100-u*520-e.chapter*140;let d=u===0?0:(u%2?-1:1)*(360+u*210);for(let q=1;q<8&&this.terr(d,p)>4;q++)d+=(q%2?1:-1)*(260+q*190);const g=f?190+u*28:c==="radar"?26:8,_=','const f=["interceptor","heavy","attacker","drone","bomber"].includes(c),g=f?190+u*28:c==="radar"?26:8;let p=-1100-u*520-e.chapter*140,d=u===0?0:(u%2?-1:1)*(360+u*210);for(let q=1;q<26&&this.terr(d,p)>(f?g-50:0);q++)q%3===0?p-=260:d+=(q%2?1:-1)*(320+q*120);const _=')
rep('const n=this.material(new tx({color:"#5d9f8c"','e.add(this.line([[-.22,0,-3.3],[.22,0,-3.3]],this.light,.02)),e.add(this.line([[0,-.15,-3.3],[0,.15,-3.3]],this.light,.02));for(const a of[-1,1])e.add(this.line([[a*.3,.13,-3.3],[a*.17,.13,-3.3]],this.light,.014)),e.add(this.line([[a*.3,-.13,-3.3],[a*.17,-.13,-3.3]],this.light,.014)),e.add(this.box([.14,.42,.62],this.dark,[a*1.02,-1.18,-1.75]));const n=this.material(new tx({color:"#5d9f8c"')
rep('const w=this.mesh(new qi(2.2,.55),this.label(','const BC=this.mesh(new ia(.07,8,6),this.light,[0,.62,7.9]);BC.name="strobe",a.add(BC);const w=this.mesh(new qi(2.2,.55),this.label(')
rep('a.name==="nav-light"&&(a.visible=Math.sin(this.time*3)>-.6)','(a.name==="nav-light"||a.name==="strobe")&&(a.visible=a.name==="strobe"?Math.sin(this.time*7)>0:Math.sin(this.time*3)>-.6)')
rep('this.camera.fov=li.damp(this.camera.fov,this.cameraMode==="cockpit"?68:58+n.speed/35,2,e),this.camera.updateProjectionMatrix()','this.camera.fov=li.damp(this.camera.fov,this.cameraMode==="cockpit"?68:58+n.speed/35,2,e),!this.options.reducedMotion&&n.catT<2.6&&(this.camera.position.x+=Math.sin(this.time*90)*.26*(2.6-n.catT),this.camera.position.y+=Math.cos(this.time*77)*.16*(2.6-n.catT),this.camera.fov-=6),this.camera.updateProjectionMatrix()')
# ---------- v21: müzik kontrolü + yoğunluk + AI düello + dron + brifing seçimi ----------
def repn(a,b,n=2):
    global h
    assert h.count(a)==n,(a,h.count(a))
    h=h.replace(a,b)
rep('setEngine(e,n){if(!this.context','setMusicOn(e){this.musicOn=e!==!1,this.musicG&&(this.musicG.gain.value=this.musicOn?.33:0)}setIntensity(e){this.musicG&&this.musicOn!==!1&&(this.musicG.gain.value=.3+.26*Math.max(0,Math.min(1,e||0)))}setEngine(e,n){if(!this.context')
repn('K.current.setEnabled(s.preferences.sound)','K.current.setEnabled(s.preferences.sound),K.current.setMusicOn(s.preferences.musicOn!==!1)')
rep('K.current.setEngine(ne.speed,!J.paused&&!J.modal&&!ne.result),','K.current.setEngine(ne.speed,!J.paused&&!J.modal&&!ne.result),K.current.setIntensity(ne.incoming?1:ne.result?0:ne.lock>=1?.55:.2),')
rep('["wingman","wingman","wingmanHint"]].map','["wingman","wingman","wingmanHint"],["musicOn","music","musicHint"]].map')
rep('wingman:!1,difficulty:"normal"','wingman:!1,musicOn:!0,difficulty:"normal"')
rep('wingman:u.wingman===!0,','wingman:u.wingman===!0,musicOn:u.musicOn!==!1,')

rep('e("192 mission configurations",()=>{n(dn.length===192&&new Set(dn.map(u=>u.id)).size===192','dn.push({id:192,name:"DUEL ARENA",season:3,chapter:0,kind:"boss",targets:["interceptor"],briefing:lb.boss,reward:1500,limit:300,par:150,sunset:1}),e("193 mission configurations",()=>{n(dn.length===193&&new Set(dn.map(u=>u.id)).size===193')
rep('if(!Rl(d,s.records)&&d!==Ddaily())return;','if(!Rl(d,s.records)&&d!==Ddaily()&&d!==192)return;')
rep(':null]})}),s.dailyHistory?.length>0?',':null]})}),S.jsx("button",{className:"daily-sortie-btn",style:{display:"block",margin:"8px auto 0",padding:"11px 22px",border:"1px solid #ff7561",borderRadius:"10px",background:"linear-gradient(180deg,#7d2d21,#4d1a12)",color:"#ffd9d0",fontWeight:700,letterSpacing:".08em",cursor:"pointer",fontSize:"13px"},onClick:()=>e(192),children:c("aiDuel")}),s.dailyHistory?.length>0?')
rep('n.fireIn=((this.preferences.difficulty==="hard"?6:9)','n.fireIn=(((this.preferences.difficulty==="hard"?6:9)')
rep('+n.id%4*1.5,this.temp.copy(this.player).sub(n.position)','+n.id%4*1.5)*(n.kind==="drone"?.55:1),this.temp.copy(this.player).sub(n.position)')
rep('children:S.jsx(Kw,{missionId:d,save:s,onDeploy:Ce,onControls:()=>c("controls")})})','children:S.jsxs("div",{children:[S.jsx(Kw,{missionId:d,save:s,onDeploy:Ce,onControls:()=>c("controls")}),S.jsxs("div",{style:{display:"flex",gap:8,justifyContent:"center",marginTop:12},children:[S.jsx("button",{className:"text-button",style:s.preferences.assisted?{border:"1px solid #e8a33d",color:"#e8a33d"}:{},onClick:()=>Xe({assisted:!0}),children:Te("startAuto")}),S.jsx("button",{className:"text-button",style:s.preferences.assisted?{}:{border:"1px solid #7ec8e3",color:"#7ec8e3"},onClick:()=>Xe({assisted:!1}),children:Te("startManual")})]})]})})')
# ---------- v22: stüdyo sesi (spatial + envelope fix + damage) + görsel patlama ----------
rep('musicSrc=null;musicG=null;','musicSrc=null;musicG=null;_attn=1;_pan0=0;')
rep('_shot(o,rv=0){const n=this.context,g=n.createGain();g.connect(this.master);','_shot(o,rv=0,pan){const n=this.context,g=n.createGain();if(pan===undefined)pan=this._pan0;let d=this.master;if(pan&&n.createStereoPanner){const p=n.createStereoPanner();p.pan.value=Math.max(-1,Math.min(1,pan));p.connect(this.master);d=p}if(this._attn<1){const q=n.createGain();q.gain.value=this._attn;q.connect(d);d=q}g.connect(d);')
rep('play(e){if(!this.context||!this.master||!this.enabled||this.context.state!=="running")return;const n=this.context;',
'play(e,pos,pv,hd){if(!this.context||!this.master||!this.enabled||this.context.state!=="running")return;const n=this.context;this._attn=1,this._pan0=0;if(pos&&pv){const dx=pos.x-pv.x,dz=pos.z-pv.z,dist=Math.hypot(dx,dz);if(dist>180){this._attn=Math.max(.1,1/(1+Math.pow(dist/620,1.7)));const hv=hd||0;this._pan0=Math.max(-.92,Math.min(.92,(dx*Math.cos(hv)+dz*Math.sin(hv))/dist*1.15))}}')
# --- envelope gecikme bugları (sessiz katmanlar) ---
rep('this._shot((g,a)=>{this._env(g,.1,.15,.12);','this._shot((g,a)=>{this._env(g,a+.1,.15,.12);')
rep('this._env(g,i*.2,.11,.13);','this._env(g,t0,.11,.13);')
rep('this._env(g,i*.028,.1,.03);','this._env(g,a+i*.028,.1,.03);')
rep('this._env(g,.04,.5,.9);','this._env(g,a+.04,.5,.9);')
rep('this._env(g,.05,.2,.32);','this._env(g,a+.05,.2,.32);')
rep('this._env(g,.1,.25,','this._env(g,a+.1,.25,')
# --- top stereo ---
rep('else if(e==="gun"){this._shot(','else if(e==="gun"){this._gs=!this._gs,this._pan0=this._gs?-.45:.45;this._shot(')
# --- füze: uzaklaşan whoosh kuyruğu ---
rep('this._nz(g,n,a,.25,"highpass",2400,0)},.2)}\nelse if(e==="explosion")',
'this._nz(g,n,a,.25,"highpass",2400,0)},.2);this._shot((g,a)=>{this._env(g,0,1.3,1.5);this._nz(g,n,a,1.5,"bandpass",300,3800,.7)},.35)}\nelse if(e==="explosion")')
# --- infilak: enkaz çıtırtısı + derin uğultu ---
rep('o.frequency.value=300;o.detune.value=35;o.connect(g);o.start(a);o.stop(a+.32);o.onended=()=>o.disconnect()},.3)}\nelse if(e==="splash")',
'o.frequency.value=300;o.detune.value=35;o.connect(g);o.start(a);o.stop(a+.32);o.onended=()=>o.disconnect()},.3);for(let i=0;i<10;i++){const t=.08+Math.random()*.9;this._shot((g,a)=>{this._env(g,a+t,.16+Math.random()*.1,.07+Math.random()*.06);this._nz(g,n,a+t,.08,"highpass",1600+Math.random()*2600,0)},.55)}this._shot((g,a)=>{this._env(g,a+.12,1.05,2.2);this._nz(g,n,a+.12,2.2,"lowpass",150,40)},.8)}\nelse if(e==="damage"){this._shot((g,a)=>{this._env(g,0,.7,1.1);this._nz(g,n,a,1.1,"lowpass",700,90)},.5);this._shot((g,a)=>{this._env(g,0,.5,.55);const o=n.createOscillator();o.type="sawtooth";o.frequency.setValueAtTime(150,a);o.frequency.exponentialRampToValueAtTime(48,a+.5);const f=n.createBiquadFilter();f.type="lowpass";f.frequency.value=900;o.connect(f);f.connect(g);o.start(a);o.stop(a+.55);o.onended=()=>o.disconnect()},.4);for(let i=0;i<2;i++)this._shot((g,a)=>{const t0=a+.08+i*.16;this._env(g,t0,.3,.1);const o=n.createOscillator();o.type="triangle";o.frequency.value=i?660:880;o.connect(g);o.start(t0);o.stop(t0+.11);o.onended=()=>o.disconnect()},.2);this._shot((g,a)=>{this._env(g,0,.45,.18);this._nz(g,n,a,.18,"bandpass",2400,900,1.6)},.3)}\nelse if(e==="splash")')
# --- motor: oyuncu hasarı artık "damage" olayı + sıyırma hasarı sesi ---
rep('n.active=!1,this.health=Math.max(0,this.health-n.damage),this.shake=.65,this.event("hit",this.player,8)','n.active=!1,this.health=Math.max(0,this.health-n.damage),this.shake=.65,this.event("damage",this.player,8)')
rep('this.pitch=Math.max(this.pitch,.05),this.shake=Math.min(1,this.shake+.4))','this.pitch=Math.max(this.pitch,.05),this.shake=Math.min(1,this.shake+.4),Math.random()<a*2.2&&this.event("damage",this.player,4))')
# --- görsel: damage patlaması, flaş ölçekli, uzaklığa göre sarsıntı ---
rep('if(n(a.kind),(a.kind==="explosion"||a.kind==="splash"||a.kind==="hit")','if(n(a.kind,a.position),(a.kind==="explosion"||a.kind==="splash"||a.kind==="hit"||a.kind==="damage")')
rep('this.flash.position.copy(a.position),this.flash.intensity=1400,','this.flash.position.copy(a.position),this.flash.intensity=500+(a.size||20)*52,')
rep('processEvents(ne,he=>K.current.play(he))','processEvents(ne,(he,ho)=>K.current.play(he,ho,ne.player,ne.heading))')
rep(',this.shake=.35,this.notify("neutralized")',',this.shake=Math.min(.6,.1+.55*Math.exp(-e.position.distanceTo(this.player)/900)),this.notify("neutralized")')
# --- bloom güçlendir ---
rep('this.bloom=new ro(new Le(1,1),.19,.5,1.3)','this.bloom=new ro(new Le(1,1),.34,.62,.9)')
# ---------- v23: AI düello startup'a taşındı + file:// demo + ilk 3 görev açık ----------
# A) düello görevini diag içinden çıkar (oraya sadece panel açılınca çalışıyordu — bug buydu)
rep('return dn.push({id:192,name:"DUEL ARENA",season:3,chapter:0,kind:"boss",targets:["interceptor"],briefing:lb.boss,reward:1500,limit:300,par:150,sunset:1}),e("193 mission configurations"',
    'return e("193 mission configurations"')
# B) modül yüklenirken ekle (dn bildiriminin hemen sonrası)
rep('by="idea-game.striker.v2";function Ey(){',
    'by="idea-game.striker.v2";dn.push({id:192,name:"DUEL ARENA",season:3,chapter:0,kind:"boss",targets:["interceptor"],briefing:lb.boss,reward:1500,limit:300,par:150,sunset:1});function Ey(){')
# C) file:// açılışta demo ayrıcalıkları (yerel test dosyası = her şey açık)
rep('/[?&]demo/.test(location.search)','(/[?&]demo/.test(location.search)||location.protocol==="file:")')
# D) ilk 3 görev yeni oyunculara açık (onboarding)
rep('function Rl(s,e){return s===0||!!e[s-1]}','function Rl(s,e){return s<3||!!e[s-1]}')
open('striker-dev/index.html','w',encoding='utf-8').write(h)
print("ALL V5 PATCHES APPLIED, size:",len(h))
m=re.search(r'<script type="module" crossorigin>([\s\S]*?)</script>', h)
open('/tmp/app_check.mjs','w',encoding='utf-8').write(m.group(1))
print("script extracted:",len(m.group(1)))
