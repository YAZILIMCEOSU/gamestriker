P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old); assert n==1, f"count {n}: {old[:80]}"
    s=s.replace(old,new)

# 1) telegraph: 1.3 s before an enemy shot, warn once per shot (only if in range and no flare cooldown)
rep('n.fireIn-=e,n.fireIn<=0&&(n.kind!==\"sub\"||n.surf)&&',
    'n.fireIn-=e,n.fireIn<=1.3&&n.fireIn>0&&!n.tele&&(n.kind!==\"sub\"||n.surf)&&this.flareTimer<=0&&n.position.distanceToSquared(this.player)<2300**2&&(n.tele=!0,this.notify(\"lockWarn\",2)),n.fireIn<=0&&(n.kind!==\"sub\"||n.surf)&&')

# 2) re-arm the telegraph once the shot is fired
rep('this.spawn(\"hostile\",n.position,this.temp,11,[9,11,14,17,20][this.di]))}',
    'this.spawn(\"hostile\",n.position,this.temp,11,[9,11,14,17,20][this.di]),n.tele=!1)}')

# 3) localized text for lockWarn (10 languages: EN TR DE ES FR IT PT RU ID AR)
strings=('lockWarn:["RADAR LOCK — break or flare!","RADAR KİLİDİ — kır veya fişek at!","RADARSPERRE — ausweichen oder Täuschkörper!","BLOQUEO RADAR — quiebra o usa señuelos!","VERROUILLAGE RADAR — vire ou leurre !","AGGANCIO RADAR — vira o usa esche!","TRAVA DE RADAR — manobre ou use chamariz!","РАДАР ЗАХВАТИЛ — уходи или ставь ловушки!","RADAR TERKUNCI — manuver atau umpan!","قفل رادار — انعطف أو أطلق الطعم!"],')
rep('swarm:["SWARM — drone swarm inbound!"', strings + 'swarm:["SWARM — drone swarm inbound!"')

assert s.count('3.57 DEV')==2
s=s.replace('3.57 DEV','3.58 DEV')
open(P,'w',encoding='utf-8').write(s); print('v84 ok', len(s))
