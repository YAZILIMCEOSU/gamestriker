#!/usr/bin/env python3
# v3.19 — kita plakalari (karasal alan), kara hedefleri KARADA, kiyi koprusu, gercekci meydan, hangar pedi
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v43.py"], cwd="/home/user", capture_output=True, text=True)
print("v43:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

# 1) PK: kita plakalari (gorev bazli taraf)
rep('out.push([x,z,540+r()*1200,150+r()*520,i])}return out}',
    'out.push([x,z,540+r()*1200,150+r()*520,i])}const sd=id%4,CX=[-6200,6200,-2800,3000][sd],CZ=[-3400,-3800,-7000,-7200][sd];out.push([CX,CZ,4200+(id%3)*700,34+(id%5)*7,90]);if(id%2)out.push([CX*.45+(sd%2?1400:-1400),CZ+2100,2400,26+(id%4)*6,91]);return out}',"pkLand")

# 2) kara hedefleri karaya, kopru kiya seridine
rep('let p=(e.kind==="boss"?-2600:-1100)-u*520-e.chapter*140,d=u===0?0:(u%2?-1:1)*(360+u*210);for(let q=1;q<26&&this.terr(d,p)>(f?g-50:0);q++)q%3===0?p-=260:d+=(q%2?1:-1)*(320+q*120);',
    'const lk=["refinery","airfield","radar"].includes(c),lb2=c==="bridge";const LP=(lk||lb2)?(this.peaks||(this.peaks=PK(this.mission.id||0))).find(x=>x[4]===90):null;let p=LP?(lb2?LP[1]*.55:LP[1]+((u%3)-1)*620):(e.kind==="boss"?-2600:-1100)-u*520-e.chapter*140,d=LP?(lb2?LP[0]*.55:LP[0]+(u-3)*480):u===0?0:(u%2?-1:1)*(360+u*210);for(let q=1;q<26&&(lk?this.terr(d,p)<5:lb2?!(this.terr(d,p)>-1&&this.terr(d,p)<9):this.terr(d,p)>(f?g-50:0));q++)q%3===0?p-=260:d+=(q%2?1:-1)*(320+q*120);',"spawnLand")

# 3) kopru modeli: uzun deck + yol cizgisi + korkuluk + kuleler
rep('if(e==="bridge"){a.add(this.box([8,40,14],this.steel,[-52,12,0]));a.add(this.box([8,40,14],this.steel,[52,12,0]));a.add(this.box([140,6,20],this.steel,[0,34,0]));a.add(this.box([4,10,20],this.steel,[-30,44,0]));a.add(this.box([4,10,20],this.steel,[30,44,0]));return a}',
    'if(e==="bridge"){a.add(this.box([10,46,18],this.steel,[-105,14,0]));a.add(this.box([10,46,18],this.steel,[105,14,0]));a.add(this.box([240,6,22],this.steel,[0,36,0]));a.add(this.box([230,.3,1.2],this.pale,[0,39.4,0],.05));for(const q of[-1,1])a.add(this.box([240,2.4,.8],this.steel,[0,39.2,q*10.6]));a.add(this.box([6,14,22],this.steel,[-60,44,0]));a.add(this.box([6,14,22],this.steel,[60,44,0]));return a}',"bridgeUp")

# 4) meydan modeli: pist cizgisi + park halinde ucaklar + yakit tanklari
rep('if(e==="airfield"){a.add(this.box([150,2,36],this.dark,[0,1,0]));a.add(this.box([26,12,20],this.steel,[-40,7,26]));a.add(this.box([26,12,20],this.steel,[-8,7,26]));a.add(this.box([8,22,8],this.steel,[40,11,24]));return a}',
    'if(e==="airfield"){a.add(this.box([170,2,40],this.dark,[0,1,0]));a.add(this.box([160,.25,1.4],this.pale,[0,2.2,0],.05));a.add(this.box([30,14,22],this.steel,[-46,8,30]));a.add(this.box([30,14,22],this.steel,[-10,8,30]));a.add(this.box([9,24,9],this.steel,[46,13,28]));for(const q of[0,1]){const w=this.enemyAircraft("interceptor");w.scale.setScalar(.9);w.position.set(20+q*26,3,16);w.rotation.y=.25;a.add(w)}for(const q of[-1,0,1]){const t=this.mesh(new oi(3,3,10,10),this.steel,[64,4,q*8]);t.rotation.x=Math.PI/2,a.add(t)}return a}',"airfieldUp")

# 5) hangar pedi: constructor
rep('this.carrier=this.assets.ship("carrier",!0),this.carrier.position.set(0,0,1050),this.scene.add(this.carrier),',
    'this.carrier=this.assets.ship("carrier",!0),this.carrier.position.set(0,0,1050),this.scene.add(this.carrier),this.hangarPad=this.assets.buildPad(),this.hangarPad.visible=!1,this.scene.add(this.hangarPad),',"padCtor")

# 6) setMode: pad gorunurlugu
rep('this.carrier.visible=e!=="hangar",e!=="game"&&this.environment.setSunset(!0))}',
    'this.carrier.visible=e!=="hangar",e!=="game"&&this.environment.setSunset(!0),this.hangarPad&&(this.hangarPad.visible=e==="hangar"))}',"padMode")

# 7) buildPad (assets sinifi)
rep('aircraft(e,n=!1){const a=new Vi;a.name=e;',
    'buildPad(){const a=new Vi;a.add(this.box([340,4,240],this.dark,[0,-2,0],.3));for(let i=0;i<5;i++)a.add(this.box([24,.3,2.2],this.pale,[-120+i*60,0,60],.05));a.add(this.box([2.2,.3,180],this.pale,[-150,0,0],.05));a.add(this.box([2.2,.3,180],this.pale,[150,0,0],.05));a.add(this.box([520,70,8],this.steel,[0,30,-160]));a.add(this.box([8,70,340],this.steel,[-270,30,0]));a.add(this.box([8,70,340],this.steel,[270,30,0]));for(const q of[-1,0,1])a.add(this.box([14,14,14],this.steel,[q*70,5,-130]));for(const q of[-1,1])a.add(this.mesh(new oi(2.4,2.4,8,10),this.orange,[q*200,4,80]));a.traverse(m=>{m.castShadow=!1,m.receiveShadow=!1});return a}aircraft(e,n=!1){const a=new Vi;a.name=e;',"buildPad")

# 7b) kara hedefleri zemin yuksekligine oturur
rep('q%3===0?p-=260:d+=(q%2?1:-1)*(320+q*120);const _=(c==="carrier"?380',
    'q%3===0?p-=260:d+=(q%2?1:-1)*(320+q*120);const gy=lk||lb2?Math.max(3,this.terr(d,p)+1.5):g;const _=(c==="carrier"?380',"snapY")
rep('position:new H(d,g,p),origin:new H(d,g,p),heading:.2,',
    'position:new H(d,gy,p),origin:new H(d,gy,p),grounded:lk||lb2,heading:.2,',"pushY")

# 7c) kara yapilari suruklenmez
rep('const a=n.airborne?310:80;','const a=n.airborne?310:n.grounded?0:80;',"noDrift")

# 7d) dogrulamaya ac
rep('$.current=ae}catch','$.current=ae,window.__world=ae}catch',"exposeWorld")

# 8) rozet
c19=s.count("3.18 DEV")
if c19<2:
    print("FAIL badge",c19); sys.exit(1)
s=s.replace("3.18 DEV","3.19 DEV")
print("ok badge x",c19)

io.open(P,"w",encoding="utf-8").write(s)
print("v44 size",len(s))
