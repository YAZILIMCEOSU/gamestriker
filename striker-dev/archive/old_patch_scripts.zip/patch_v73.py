p = '/home/user/striker-dev/index.html'
s = open(p, encoding='utf-8').read()


def rep(old, new):
    global s
    n = s.count(old)
    assert n == 1, (n, old[:100])
    s = s.replace(old, new)


# 1) Asistan irtifa hedefi: savaşta 200 m (hava hedefi varsa 150–700), asistan açıkken en az 80 m
rep('const p=this.phase===\"return\"?Math.max(24,Math.min(180,this.targetDistance*.35)):this.target?.airborne?this.target.position.y:105;u=li.clamp((p-this.player.y)/380,-.25,.25)}',
    'const p=this.phase===\"return\"?(this.targetDistance<600?Math.max(40,Math.min(180,this.targetDistance*.35)):180):this.target?.airborne?Math.max(150,Math.min(700,this.target.position.y)):200;u=li.clamp((p-this.player.y)/380,-.25,.25);if(this.player.y<80&&this.phase!==\"landing\"&&this.phase!==\"takeoff\")u=Math.max(u,.22)}')

# 2) Avcı yapay zekâsı: sürekli sapma yok; düz yaklaş, yakında kır ve uzaklaş, geri dön
rep('let ux=dx/dist,uy=dy/dist,uz=dz/dist;const ang=n.evT>0?n.evDir*1.25:Math.sin(this.time*1.3+n.id)*.22;const c=Math.cos(ang),sn=Math.sin(ang);const rx=ux*c-uz*sn,rz=ux*sn+uz*c;ux=rx;uz=rz;if(n.evT>0)uy=uy*.5+n.evDir*.2;',
    'let ux=dx/dist,uy=dy/dist,uz=dz/dist;n.bT=(n.bT||0)-e;if(n.bT<=0&&n.evT<=0&&dist<260){n.bT=2.8+Math.random()*1.2;n.bDir=Math.random()<.5?-1:1}if(n.bT>0&&n.evT<=0){ux=-ux;uz=-uz;uy=-uy*.3}const ang=n.evT>0?n.evDir*1.25:(n.bT>0?(n.bDir||1)*.5:0);const c=Math.cos(ang),sn=Math.sin(ang);const rx=ux*c-uz*sn,rz=ux*sn+uz*c;ux=rx;uz=rz;if(n.evT>0)uy=uy*.5+n.evDir*.2;')

s = s.replace('3.72 DEV', '3.73 DEV')
open(p, 'w', encoding='utf-8').write(s)
print('ok')
