p='/home/user/striker-dev/index.html'
s=open(p,encoding='utf-8').read()
def rep(old,new,cnt=1):
    global s
    n=s.count(old); assert n==cnt,(n,old[:70]); s=s.replace(old,new)
# exposure: less washed-out highlights
rep('this.renderer.toneMappingExposure=1.12','this.renderer.toneMappingExposure=.96')
# bloom: less glare
rep('quality==="ultra"?.34:.24','quality==="ultra"?.2:.14',2)
# fog: weather 2 density lower, others unchanged
rep('fog.density=e===2?3.6e-4:','fog.density=e===2?2.1e-4:')
# fog overlay veil: softer
rep('background:linear-gradient(180deg,rgba(214,226,232,.14),rgba(214,226,232,.32))','background:linear-gradient(180deg,rgba(214,226,232,.06),rgba(214,226,232,.14))')
s=s.replace('3.62 DEV','3.63 DEV')
open(p,'w',encoding='utf-8').write(s)
print('v89 ok')
