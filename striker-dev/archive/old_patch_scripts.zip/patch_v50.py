#!/usr/bin/env python3
# v3.25 — ucak gemisi sinematigi: guberte kalkisi -> seyir -> saldiri -> RTB(AURORA) -> otomatik inis
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v49.py"], cwd="/home/user", capture_output=True, text=True)
print("v49:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

# 1) constructor: home carrier + guberte spawn + takeoff fazı
rep('this.notify("sortie",4),this.evtT=35+Math.random()*30',
    'this.notify("sortie",4),this.homePos=new H(0,0,1500),this.entities.push({id:901,kind:"carrier",friendly:!0,position:this.homePos.clone(),origin:this.homePos.clone(),heading:0,hp:1e9,maxHp:1e9,radius:90,fireIn:1e9,phase:0,airborne:!1}),this.player.set(0,17,1560),this.speed=0,this.catT=0,this.phase="takeoff",this.notify("takeoffRoll",5),this.evtT=35+Math.random()*30',
    "cineSpawn")

# 2) takeoff: katapult ivmesi yerine gercek deck-run ivmesi
rep('const f=this.catT<2.6?Math.min(178,this.speed+260*a):88+n.throttle*(this.aircraft.speed-88)+(n.boost?40:0);',
    'const f=this.catT<2.6?Math.min(178,this.speed+(this.phase==="takeoff"?30:260)*a):88+n.throttle*(this.aircraft.speed-88)+(n.boost?40:0);',
    "rollAccel")

# 3) takeoff fazinda dusman yok; rotation sonrasi havalaninca combat
rep('this.player.length()>14e3&&(this.assisted=!0),this.phase==="return")',
    'this.player.length()>14e3&&(this.assisted=!0),this.phase==="takeoff"&&(this.speed>70&&this.catT>2.2?(this.phase="combat",this.catT=4,this.notify("airborne",5)):0),this.phase==="return")',
    "takeoffPhase")

# 4) dusman guncellemesi takeoff'ta calismasin
rep('this.notify(this.speed>=115?"landSpeed":"landAlt",2)}else{this.updateEnemies(a),',
    'this.notify(this.speed>=115?"landSpeed":"landAlt",2)}else if(this.phase==="takeoff"){}else{this.updateEnemies(a),',
    "takeoffSkipEnemies")

# 5) RTB: extraction 1050 one degil, AURORA'ya (homePos)
rep('this.phase="return",this.extraction.copy(this.player).addScaledVector(this.forward,1050),this.extraction.y=180',
    'this.phase="return",this.extraction.copy(this.homePos),this.extraction.y=120',
    "rtbHome")

# 6) 902 klon carrier push'ini kaldir (home carrier zaten sahnede)
rep('this.notify("extraction",30),this.entities.push({id:902,kind:"carrier",friendly:!0,position:this.extraction.clone(),origin:this.extraction.clone(),heading:this.heading,hp:1e9,maxHp:1e9,radius:90,fireIn:1e9,phase:0,airborne:!1})',
    'this.notify("extraction",30)',
    "rtbNoDup")

# 7) inis sinematigi: yaklas -> landing fazi -> deck touchdown -> finish
rep('this.phase==="return"){this.lock=0;const Ld=this.player.distanceTo(this.extraction);if(Ld<220&&this.player.y<95&&this.speed<125)this.finish(!0,"landed");',
    'this.phase==="return"){this.lock=0;const Ld=this.player.distanceTo(this.extraction);if(this.phase==="return"&&Ld<420&&this.player.y<140&&this.speed<150){this.phase="landing",this.landT=0,this.assisted=!1,this.notify("clearedLand",6)}if(this.phase==="landing"){this.landT+=a;const D=this.extraction,T=Math.atan2(D.x-this.player.x,-(D.z-this.player.z));this.heading=Lu(this.heading+Math.atan2(Math.sin(T-this.heading),Math.cos(T-this.heading))*Math.min(1,a*2));this.player.x+=(D.x-this.player.x)*Math.min(1,a*1.6);this.player.z+=(D.z+40-this.player.z)*Math.min(1,a*1.6);this.player.y=Math.max(17,this.player.y+(17-this.player.y)*Math.min(1,a*.9)-a*6);this.speed=Math.max(28,this.speed-90*a);this.pitch=li.damp(this.pitch,.03,3,a);this.bank=li.damp(this.bank,0,4,a);if(this.landT>5||this.player.distanceTo(D)<14){this.player.set(D.x,17,D.z+40),this.speed=0,this.notify("touchdown",5),this.finish(!0,"landed")}}else if(Ld<220&&this.player.y<95&&this.speed<125)this.finish(!0,"landed");',
    "landingCine")

# 8) landing fazi da return-dalllansa (blok her tick calissin)
rep(',this.phase==="return"){this.lock=0',
    ',(this.phase==="return"||this.phase==="landing")){this.lock=0',
    "landingInBranch")

# 8b) wake loop: id==index varsayimini kaldir (home carrier 901 guvenli olsun)
rep('for(const o of this.wakes){const c=n.entities[o.userData.id];',
    'for(const o of this.wakes){const c=n.entities.find(q=>q.id===o.userData.id);if(!c)continue;',
    "wakeById")

# 9) i18n radyo hatlari
i='welcomeHome:["Welcome home, pilot."'
iw=s.find(i)
j=s.find(']',iw)
add=',takeoffRoll:["AURORA deck, wind over deck 18. Roll on, Aslan.","AURORA güvertesi, rüzgâr 18. Gazla, Aslan.","AURORA-Deck, Wind 18. Rollbahn frei, Aslan.","Cubierta AURORA, viento 18. Rueda, Aslan.","Pont AURORA, vent 18. Lancez-vous, Aslan.","Ponte AURORA, vento 18. Via, Aslan.","Convés AURORA, vento 18. Role, Aslan.","Палуба АВРОРЫ, ветер 18. Разгон, Аслан.","Dek AURORA, angin 18. Meluncur, Aslan.","سطح أورورا، رياح 18. انطلق يا أصلان."],airborne:["Positive climb. Gear up — proceed to targets.","Pozitif tırmanma. Vites içeri — hedeflere ilerle.","Positiver Steigflug. Fahrwerk ein — weiter zu den Zielen.","Ascenso positivo. Tren arriba — continúe a los objetivos.","Montée positive. Train rentré — cap sur les objectifs.","Salita positiva. Carrello su — procedi ai bersagli.","Subida positiva. Trem recolhido — prossiga aos alvos.","Набор высоты. Шасси убрать — следуйте к целям.","Pendakian positif. Roda masuk — lanjut ke target.","تسلق إيجابي. ارفع العجلات — تابع إلى الأهداف."],clearedLand:["AURORA marshal: cleared to land, deck steady.","AURORA marşal: inişe serbest, güverte sabit.","AURORA-Marshalling: Landeerlaubnis, Deck stabil.","AURORA: autorizado a aterrizar, cubierta estable.","AURORA : autorisé à apponter, pont stable.","AURORA: autorizzato all\'appontaggio, ponte stabile.","AURORA: autorizado a pousar, convés estável.","АВРОРА: разрешена посадка, палуба готова.","AURORA: diizinkan mendarat, dek stabil.","أورورا: مصرح بالهبوط، السطح ثابت."],touchdown:["Hook down, welcome home, Aslan.","Kanca aşağı, evine hoş geldin, Aslan.","Fanghaken unten, willkommen zu Hause, Aslan.","Gancho abajo, bienvenido a casa, Aslan.","Crosse sortie, bienvenue à la maison, Aslan.","Gancio giù, bentornato a casa, Aslan.","Gancho baixado, bem-vindo a casa, Aslan.","Крюк выпущен, с возвращением, Аслан.","Kait turun, selamat datang, Aslan.","الخُطّاف منخفض، مرحباً بعودتك يا أصلان."]'
assert s.count(i)==1
s=s[:j+1]+add+s[j+1:]
print("ok i18nRadio")

# 9) rozet
c25=s.count("3.24 DEV")
if c25<2:
    print("FAIL badge",c25); sys.exit(1)
s=s.replace("3.24 DEV","3.25 DEV")
print("ok badge x",c25)

io.open(P,"w",encoding="utf-8").write(s)
print("v50 size",len(s))
