p = '/home/user/striker-dev/index.html'
s = open(p, encoding='utf-8').read()


def rep(old, new):
    global s
    n = s.count(old)
    assert n == 1, (n, old[:90])
    s = s.replace(old, new)


# M1: tam ekran iframe'de reddedilirse oyunu yeni sekmede aç
rep('Ne=async()=>{try{document.fullscreenElement?await document.exitFullscreen():await document.documentElement.requestFullscreen()}catch{P(__L(de,Fw.fsError))}};',
    'Ne=async()=>{try{document.fullscreenElement?await document.exitFullscreen():await document.documentElement.requestFullscreen()}catch{if(window.top!==window.self){try{window.open(location.href,"_blank","noopener")}catch{}P(__L(de,Fw.fsFrame))}else P(__L(de,Fw.fsError))}};')

FSFRAME = ('fsFrame:["Tam ekran için oyun yeni sekmede açıldı.",'
           '"Opened in a new tab for fullscreen.",'
           '"Für Vollbild wurde das Spiel in einem neuen Tab geöffnet.",'
           '"El juego se abrió en una pestaña nueva para pantalla completa.",'
           '"Le jeu s\'est ouvert dans un nouvel onglet pour le plein écran.",'
           '"Il gioco è stato aperto in una nuova scheda per lo schermo intero.",'
           '"O jogo foi aberto em uma nova aba para tela cheia.",'
           '"Игра открыта в новой вкладке для полноэкранного режима.",'
           '"Game dibuka di tab baru untuk layar penuh.",'
           '"تم فتح اللعبة في تبويب جديد لملء الشاشة."],')
rep('fsError:[', FSFRAME + 'fsError:[')

# M2: dikey telefonda uçuşta "yatay çevir" uyarısı (kapatılabilir)
HINT = r'''<style id="mobile-v72">
#rotate-hint{display:none;position:fixed;inset:0;z-index:9999;background:rgba(8,14,18,.94);color:#e8f1f5;align-items:center;justify-content:center;flex-direction:column;gap:14px;text-align:center;padding:24px;font-family:var(--mono,monospace);font-size:14px;letter-spacing:.06em}
#rotate-hint b{font-size:28px;color:#e8a33d}
#rotate-hint button{margin-top:10px;padding:12px 22px;border-radius:10px;border:1px solid #e8a33d;background:transparent;color:#e8a33d;font:inherit;cursor:pointer}
@media (orientation:portrait) and (pointer:coarse){body.rotate-ask #rotate-hint{display:flex}}
@media (max-width:820px) and (pointer:coarse){.obj-banner,.hg3-stats{font-size:10px!important}}
</style>
<script>(function(){var tr=(navigator.language||"").indexOf("tr")===0;var t=tr?{h:"Daha iyi uçuş için telefonu yatay çevirin",b:"Devam et"}:{h:"Turn your phone sideways for a better flight",b:"Continue"};var d=document.createElement("div");d.id="rotate-hint";d.innerHTML="<b>&#8635;</b><span>"+t.h+"</span><button type=\"button\">"+t.b+"</button>";document.addEventListener("DOMContentLoaded",function(){document.body.appendChild(d)});d.addEventListener("click",function(){document.body.classList.remove("rotate-ask");d.dataset.dismissed="1"});setInterval(function(){var f=!!document.querySelector(".striker-app.in-flight");document.body.classList.toggle("rotate-ask",f&&!d.dataset.dismissed)},700)})();</script>
</head>'''
rep('</head>', HINT)
s = s.replace('3.71 DEV', '3.72 DEV')
open(p, 'w', encoding='utf-8').write(s)
print('ok')
