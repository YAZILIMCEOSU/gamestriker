#!/usr/bin/env python3
# v3.26 — K1: baslatma guvenilirligi (boot watchdog + gorunur hata raporu + retry)
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v50.py"], cwd="/home/user", capture_output=True, text=True)
print("v50:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

WATCH = '''<script>
(function(){
function lang(){try{var sv=JSON.parse(localStorage.getItem("idea-game.striker.v2")||"{}");var l=sv.preferences&&sv.preferences.language;if(l==="tr")return "tr";if(l)return "en"}catch(e){}return (navigator.language||"").indexOf("tr")===0?"tr":"en"}
var TR=lang()==="tr";
var T=TR?{t:"GÖRÜNTÜLEME MOTORU BAŞLATILAMADI",b:"Cihazınız WebGL desteklemiyor veya oyun başlarken bir hata oluştu. Güncel bir tarayıcı deneyin.",r:"YENİDEN DENE",w:"SİSTEMLER HAZIRLANIYOR…"}:{t:"RENDER ENGINE FAILED TO START",b:"Your device does not support WebGL or an error occurred during boot. Try an up-to-date browser.",r:"RETRY",w:"PREPARING SYSTEMS…"};
function show(msg){if(document.getElementById("bootfail"))return;var d=document.createElement("div");d.id="bootfail";d.setAttribute("role","alert");d.style.cssText="position:fixed;inset:0;z-index:9999;background:#0b1418;color:#dfe9ea;display:flex;align-items:center;justify-content:center;font-family:ui-monospace,monospace;text-align:center;padding:24px";d.innerHTML='<div><h2 style="color:#e8a33d;letter-spacing:2px;margin:0 0 10px">'+T.t+'</h2><p style="max-width:440px;line-height:1.5">'+T.b+'</p>'+(msg?'<p style="color:#7d9aa3;font-size:11px;word-break:break-all;max-width:520px">'+String(msg).slice(0,300)+'</p>':'')+'<button onclick="location.reload()" style="margin-top:14px;padding:11px 26px;background:#e8a33d;border:0;color:#10212b;font-weight:700;letter-spacing:1px;cursor:pointer">'+T.r+'</button></div>';(document.body||document.documentElement).appendChild(d)}
window.__showBoot=show;
try{var c=document.createElement("canvas");if(!(c.getContext("webgl2")||c.getContext("webgl"))){show("WebGL context unavailable");return}}catch(e){show(e);return}
var errs=[];window.addEventListener("error",function(e){if(!window.__booted)errs.push(e.message)});window.addEventListener("unhandledrejection",function(e){if(!window.__booted)errs.push(String(e.reason&&e.reason.message||e.reason))});
setInterval(function(){if(window.__booted)return;if(performance.now()>9000)show(errs[0]||"boot timeout")},1500);
})();
</script>
'''

rep('<script type="module" crossorigin>', WATCH + '<script type="module" crossorigin>', "watchdog")

rep('render(e,n){this.time+=e,', 'render(e,n){window.__booted=!0,this.time+=e,', "bootFlag")

c26=s.count("3.25 DEV")
if c26<2:
    print("FAIL badge",c26); sys.exit(1)
s=s.replace("3.25 DEV","3.26 DEV")
print("ok badge x",c26)

io.open(P,"w",encoding="utf-8").write(s)
print("v51 size",len(s))
