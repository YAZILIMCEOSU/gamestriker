#!/usr/bin/env python3
# v3.40 — GRAFIK+: egzost/afterburner parlakligi hiza bagli guclenir + egzost-cekirdek olcegi.
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v64.py"], cwd="/home/user", capture_output=True, text=True)
print("v64:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old, new, tag):
    global s
    c = s.count(old)
    if c != 1:
        print("FAIL", tag, "count", c); sys.exit(1)
    s = s.replace(old, new)
    print("ok", tag)

rep('a.name==="exhaust"&&(a.scale.y=.85+Math.sin(this.time*27)*.07+(n&&this.mode==="game"?n.speed/300:.5))',
    'a.name==="exhaust"&&(a.scale.y=.85+Math.sin(this.time*27)*.07+(n&&this.mode==="game"?n.speed/220+.55:.5)),a.name==="exhaust-core"&&(a.scale.y=1+(n&&this.mode==="game"?Math.min(1.6,n.speed/260):0))',
    "abGlow")

c = s.count("3.39 DEV")
if c < 2:
    print("FAIL badge", c); sys.exit(1)
s = s.replace("3.39 DEV", "3.40 DEV")
print("ok badge x", c)

io.open(P, "w", encoding="utf-8").write(s)
print("v65 size", len(s))
