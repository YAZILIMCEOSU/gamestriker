#!/usr/bin/env python3
# v3.27 — K2: HUD kullanilabilirlik (bildirim onceligi, ilk gorev sade kontrol, mobil cakisma)
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v51.py"], cwd="/home/user", capture_output=True, text=True)
print("v51:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

# 1) bildirim onceligi: uyari > savas bilgisi > kocluk (tek slot, dusuk oncelikli mesaj uyariyi ezemez)
rep('notify(e,n=2){this.message=e,this.messageUntil=this.time+n}',
    'notify(e,n=2){const P=/missile|sam|warn|low|land|incoming|stall|pull|fuel|evade/.test(e)?2:/neutralized|locked|kill|bonus|supply|ace|touchdown|airborne|bossP/.test(e)?1:0;if(this.message&&this.time<this.messageUntil&&P<(this.messagePrio||0))return;this.message=e,this.messageUntil=this.time+n,this.messagePrio=P}',
    "notifyPrio")

# 2) hudData: mid + ilk gorev egitim penceresi
rep('mkind:s.mission.kind,',
    'mkind:s.mission.kind,mid:s.mission.id||0,tut:(s.mission.id||0)===0&&s.time<40&&!s.kills,',
    "hudMidTut")

# 3) ilk gorevde aux silahlar (flare/bomba) egitim penceresi boyunca gizli
rep('S.jsxs("div",{className:"aux-weapons",children:',
    '(!e.tut)&&S.jsxs("div",{className:"aux-weapons",children:',
    "auxGate")

# 4) mobil: silah kumesi olcek + radyo kutusu genislik siniri (cakisma onleme)
rep('text-align:left!important}</style>',
    'text-align:left!important}@media(max-width:720px){.weapons-controls{scale:.86;transform-origin:100% 100%}.radio-transmission{max-width:72vw;left:auto;right:12px}.hull-display{bottom:196px;right:14px}}</style>',
    "cssMobile")

c27=s.count("3.26 DEV")
if c27<2:
    print("FAIL badge",c27); sys.exit(1)
s=s.replace("3.26 DEV","3.27 DEV")
print("ok badge x",c27)

io.open(P,"w",encoding="utf-8").write(s)
print("v52 size",len(s))
