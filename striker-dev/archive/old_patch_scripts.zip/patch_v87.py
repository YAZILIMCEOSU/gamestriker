p='/home/user/striker-dev/index.html'
s=open(p,encoding='utf-8').read()
old='n.fireIn-=e,n.fireIn<=1.3&&'
assert s.count(old)==1, s.count(old)
new=('n.airborne&&n.kind!=="sub"&&n.fireIn>3&&n.position.distanceToSquared(this.player)<1800**2&&(n.fireIn=Math.min(n.fireIn,2.5+Math.random()*1.5)),'
     'n.fireIn-=e,n.fireIn<=1.3&&')
s=s.replace(old,new)
assert s.count('3.60 DEV')==2
s=s.replace('3.60 DEV','3.61 DEV')
open(p,'w',encoding='utf-8').write(s)
print('v87 ok')
