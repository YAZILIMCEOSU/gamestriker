#!/usr/bin/env python3
# v3.30 — FAZ C (K3): kilit durum makinesi (detected/tracking/locking/locked/lost) + gelen fuze uyari
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v54.py"], cwd="/home/user", capture_output=True, text=True)
print("v54:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

# 1) lockState getter
rep('get alive(){return this.entities.filter(e=>e.hp>0&&!e.friendly)}',
    'get alive(){return this.entities.filter(e=>e.hp>0&&!e.friendly)}get lockState(){const t=this.target;if(!t)return this._everTrack?"lost":"detected";if(this.lock>=1)return"locked";if(this.lock>0)return"locking";return"tracking"}',
    "lockGetter")

# 2) durum gecis izleme (update icinde)
rep(';const o=Math.abs(n.yaw)+Math.abs(n.pitch)>.07;',
    ';const LS=this.target?(this.lock>=1?"locked":this.lock>0?"locking":"tracking"):(this._everTrack?"lost":"detected");if(LS!=="lost")this._everTrack=this._everTrack||LS!=="detected";this._lsPrev=LS;const o=Math.abs(n.yaw)+Math.abs(n.pitch)>.07;',
    "lockTrack")

# 3) gelen fuze uyari (cooldown'lu)
rep('this.catT+=a,this.gunTimer-=a,',
    'this.incoming&&!(this.warnT>0)&&this.notify("missileWarn",3),this.warnT=Math.max(0,(this.warnT||0)-a),this.catT+=a,this.gunTimer-=a,',
    "missileWarn")

# 4) hudData lstate
rep('lock:s.lock,', 'lock:s.lock,lstate:s.lockState,', "hudLstate")

# 5) missile button durum sinifi
rep('className:`weapon missile-button ${e.lock>=1?"missile-ready":""}`',
    'className:`weapon missile-button ${e.lock>=1?"missile-ready":""} lock-${e.lstate}`',
    "btnLstate")

# 6) CSS durum renkleri + pulse
rep('right:14px}}</style>',
    'right:14px}}.missile-button.lock-tracking{border-color:#7ec8e3}.missile-button.lock-locking{border-color:#e8a33d;animation:lockpulse .8s infinite}.missile-button.lock-locked{border-color:#7dff9b}.missile-button.lock-lost{border-color:#ff8265}@keyframes lockpulse{50%{box-shadow:0 0 14px #e8a33d88}}</style>',
    "cssLock")

# 7) i18n missileWarn x10
a='الخُطّاف منخفض، مرحباً بعودتك يا أصلان."]'
assert s.count(a)==1
s=s.replace(a, a+',missileWarn:["Missile launch against you — break and flare!","Üzerine füze atıldı — kır ve flare at!","Raketenanflug — ausbrechen und Flares!","¡Misil en camino! ¡Rompe y suelta bengalas!","Missile en approche — rompez et leurres !","Missile in arrivo — spezza e lancia flare!","Míssil em aproximação — quebre e solte flares!","Пуск по вам — манёвр и ловушки!","Rudal menuju kamu — berbelok dan flare!","صاروخ قادم نحوك — اناور وأطلق الشعلات!"]')
print("ok i18nWarn")

c30=s.count("3.29 DEV")
if c30<2:
    print("FAIL badge",c30); sys.exit(1)
s=s.replace("3.29 DEV","3.30 DEV")
print("ok badge x",c30)

io.open(P,"w",encoding="utf-8").write(s)
print("v55 size",len(s))
