#!/usr/bin/env python3
# v3.22 — gercek olcek + AA kalitesi: 560 m kopru, 1000 m pist, olcekli rafineri, orantili AA
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v46.py"], cwd="/home/user", capture_output=True, text=True)
print("v46:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

# 1) KOPRU: 560 m tabliye, 7 ayak, 2 portal kule, yaklasma setleri, olcekli AA
rep('if(e==="bridge"){a.add(this.box([10,46,18],this.steel,[-105,14,0]));a.add(this.box([10,46,18],this.steel,[105,14,0]));a.add(this.box([240,6,22],this.steel,[0,36,0]));a.add(this.box([230,.3,1.2],this.pale,[0,39.4,0],.05));for(const q of[-1,1])a.add(this.box([240,2.4,.8],this.steel,[0,39.2,q*10.6]));a.add(this.box([6,14,22],this.steel,[-60,44,0]));a.add(this.box([6,14,22],this.steel,[60,44,0]));a.add(this.box([90,10,20],this.dark,[-160,4,0]));a.add(this.box([90,10,20],this.dark,[160,4,0]));a.add(this.box([7,5,7],this.steel,[-160,11.5,0]));a.add(this.box([1.4,9,1.4],this.steel,[-160,18,0]));a.add(this.box([7,5,7],this.steel,[160,11.5,0]));a.add(this.box([1.4,9,1.4],this.steel,[160,18,0]));return a}',
    'if(e==="bridge"){a.add(this.box([560,4,24],this.steel,[0,16,0]));a.add(this.box([540,.3,1.4],this.pale,[0,18.4,0],.05));for(const q of[-1,1])a.add(this.box([560,2.2,.8],this.steel,[0,18.2,q*11.6]));for(let p=-240;p<=240;p+=80)a.add(this.box([12,18,14],this.steel,[p,8,0]));for(const q of[-1,1]){a.add(this.box([10,52,10],this.steel,[q*160,26,0]));a.add(this.box([6,4,30],this.steel,[q*160,52,0]))}for(const q of[-1,1])a.add(this.box([140,12,26],this.dark,[q*330,5,0]));for(const q of[-1,1]){a.add(this.box([5,2,5],this.steel,[q*330,12,8]));a.add(this.box([.7,6,.7],this.steel,[q*330,16,8]))}return a}',"bridgeReal")

# 2) MEYDAN: 1000 m pist + esik/orta cizgi, taksi yolu, 2 hangar, kule, yakit ciftligi, olcekli AA
rep('if(e==="airfield"){a.add(this.box([230,5,150],this.dark,[0,-2.5,6]));a.add(this.box([16,9,12],this.steel,[90,4,-40]));a.add(this.box([17,1.2,13],this.pale,[90,9,-40]));a.add(this.box([170,2,40],this.dark,[0,1,0]));a.add(this.box([160,.25,1.4],this.pale,[0,2.2,0],.05));a.add(this.box([30,14,22],this.steel,[-46,8,30]));a.add(this.box([30,14,22],this.steel,[-10,8,30]));a.add(this.box([9,24,9],this.steel,[46,13,28]));for(const q of[0,1]){const w=this.enemyAircraft("interceptor");w.scale.setScalar(.9);w.position.set(20+q*26,3,16);w.rotation.y=.25;a.add(w)}for(const q of[-1,0,1]){const t=this.mesh(new oi(3,3,10,10),this.steel,[64,4,q*8]);t.rotation.x=Math.PI/2,a.add(t)}a.add(this.box([22,8,.5],this.pale,[-46,5,19.2],.05));a.add(this.box([22,8,.5],this.pale,[-10,5,19.2],.05));a.add(this.box([30,1.6,1.6],this.pale,[-46,15.4,30],.05));a.add(this.box([30,1.6,1.6],this.pale,[-10,15.4,30],.05));a.add(this.box([7,5,7],this.steel,[-90,2.5,-40]));a.add(this.box([1.4,9,1.4],this.steel,[-90,9,-40]));a.add(this.box([7,3,3.4],this.steel,[-20,1.6,-40]));a.add(this.box([2.6,2.4,3.2],this.dark,[-15.4,1.4,-40]));return a}',
    'if(e==="airfield"){a.add(this.box([1100,5,320],this.dark,[0,-2.5,40]));a.add(this.box([1000,2,45],this.dark,[0,1,0]));for(const q of[-1,1])for(let i=0;i<6;i++)a.add(this.box([3,.4,12],this.pale,[q*(470-i*16),2.2,0],.05));for(let i=0;i<9;i++)a.add(this.box([18,.4,1.6],this.pale,[-400+i*100,2.2,0],.05));a.add(this.box([700,2,18],this.dark,[0,1,80]));a.add(this.box([30,2,50],this.dark,[-300,1,45]));a.add(this.box([30,2,50],this.dark,[200,1,45]));for(const q of[-1,0]){a.add(this.box([90,22,60],this.steel,[q*110-40,11,140]));a.add(this.box([92,2,62],this.dark,[q*110-40,23,140]));a.add(this.box([70,12,.6],this.pale,[q*110-40,7,109.6],.05))}a.add(this.box([10,30,10],this.steel,[120,15,140]));a.add(this.box([16,8,16],this.steel,[120,34,140]));for(const q of[-1,0,1]){const t=this.mesh(new oi(5,5,14,10),this.steel,[180+q*14,5,140]);t.rotation.x=Math.PI/2,a.add(t)}for(const q of[0,1]){const w=this.enemyAircraft("interceptor");w.position.set(-250+q*45,2,95);w.rotation.y=Math.PI/2;a.add(w)}a.add(this.box([5,2,5],this.steel,[-450,1,40]));a.add(this.box([.7,6,.7],this.steel,[-450,5,40]));a.add(this.box([5,2,5],this.steel,[450,1,40]));a.add(this.box([.7,6,.7],this.steel,[450,5,40]));return a}',"airfieldReal")

# 3) RAFINERI: 22 m tanklar, 48 m kolon, flare, boru raflari, depo+araclar, olcekli AA
rep('if(e==="refinery"){a.add(this.box([210,5,150],this.dark,[0,-2,0]));a.add(this.box([200,.3,1.6],this.pale,[0,.8,52],.05));for(const q of[[-18,0,-8],[0,0,10],[18,0,-6]])a.add(this.mesh(new oi(7,7,16,10),this.steel,q));a.add(this.box([6,34,6],this.steel,[26,17,6]));a.add(this.box([40,4,4],this.steel,[0,26,0]));for(const q of[[-70,5,-50],[-52,5,-52],[70,6,-46]])a.add(this.box([16,10,12],this.steel,q));for(const q of[[-70,10.4,-50],[-52,10.4,-52],[70,11.4,-46]])a.add(this.box([17,1.4,13],this.pale,q));for(const q of[[-70,6,-43.6],[-52,6,-45.6],[70,7,-39.6]])a.add(this.box([10,1.4,.4],this.pale,q,.06));a.add(this.box([40,2,2],this.steel,[0,6,24]));a.add(this.box([2,2,24],this.steel,[18,6,12]));for(const q of[[36,1.5,40],[40,1.5,44],[38,4,42]])a.add(this.box([4,3,4],this.steel,q));a.add(this.box([7,3,3.4],this.steel,[20,1.6,-30]));a.add(this.box([2.6,2.4,3.2],this.dark,[24.6,1.4,-30]));a.add(this.box([7,5,7],this.steel,[46,2.5,44]));a.add(this.box([1.4,9,1.4],this.steel,[46,9,44]));return a}',
    'if(e==="refinery"){a.add(this.box([260,5,180],this.dark,[0,-2,0]));for(const q of[[-40,0,-20],[0,0,10],[40,0,-15]])a.add(this.mesh(new oi(11,13,22,12),this.steel,q));a.add(this.mesh(new oi(3.5,4,48,10),this.steel,[70,24,-20]));a.add(this.mesh(new oi(3,3.5,38,10),this.steel,[82,19,0]));a.add(this.box([3,64,3],this.steel,[95,32,-30]));a.add(this.box([2,2,2],this.orange,[95,65,-30],.5));a.add(this.box([90,4,3],this.steel,[20,10,-5]));a.add(this.box([90,4,3],this.steel,[20,16,0]));for(const q of[[-90,6,-60],[-65,6,-62],[90,7,-55]])a.add(this.box([20,12,14],this.steel,q));for(const q of[[-90,12.4,-60],[-65,12.4,-62],[90,13.4,-55]])a.add(this.box([21,1.4,15],this.pale,q));for(const q of[[-20,1.6,-70],[0,1.6,-72]]){a.add(this.box([8,3.2,4],this.steel,q));a.add(this.box([3,2.6,3.8],this.dark,[q[0]+5.5,1.4,q[2]]))}a.add(this.box([5,2,5],this.steel,[110,1,60]));a.add(this.box([.7,6,.7],this.steel,[110,5,60]));return a}',"refineryReal")

# 4) RADAR AA olcekli
rep('a.add(this.box([7,5,7],this.steel,[30,2.5,26]));a.add(this.box([1.4,9,1.4],this.steel,[30,9,26]));',
    'a.add(this.box([5,2,5],this.steel,[30,1,26]));a.add(this.box([.7,6,.7],this.steel,[30,5,26]));a.add(this.box([6,3,5],this.steel,[26,1.5,-20]));',"radarAA")

# 5) parca ofsetleri yeni geometriyle eslestirildi
rep('mkParts(c){return c==="refinery"?[{k:"tank",o:[-18,8,-8],r:9,h:60},{k:"tank",o:[0,8,10],r:9,h:60},{k:"tank",o:[18,8,-6],r:9,h:60},{k:"stack",o:[26,17,6],r:7,h:50},{k:"aa",o:[46,4,44],r:8,h:80}]:c==="airfield"?[{k:"hangar",o:[-46,8,30],r:16,h:120},{k:"hangar",o:[-10,8,30],r:16,h:120},{k:"tower",o:[46,13,28],r:8,h:80},{k:"tank",o:[64,4,8],r:6,h:50},{k:"tank",o:[64,4,0],r:6,h:50},{k:"tank",o:[64,4,-8],r:6,h:50},{k:"aa",o:[-90,4,-40],r:8,h:80}]:c==="radar"?[{k:"dish",o:[0,23,0],r:10,h:90},{k:"aa",o:[30,4,26],r:8,h:80}]:c==="bridge"?[{k:"aa",o:[-160,10,0],r:8,h:80},{k:"aa",o:[160,10,0],r:8,h:80}]:null}',
    'mkParts(c){return c==="refinery"?[{k:"tank",o:[-40,11,-20],r:13,h:80},{k:"tank",o:[0,11,10],r:13,h:80},{k:"tank",o:[40,11,-15],r:13,h:80},{k:"stack",o:[70,24,-20],r:8,h:60},{k:"aa",o:[110,2,60],r:8,h:80}]:c==="airfield"?[{k:"hangar",o:[-150,11,140],r:40,h:150},{k:"hangar",o:[-40,11,140],r:40,h:150},{k:"tower",o:[120,20,140],r:10,h:80},{k:"tank",o:[166,5,140],r:8,h:50},{k:"tank",o:[180,5,140],r:8,h:50},{k:"tank",o:[194,5,140],r:8,h:50},{k:"aa",o:[-450,2,40],r:8,h:80},{k:"aa",o:[450,2,40],r:8,h:80}]:c==="radar"?[{k:"dish",o:[0,23,0],r:10,h:90},{k:"aa",o:[30,2,26],r:8,h:80}]:c==="bridge"?[{k:"aa",o:[-330,12,0],r:10,h:80},{k:"aa",o:[330,12,0],r:10,h:80}]:null}',"partsReal")

# 6) vurusluluk yaricaplari yeni olcege gore
rep('c==="bridge"?60:c==="refinery"?45:c==="airfield"?55',
    'c==="bridge"?340:c==="refinery"?95:c==="airfield"?140',"radiiReal")

# 7) rozet
c22=s.count("3.21 DEV")
if c22<2:
    print("FAIL badge",c22); sys.exit(1)
s=s.replace("3.21 DEV","3.22 DEV")
print("ok badge x",c22)

io.open(P,"w",encoding="utf-8").write(s)
print("v47 size",len(s))
