P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old); assert n==1, f"count {n}: {old[:50]}"
    s=s.replace(old,new)
rep('this.cloudTick(e),this.particles.update(e),this.flash.intensity*=',
    'this.cloudTick(e),this.droneTick(e),this.particles.update(e),this.flash.intensity*=')
method=('droneTick(e){if(this.mode!=="game"||!this.player){if(this.droneG)this.droneG.visible=!1;return}'
        'if(!this.droneG){this.droneG=this.assets.aircraft("vanguard");this.droneG.name="kirlangic-m2";this.droneG.scale.setScalar(.7);this.scene.add(this.droneG);this.droneT=0}'
        'this.droneG.visible=!0;this.droneT=(this.droneT||0)+Math.min(.05,Math.max(0,e||0));const t=this.droneT,pp=this.player.position;'
        'this.droneG.position.set(pp.x-95+Math.sin(t*.35)*40,pp.y+28+Math.sin(t*.6)*4,pp.z-110+Math.cos(t*.25)*30);'
        'this.droneG.rotation.y=this.player.rotation.y}')
rep('cloudTick(e){', method+'cloudTick(e){')
s=s.replace('3.47 DEV','3.48 DEV')
open(P,'w',encoding='utf-8').write(s); print('v74 ok', len(s))
