p='/home/user/striker-dev/index.html'
s=open(p,encoding='utf-8').read()
def rep(old,new):
    global s
    n=s.count(old); assert n==1,(n,old[:80]); s=s.replace(old,new)

# A) terrain: scrape damage + hard-hit damage with cooldown; total damage -> destroyed
old=('this.catT>3&&this.player.y<Math.max(10,this.terr(this.player.x,this.player.z)+12)&&(this.health-=a*8,this.player.y=Math.max(6,this.player.y,this.terr(this.player.x,this.player.z)+8),this.pitch=Math.max(this.pitch,.05),this.shake=Math.min(1,this.shake+.4),Math.random()<a*2.2&&this.event("damage",this.player,4)),')
new=('this.catT>3&&(()=>{const g=this.terr(this.player.x,this.player.z),clear=this.player.y-g;if(clear<12){this.impactCd=(this.impactCd||0)-a;this.health-=a*4;this.player.y=Math.max(6,this.player.y,g+8);this.pitch=Math.max(this.pitch,.05);this.shake=Math.min(1,this.shake+.4);if(this.impactCd<=0){this.impactCd=1.1;const dmg=12+Math.min(18,this.speed*.06);this.health-=dmg;this.shake=1;this.event("damage",this.player,10);this.notify("terrainHit",4)}else if(Math.random()<a*2.2)this.event("damage",this.player,4)}})(),')
rep(old,new)

# B) airborne enemies never sink into terrain
rep('n.airborne&&n.kind!=="sub"&&n.fireIn>3&&',
    'n.airborne&&(n.position.y=Math.max(n.position.y,this.terr(n.position.x,n.position.z)+60)),n.airborne&&n.kind!=="sub"&&n.fireIn>3&&')

# C) SIHA (uav) also pursues instead of orbiting left/right
rep('ai=n.airborne&&(n.kind==="interceptor"||n.kind==="attacker");',
    'ai=n.airborne&&(n.kind==="interceptor"||n.kind==="attacker"||n.kind==="uav");')
rep('const spd=(n.evT>0?290:215)*[.9,1,1.08,1.16,1.25][this.di||0];',
    'const spd=(n.evT>0?290:215)*[.9,1,1.08,1.16,1.25][this.di||0]*(n.kind==="uav"?.8:1);')
s=s.replace('3.61 DEV','3.62 DEV').replace('3.62 DEV','3.62 DEV')
open(p,'w',encoding='utf-8').write(s)
print('v88 ok')
