P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
old='$.current.begin(ae),'
assert s.count(old)==1, s.count(old)
s=s.replace(old,'$.current.begin(ae),window.__gfx=$.current,')
open(P,'w',encoding='utf-8').write(s); print('v67b ok')
