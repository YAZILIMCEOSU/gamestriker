P='/home/user/striker-dev/index.html'
s=open(P,encoding='utf-8').read()
old='renderMenu(e){const n=this.mode===\"hangar\",a=this.width/this.height<1;'
assert s.count(old)==1, s.count(old)
s=s.replace(old, old+'this.bloom.strength=n?.05:this.options.quality===\"ultra\"?.34:.24;')
assert s.count('3.44 DEV')==2
s=s.replace('3.44 DEV','3.45 DEV')
open(P,'w',encoding='utf-8').write(s); print('v71 ok', len(s))
