#!/usr/bin/env python3
# v3.18 — dogal inis (asist), kara yapilari (kopru/rafineri/meydan), hava durumu, surpriz bonus, istihbarat satiri
import io, sys, subprocess
r = subprocess.run([sys.executable, "striker-dev/patch_v42.py"], cwd="/home/user", capture_output=True, text=True)
print("v42:", r.stdout.strip().splitlines()[-1] if r.stdout else r.stderr[-200:])
if r.returncode != 0: sys.exit(1)

P = "/home/user/striker-dev/index.html"
s = io.open(P, encoding="utf-8").read()

def rep(old,new,tag):
    global s
    c=s.count(old)
    if c!=1:
        print("FAIL",tag,"count",c); sys.exit(1)
    s=s.replace(old,new)
    print("ok",tag)

# 1) gorev hava durumu
rep('sunset:[.12,0,.6,1][sn],biome:e%6}}','sunset:[.12,0,.6,1][sn],biome:e%6,weather:(e+sn)%3}}',"weatherField")

# 2) snapshot weather
rep('mkind:s.mission.kind,fuel:s.fuel,','mkind:s.mission.kind,weather:s.mission.weather||0,fuel:s.fuel,',"snapWeather")

# 3) asist donus: alçalma profili
rep('const p=this.phase==="return"?180:this.target?.airborne?this.target.position.y:105;',
    'const p=this.phase==="return"?Math.max(24,Math.min(180,this.targetDistance*.35)):this.target?.airborne?this.target.position.y:105;',"assistDescend")

# 4) asist donus: hiz limiti
rep('const f=this.catT<2.6?Math.min(178,this.speed+260*a):88+n.throttle*(this.aircraft.speed-88)+(n.boost?40:0);if(this.catT<2.6?this.speed=Math.min(178,this.speed+260*a):this.speed=li.damp(this.speed,f,.8,a),',
    'const f=this.catT<2.6?Math.min(178,this.speed+260*a):88+n.throttle*(this.aircraft.speed-88)+(n.boost?40:0);const f9=this.phase==="return"&&this.assisted?Math.min(f,this.targetDistance<420?102:150):f;if(this.catT<2.6?this.speed=Math.min(178,this.speed+260*a):this.speed=li.damp(this.speed,f9,.8,a),',"assistSpeed")

# 5) inis esikleri gevset
rep('if(Ld<190&&this.player.y<80&&this.speed<115)this.finish(!0,"landed");else if(Ld<260)',
    'if(Ld<220&&this.player.y<95&&this.speed<125)this.finish(!0,"landed");else if(Ld<300)',"landSoft")

# 6) yeni kara hedefleri hp
rep('c==="heli"?120:c==="uav"?80:100)*',
    'c==="heli"?120:c==="uav"?80:c==="bridge"?240:c==="refinery"?160:c==="airfield"?200:100)*',"hpLand")

# 7) radius
rep('c==="heli"?16:c==="uav"?13:f?22:',
    'c==="heli"?16:c==="uav"?13:c==="bridge"?60:c==="refinery"?45:c==="airfield"?55:f?22:',"radiusLand")

# 8) havuzlar
rep('strike:["corvette","destroyer","corvette","radar","destroyer","corvette","sub"]',
    'strike:["corvette","refinery","corvette","radar","airfield","bridge","sub"]',"poolStrike")
rep('kind:"raid",targets:["destroyer","radar","sub","destroyer","radar"]',
    'kind:"raid",targets:["bridge","refinery","radar","airfield","destroyer"]',"poolRaid")
rep('kind:"raid",targets:["carrier","destroyer","radar","sub"]',
    'kind:"raid",targets:["carrier","bridge","radar","refinery"]',"poolRaid2")
rep('boss:["heavy","carrier","destroyer","drone","interceptor","heavy","sub"]',
    'boss:["heavy","carrier","bridge","drone","interceptor","refinery","sub"]',"poolBoss")

# 9) renderer modelleri
rep('const o=e==="carrier",',
    'if(e==="bridge"){a.add(this.box([8,40,14],this.steel,[-52,12,0]));a.add(this.box([8,40,14],this.steel,[52,12,0]));a.add(this.box([140,6,20],this.steel,[0,34,0]));a.add(this.box([4,10,20],this.steel,[-30,44,0]));a.add(this.box([4,10,20],this.steel,[30,44,0]));return a}if(e==="refinery"){for(const q of[[-18,0,-8],[0,0,10],[18,0,-6]])a.add(this.mesh(new oi(7,7,16,10),this.steel,q));a.add(this.box([6,34,6],this.steel,[26,17,6]));a.add(this.box([40,4,4],this.steel,[0,26,0]));return a}if(e==="airfield"){a.add(this.box([150,2,36],this.dark,[0,1,0]));a.add(this.box([26,12,20],this.steel,[-40,7,26]));a.add(this.box([26,12,20],this.steel,[-8,7,26]));a.add(this.box([8,22,8],this.steel,[40,11,24]));return a}const o=e==="carrier",',
    "landModels")

# 10) begin setWeather
rep(',this.environment.buildIslands(e.mission.id||0,e.mission.biome||0),(e.mission.biome||0)===5&&this.environment.setSunset(!0),',
    ',this.environment.buildIslands(e.mission.id||0,e.mission.biome||0),(e.mission.biome||0)===5&&this.environment.setSunset(!0),this.environment.setWeather(e.mission.weather||0),',"beginWeather")

# 11) environment setWeather
rep('biomePal=[',
    'setWeather(e){this.weatherN=e;this.sceneE&&this.sceneE.fog&&(this.sceneE.fog.density=e===2?4.5e-4:e===1?2.4e-4:1.6e-4)}biomePal=[',"setWeather")

# 12) HUD yagmur overlay
rep('S.jsx("div",{className:"grade-overlay"}),',
    'S.jsx("div",{className:"grade-overlay"}),e.weather===1?S.jsx("div",{className:"rain-overlay"}):null,',"rainOverlay")

# 13) yagmur SFX baslat/durdur cagrilari
rep('U(Lx(ae,[])),K.current.play("launch")',
    'U(Lx(ae,[])),K.current.play("launch"),(ae.mission.weather||0)===1&&K.current.play("rainstart")',"rainStart")
rep('ne.result&&!ie.current&&(ie.current=!0,ze(',
    'ne.result&&!ie.current&&(ie.current=!0,K.current.play("rainstop"),ze(',"rainStop")

# 14) play() rain dallari
rep('o.start(a);o.stop(a+.22);o.onended=()=>o.disconnect()});return}',
    'o.start(a);o.stop(a+.22);o.onended=()=>o.disconnect()});return}if(e==="rainstart"){if(this._rain)return;const len=n.sampleRate*2,buf=n.createBuffer(1,len,n.sampleRate),dd=buf.getChannelData(0);for(let i=0;i<len;i++)dd[i]=(Math.random()*2-1)*.3;const src=n.createBufferSource();src.buffer=buf;src.loop=!0;const rf=n.createBiquadFilter();rf.type="highpass";rf.frequency.value=900;const rg=n.createGain();rg.gain.value=.05;src.connect(rf);rf.connect(rg);rg.connect(this.master);src.start();this._rain={src};return}if(e==="rainstop"){this._rain&&(this._rain.src.stop(),this._rain=null);return}',"rainSfx")

# 15) surpriz bonus olayi
rep(':(this.frenzyT=20,this.notify("frenzy",6)));',
    ':Math.random()<.5?((B3=>{this.entities.push({id:540,kind:"uav",bonus:!0,position:new H(this.player.x+160,170,this.player.z+420),origin:new H(this.player.x+160,170,this.player.z+420),heading:.2,hp:70*B3,maxHp:70*B3,radius:13,fireIn:1e9,phase:0,airborne:!0})})(diM),this.notify("bonus",6)):(this.frenzyT=20,this.notify("frenzy",6)));',"bonusEvt")

# 16) bonus odulu
rep('this.notify("neutralized"),e.id===this.targetId',
    'this.notify("neutralized"),e.bonus&&(this.aceBonus=(this.aceBonus||0)+400,this.notify("bonusGot",4)),e.id===this.targetId',"bonusReward")

# 17) meydandan kalkan savunmaci
rep('hooksTick(a){const M=this.mission.kind,diM=[.85,1,1.2,1.45,1.75][this.di];',
    'hooksTick(a){const M=this.mission.kind,diM=[.85,1,1.2,1.45,1.75][this.di];this.afT=(this.afT||0)-a;if(this.afT<=0){const af=this.entities.find(n=>n.kind==="airfield"&&n.hp>0);if(af){this.afT=28;this.afId=(this.afId||600)+1;this.entities.push({id:this.afId,kind:"interceptor",position:new H(af.position.x,120,af.position.z-300),origin:new H(af.position.x,120,af.position.z-300),heading:.2,hp:100*diM,maxHp:100*diM,radius:22,fireIn:5,phase:0,airborne:!0})}else this.afT=6}',"airfieldDef")

# 18) brifing istihbarat satiri
rep('S.jsx("p",{children:__L(c,o.briefing)}),',
    'S.jsx("p",{children:__L(c,o.briefing)}),S.jsx("p",{className:"brief-intel",children:u("intel_"+o.kind)}),',"intelLine")

# 19) gorev karti hava rozeti
rep('S.jsx("span",{className:"mission-biome",children:c("biome"+(u.biome||0))}),',
    'S.jsx("span",{className:"mission-biome",children:c("biome"+(u.biome||0))}),S.jsx("span",{className:"mission-weather",children:["","🌧",""][u.weather||0]}),',"weatherBadge")

# 20) i18n intel + bonus
rep('const Fw={achTitle:',
    """const Fw={intel_strike:["Strategy: strike hard, egress fast. Flares ready for AA.","Strateji: sert vur, hızlı çık. AA için flare hazır.","Strategie: hart zuschlagen, schnell absetzen.","Estrategia: golpea fuerte y sal rápido.","Stratégie : frappez fort, sortez vite.","Strategia: colpire forte e uscire.","Estratégia: ataque forte e saia rápido.","Тактика: бить жёстко, уходить быстро.","Strategi: pukul keras, keluar cepat.","استراتيجية: اضرب بقوة واخرج سريعاً."],intel_intercept:["Strategy: keep altitude, bleed them one by one.","Strateji: irtifayı koru, tek tek avla.","Höhe halten, einzeln ausbluten.","Mantén altitud, desgaste uno a uno.","Gardez l’altitude, usez-les un par un.","Tieni quota, logorali uno a uno.","Mantenha altitude, desgaste um a um.","Держите высоту, изматывайте по одному.","Jaga ketinggian, kuras satu per satu.","حافظ على الارتفاع وأنهكهم واحداً واحداً."],intel_defense:["Strategy: stay near the ship, keep flares cold.","Strateji: geminin yakınında kal, flare’leri sakla.","Bleib nah am Schiff, Flares sparen.","Quédate cerca del buque, guarda bengalas.","Restez près du navire, gardez les leurres.","Resta vicino alla nave, conserva i flare.","Fique perto do navio, guarde flares.","Держитесь у корабля, берегите ловушки.","Tetap dekat kapal, simpan suar.","ابقَ قرب السفينة واحتفظ بالشعلات."],intel_radar:["Strategy: skim the water, pop up only to fire.","Strateji: su üstünden git, sadece ateş için yüksel.","Flach fliegen, nur zum Feuern steigen.","Rasa el agua, sube solo para disparar.","Rasez l’eau, montez pour tirer.","Radente l’acqua, sali solo per fuoco.","Rase a água, suba só para atirar.","Идите над водой, поднимайтесь для залпа.","Terbang rendah, naik hanya untuk menembak.","حلّق منخفضاً واصعد فقط للإطلاق."],intel_carrier:["Strategy: kill escorts first, then the flagship.","Strateji: önce eskortları, sonra amiral gemisini vur.","Erst Eskorten, dann das Flaggschiff.","Primero escoltas, luego el buque insignia.","D’abord les escortes, puis le navire amiral.","Prima le scorte, poi l’ammiraglia.","Primeiro escoltas, depois a capitânia.","Сначала эскорт, затем флагман.","Hancurkan pengawal dulu, lalu kapal induk.","دمّر المرافقة أولاً ثم الرائدة."],intel_boss:["Strategy: save missiles for the ace window.","Strateji: füzeleri as penceresine sakla.","Raketen für das Ass-Fenster sparen.","Guarda misiles para la ventana del as.","Gardez les missiles pour la fenêtre de l’as.","Risparmia i missili per la finestra dell’asso.","Guarde mísseis para a janela do ás.","Берегите ракеты для окна аса.","Simpan rudal untuk jendela ace.","وفّر الصواريخ لنافذة الأس."],intel_escort:["Strategy: orbit the convoy, scan high and low.","Strateji: konvoyun çevresinde dön, her yönde tara.","Konvoi umkreisen, hoch und tief scannen.","Orbita el convoy, explora arriba y abajo.","Orbitez autour du convoi, scannez partout.","Orbita il convoglio, scandaglia ovunque.","Orbite o comboio, varra alto e baixo.","Кружите над конвоем, сканируйте всё.","Orbiti konvoi, pindai semua arah.","قم بالدوران حول القافلة وامسح كل الاتجاهات."],intel_raid:["Strategy: one pass per target. No lingering.","Strateji: hedef başına tek geçiş. Oyalanma.","Ein Anflug pro Ziel. Nicht verweilen.","Un paso por objetivo. Sin detenerse.","Un passage par cible. Sans s’attarder.","Un passaggio per bersaglio. Non indugiare.","Uma passada por alvo. Sem demora.","Один заход на цель. Не задерживаться.","Satu lintasan per target. Jangan lama.","مرور واحد لكل هدف. دون تردد."],intel_waves:["Strategy: hold the center, reload between waves.","Strateji: merkezi tut, dalgalar arasında yeniden yüklen.","Mitte halten, zwischen Wellen nachladen.","Mantén el centro, recarga entre olas.","Tenez le centre, rechargez entre vagues.","Tieni il centro, ricarica tra le ondate.","Segure o centro, recarregue entre ondas.","Держите центр, перезаряжайтесь между волнами.","Tahan tengah, isi ulang antar gelombang.","ثبّت المركز وأعد التلقيم بين الموجات."],intel_race:["Strategy: smooth is fast. Bank early, apex inside.","Strateji: yumuşak olan hızlıdır. Erken yat, içten dön.","Weich ist schnell. Früh neigen, innen apex.","Suave es rápido. Inclina pronto, apex interno.","Le fluide est rapide. Inclinez tôt, corde intérieure.","Liscio è veloce. Inclina presto, apex interno.","Suave é rápido. Incline cedo, apex interno.","Плавно — значит быстро. Ранний крен, внутренняя дуга.","Halus itu cepat. Miring awal, apex dalam.","السلس سريع. ميل مبكراً وانعطف من الداخل."],intel_chain:["Strategy: pace yourself. Three stages, one focus.","Strateji: kendini ayarla. Üç aşama, tek odak.","Kräfte einteilen. Drei Phasen, ein Fokus.","Dosifica. Tres fases, un foco.","Gérez-vous. Trois étapes, un focus.","Risparmia. Tre fasi, un focus.","Dose-se. Três etapas, um foco.","Экономьте силы. Три этапа, один фокус.","Hemat tenaga. Tiga tahap, satu fokus.","نظّم جهدك. ثلاث مراحل وتركيز واحد."],bonus:["BONUS TARGET — golden drone, +400 credits!","BONUS HEDEF — altın SİHA, +400 kredi!","BONUSZIEL — goldene Drohne, +400 Credits!","OBJETIVO BONUS — dron dorado, +400 créditos!","CIBLE BONUS — drone doré, +400 crédits !","BERSAGLIO BONUS — drone dorato, +400 crediti!","ALVO BÔNUS — drone dourado, +400 créditos!","БОНУС-ЦЕЛЬ — золотой дрон, +400 кредитов!","TARGET BONUS — drone emas, +400 kredit!","هدف إضافي — طائرة ذهبية، +400 رصيد!"],bonusGot:["Bonus secured: +400","Bonus alındı: +400","Bonus gesichert: +400","Bonus asegurado: +400","Bonus obtenu : +400","Bonus ottenuto: +400","Bônus garantido: +400","Бонус получен: +400","Bonus aman: +400","تم تأمين المكافأة: +400"],achTitle:""","i18nIntel")

# 21) CSS
css='''.rain-overlay{position:fixed;inset:0;pointer-events:none;z-index:40;background:repeating-linear-gradient(115deg,transparent 0 6px,rgba(180,210,230,.13) 6px 7px);animation:rainmv .45s linear infinite;mix-blend-mode:screen}
@keyframes rainmv{to{background-position:90px 200px}}
.brief-intel{font-family:var(--mono);color:#ffd08a;font-size:11px;letter-spacing:.06em;margin-top:8px;border-left:2px solid #e8a33d;padding-left:8px}
.mission-weather{position:absolute;right:10px;bottom:10px;font-size:12px}
'''
i=s.rfind('</style>')
s=s[:i]+css+s[i:]
print("ok css43")

# 22) rozet
c18=s.count("3.17 DEV")
if c18<2:
    print("FAIL badge",c18); sys.exit(1)
s=s.replace("3.17 DEV","3.18 DEV")
print("ok badge x",c18)

io.open(P,"w",encoding="utf-8").write(s)
print("v43 size",len(s))
